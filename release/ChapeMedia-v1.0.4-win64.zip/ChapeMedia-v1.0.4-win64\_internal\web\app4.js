$('#player-close').onclick=()=>{$('#video-el').pause();$('#audio-el').pause();$('#player-modal').classList.add('hidden')};
$('#player-modal').addEventListener('click',e=>{if(e.target.id==='player-modal')$('#player-close').click()});
/* Fenetre de lecture deplaçable : glisser la barre de titre (double-clic = recentrer). */
let plX=0,plY=0,plDrag=null;
function plApply(){const p=$('#player-modal .player');if(p)p.style.transform='translate('+plX+'px,'+plY+'px)'}
window.resetPlayerPos=function(){plX=0;plY=0;plApply()};
(function(){
 const head=document.querySelector('#player-modal .player-head');if(!head)return;
 head.addEventListener('pointerdown',e=>{
  if(e.target.closest('button'))return;
  plDrag={x:e.clientX,y:e.clientY,ox:plX,oy:plY};
  try{head.setPointerCapture(e.pointerId)}catch(_){}
  document.body.style.userSelect='none';e.preventDefault();
 });
 head.addEventListener('pointermove',e=>{
  if(!plDrag)return;
  plX=plDrag.ox+(e.clientX-plDrag.x);plY=plDrag.oy+(e.clientY-plDrag.y);plApply();
  const r=head.parentElement.getBoundingClientRect();let dx=0,dy=0;
  if(r.left<8)dx=8-r.left;else if(r.right>window.innerWidth-8)dx=(window.innerWidth-8)-r.right;
  if(r.top<0)dy=-r.top;else if(r.bottom>window.innerHeight-8)dy=(window.innerHeight-8)-r.bottom;
  if(dx||dy){plX+=dx;plY+=dy;plApply()}
 });
 const end=()=>{if(plDrag){plDrag=null;document.body.style.userSelect=''}};
 head.addEventListener('pointerup',end);head.addEventListener('pointercancel',end);
 head.addEventListener('dblclick',e=>{if(!e.target.closest('button'))window.resetPlayerPos()});
})();
$('#player-external').onclick=()=>{if(state.currentPlay)api('open_external',state.currentPlay)};
$('#player-folder').onclick=()=>{if(state.currentPlay)api('open_folder',state.currentPlay)};
$('#btn-folder').onclick=async()=>{const d=await api('choose_folder');if(d)$('#dest-path').textContent=d};
$('#btn-folder-top').onclick=()=>$('#btn-folder').click();
$('#btn-paste').onclick=async()=>{try{const t=await navigator.clipboard.readText();if(t)$('#url').value=t.trim()}catch(e){toast('Copiez puis collez (Ctrl+V)')}};
$('#btn-refresh').onclick=refresh;
$('#btn-clear').onclick=async()=>{
 if(state.tab==='log'){
  if(confirm('Vider tout le journal ?')){await api('clear_logs');state.logs=[];applyCounts();render();toast('Journal vidé')}}
 else if(state.tab==='history'){
  if(confirm("Vider tout l'historique ?\n(Les favoris ⭐ sont conservés.)")){await api('clear_history');refresh()}}
 else toast('La mediatheque reflete le dossier')};
$('#btn-info').onclick=async()=>{const u=$('#url').value.trim();if(!u)return toast("Collez une URL d'abord",true);
 setStatus('Analyse du lien…');try{const info=await api('fetch_info',u);$('#preview').classList.remove('hidden');
  $('#preview-title').textContent=info.title||u;$('#preview-meta').textContent=(info.uploader||'')+' • '+(info.duration_string||'')+' • '+(info.extractor||'');
  $('#preview-thumb').src=info.thumbnail||'';setStatus('Pret.')}catch(e){toast('Lien illisible : '+e,true);setStatus('Lien illisible')}};
$('#btn-download').onclick=async()=>{const u=$('#url').value.trim();if(!u)return toast('Collez une URL',true);
 busy($('#btn-download'),1,'⏳ TÉLÉCHARGEMENT…');setBar(2);setStatus('Connexion…');
 try{await api('start_download',{url:u,mode:state.mode,vformat:state.vf,vquality:state.vq,aformat:state.af,aquality:state.aq,silent:state.mode==='video'&&!!state.silent})}
 catch(e){busy($('#btn-download'),0);toast(''+e,true);setStatus(''+e)}};
/* ---- Outils donnees : favoris, statistiques, export, sauvegarde, dossier ---- */
$('#btn-fav').onclick=()=>showFavorites(!state.favOnly);
$('#btn-fav-reset').onclick=()=>showFavorites(false);
/* Nettoyage avance : retire les entrees dont le fichier n'existe plus sur le disque. */
$('#btn-prune-missing').onclick=async()=>{
 if(!confirm("Retirer de l'historique les entrees dont le fichier n'existe plus ?\n(Les favoris sont conserves.)"))return;
 try{const r=await api('prune_history_missing');
  toast((r&&typeof r.removed==='number')?r.removed+' entree(s) retiree(s)':'Nettoyage effectue');
  refresh()}catch(e){toast('Nettoyage impossible : '+e,true)}};
$('#btn-stats').onclick=async()=>{const box=$('#stats-box');
 if(!box.classList.contains('hidden')){box.classList.add('hidden');return}
 box.innerHTML='<div class="empty">Chargement des statistiques…</div>';box.classList.remove('hidden');
 busy($('#btn-stats'),1,'⏳ …');
 try{box.innerHTML=statsHtml(await api('get_stats'))}
 catch(e){box.classList.add('hidden');toast('Stats indisponibles',true)}
 finally{busy($('#btn-stats'),0)}};
$('#btn-export').onclick=async()=>{try{
 const r=await api('export_history');
 if(r&&r.ok){toast('💾 Export JSON : '+String(r.path).split(/[\\/]/).pop());api('open_folder',r.path)}
 else toast('Export impossible',true)}catch(e){toast('Export impossible',true)}};
$('#btn-backup').onclick=async()=>{try{
 const r=await api('backup_db');
 if(r&&r.ok)toast('💾 Sauvegarde : '+String(r.path).split(/[\\/]/).pop()+' ('+fmtSize(r.size)+')');
 else toast('Sauvegarde impossible',true)}catch(e){toast('Sauvegarde impossible',true)}};
$('#btn-data').onclick=()=>{api('open_db_folder').catch(()=>{})};
$('#btn-opt').onclick=async()=>{const btn=$('#btn-opt');busy(btn,1,'⏳ OPTIM…');
 setStatus('Optimisation des données…');
 try{
  const r=await api('optimize_db');setStatus('Pret.');
  if(r&&r.ok)toast('🧰 Données optimisées : '+fmtSize(r.before)+' → '+fmtSize(r.after)+' · intégrité '+(r.integrity||'ok'));
  else toast('Compactage impossible',true)}catch(e){toast('Compactage impossible',true);setStatus('Pret.')}
 finally{busy(btn,0)}};
/* Panneau STATS : tout est calcule cote donnees puis affiche en grille. */
function statsHtml(s){
 const cell=(l,v)=>'<div><span>'+l+'</span><b>'+v+'</b></div>';
 const sites=(s.top_sites||[]).map(x=>esc(String(x.site))+'&nbsp;·&nbsp;'+x.n).join('&nbsp;&nbsp;')||'—';
 const days=(s.daily||[]).slice(-7).map(d=>esc(String(d.day).slice(5))+'&nbsp;'+d.downloads).join('&nbsp;&nbsp;')||'—';
 return '<div class="stats-grid">'
  +cell('📥 TÉLÉCHARGEMENTS',s.downloads+' <small>('+s.video+' vidéo / '+s.audio+' audio)</small>')
  +cell('⭐ FAVORIS',s.favorites)
  +cell('👁 LECTURES',s.plays)
  +cell('📦 VOLUME TÉLÉCHARGÉ',fmtSize(s.bytes))
  +cell('⚠ ERREURS',s.errors)
  +cell('📚 MÉDIATHÈQUE',s.library+' fichiers · '+fmtSize(s.library_bytes))
  +cell('🗄 STOCKAGE LOCAL',fmtSize(s.db_size))
  +cell('🗂 JOURNAL',s.logs+' lignes')
  +cell('🕘 DERNIER TÉLÉCHARGEMENT',esc(String(s.last||'—')))
  +cell('🌐 SITES',sites)
  +cell('📅 7 DERNIERS JOURS',days)
  +cell('📂 DOSSIER',esc(String(s.download_dir||'—')))
  +'</div>'}
document.addEventListener('pywebviewready',boot);
window.addEventListener('load',()=>setTimeout(()=>{if(!state.history.length&&!state.library.length)boot()},700));
/* ---- Mentions legales : createur Dane hk \Manifest, licence MIT + mise a jour integree ---- */
let updBusy=false,updArmTimer=null;
function updStatus(txt,err){const el=$('#update-status');if(!el)return;el.textContent=txt||'';el.classList.toggle('err',!!err)}
let legalDone=false;
async function openLegal(){
 $('#legal-modal').classList.remove('hidden');
 if(legalDone)return;legalDone=true;
 try{const v=await api('get_version');
  $('#legal-version').textContent=(v.name||'CHAPE-MEDIA')+' v'+(v.display_version||v.app_version||v.version||'?')+(v.installed_package?'':' — mode sources');
  if(v.installed_package&&v.writable===false)updStatus("Dossier programme protege : déplacez l'application dans un dossier personnel pour qu'elle puisse se mettre à jour.",true);
  else if(v.installed_package)updStatus('Source du manifeste : '+(v.update_url||v.source||'non configurée'));
  else updStatus('Mode sources : la mise à jour automatique ne remplace que la version installée (.exe)');
 }catch(e){}
}
$('#btn-legal').onclick=openLegal;
$('#legal-close').onclick=()=>$('#legal-modal').classList.add('hidden');
$('#legal-modal').addEventListener('click',e=>{if(e.target.id==='legal-modal')$('#legal-close').click()});
/* Verification : lit le manifeste publie (version + SHA-256 du paquet) puis telecharge en fond.
   L'installation reste volontaire : deux clics -> l'app se ferme, le script remplace les
   fichiers (avec retour arriere automatique) et redemarre. */
$('#btn-update-check').onclick=async e=>{
 const b=e.currentTarget;if(updBusy)return;updBusy=true;busy(b,1,'⏳ Vérification…');
 updStatus('Contact du serveur de mise à jour…');
 try{
  const r=await api('check_update');
  if(!r.ok)updStatus('Vérification impossible : '+(r.error||'serveur injoignable'),true);
  else if(r.available){updStatus('Version '+(r.latest||'?')+' disponible (installée : '+r.current+') — téléchargement…');
   const d=await api('download_update');if(d&&d.ok===false)updStatus(d.error||'Téléchargement impossible',true)}
  else updStatus('À jour : version '+(r.current||'?')+(r.latest?' (publiée : '+r.latest+')':' (aucune publication connue)'));
 }catch(err){updStatus('Interface indisponible',true)}
 busy(b,0);updBusy=false};
$('#btn-update-install').onclick=async e=>{
 const b=e.currentTarget;if(updBusy)return;
 if(b.dataset.arm!=='1'){
  b.dataset.arm='1';busy(b,1,'⚠️ Confirmer (l\'app va redémarrer)');
  clearTimeout(updArmTimer);updArmTimer=setTimeout(()=>{b.dataset.arm='0';busy(b,0)},8000);
  return}
 b.dataset.arm='0';updBusy=true;busy(b,1,'⏳ Installation…');
 try{const r=await api('install_update',true);
  if(r&&r.ok){updStatus("Installation lancée : CHAPE-MEDIA se ferme et redémarre sur la version "+((r.version)||'')+'…');toast('Mise à jour en cours…')}
  else{updStatus((r&&r.error)||'Installation impossible',true);busy(b,0);updBusy=false}}
 catch(err){updStatus('Interface indisponible',true);busy(b,0);updBusy=false}};

/* ---- Profil utilisateur : nom + photo, affiches dans le bandeau et modifiables ----
   Le nom est stocke en base, la photo est copiee dans APP_DATA/profile par le backend
   (set_profile copie le fichier choisi, l'interface ne transmet qu'un chemin local). */
function applyProfile(p){
 if(!p)return;
 const name=(p.name||'').trim();
 const photo=p.photo||'';
 const btnName=$('#profile-name');
 if(btnName)btnName.textContent=name||'PROFIL';
 const av=$('#profile-avatar');
 if(av){if(photo){av.src=photo;av.classList.remove('hidden')}else{av.src='icon.svg';av.classList.add('hidden')}}
}
let profileLoaded=false;
async function openProfile(){
 $('#profile-modal').classList.remove('hidden');
 try{
  const p=await api('get_profile');
  $('#profile-name-input').value=(p.name||'');
  $('#profile-preview').src=p.photo||'icon.svg';
  profileLoaded=true;
 }catch(e){toast('Profil indisponible',true)}}
$('#btn-profile').onclick=openProfile;
$('#profile-close').onclick=()=>$('#profile-modal').classList.add('hidden');
$('#profile-modal').addEventListener('click',e=>{if(e.target.id==='profile-modal')$('#profile-close').click()});
$('#profile-photo-input').addEventListener('change',e=>{
 const f=e.target.files&&e.target.files[0];
 if(f){
  // apercu immediate : on affiche le fichier choisi avant l'enregistrement
  try{$('#profile-preview').src=URL.createObjectURL(f)}catch(_){}
  $('#profile-preview').dataset.pending=f.name}});
$('#profile-save').onclick=async e=>{
 const b=e.currentTarget;if(b.dataset.busy)return;b.dataset.busy='1';busy(b,1,'⏳ …');
 try{
  const name=$('#profile-name-input').value.trim();
  const file=$('#profile-photo-input').files&&$('#profile-photo-input').files[0];
  let photoPath='';
  if(file){
   // pywebview (EdgeChromium) expose window.pywebview.api ; ici on passe par un
   // chemin : le navigateur ne donne pas le chemin reel d'un fichier, on copie
   // donc l'image dans les donnees de l'app via une data-url cote Python.
   const dataUrl=await new Promise(res=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>res('');r.readAsDataURL(file)});
   if(dataUrl){
    const r2=await api('save_profile_photo',dataUrl);
    if(r2&&r2.ok)photoPath=r2.path;
    else toast((r2&&r2.error)||'Photo non enregistree',true)}}
  const p=await api('set_profile',name,photoPath);
  applyProfile(p);
  $('#profile-modal').classList.add('hidden');
  $('#profile-photo-input').value='';
  $('#profile-preview').dataset.pending='';
  toast(name?('Profil enregistré : '+name):'Profil enregistré');
 }catch(err){toast('Enregistrement impossible',true)}
 finally{b.dataset.busy='0';busy(b,0)}};
// chargement initial du profil au demarrage de l'interface
api('get_profile').then(applyProfile).catch(()=>{});

/* ---- Lecture en boucle ----
   Toggle actif : le média courant redemarre automatiquement a la fin (video ou audio).
   L'etat est conservé d'un média au suivant dans la session. */
let loopOn=!!window.DNA_LOOP;
$('#player-loop').onclick=()=>{
 loopOn=!loopOn;window.DNA_LOOP=loopOn;
 const v=$('#video-el'),a=$('#audio-el');
 v.loop=loopOn;a.loop=loopOn;
 $('#player-loop').textContent=loopOn?'🔁 BOUCLE : OUI':'🔁 BOUCLE : NON';
 $('#player-loop').classList.toggle('active',loopOn);
 toast(loopOn?'Lecture en boucle activée':'Lecture en boucle désactivée')};

/* ---- Partage par lien (appareils sur le même réseau / même navigateur) ----
   Le backend cree une URL http://<IP-LAN>:<port>/media?path=... ouverte dans le
   navigateur par defaut : n'importe quel appareil du réseau peut la consommer. */
let currentSharePath='';
window.setCurrentSharePath=function(p){currentSharePath=p||'';
 const el=$('#share-link');el.textContent='';el.classList.add('hidden')};
$('#player-share').onclick=async e=>{
 const b=e.currentTarget;if(b.dataset.busy)return;b.dataset.busy='1';
 try{
  const r=await api('share_media',currentSharePath);
  if(r&&r.ok){
   const el=$('#share-link');el.textContent=r.url;el.classList.remove('hidden');
   try{await navigator.clipboard.writeText(r.url);toast('Lien copié dans le presse-papiers')}
   catch(_){toast('Lien créé : '+r.url)}
   window.open(r.url,'_blank');
  }else toast((r&&r.error)||'Partage impossible',true);
 }catch(err){toast('Partage indisponible',true)}
 finally{b.dataset.busy='0'}};

/* ---- Raccourcis clavier ----
   Entrée  : lance le telechargement depuis le champ URL
   /       : focus sur la recherche (hors champ de saisie)
   Echap   : ferme le lecteur, puis les mentions, puis le panneau STATS ---- */
$('#url').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('#btn-download').click()}});
document.addEventListener('keydown',e=>{
 const t=e.target,typing=t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA');
 if(e.key==='Escape'){
  if(!$('#player-modal').classList.contains('hidden'))$('#player-close').click();
  else if(!$('#legal-modal').classList.contains('hidden'))$('#legal-close').click();
  else if(!$('#stats-box').classList.contains('hidden'))$('#btn-stats').click();}
 else if(e.key==='/'&&!typing){e.preventDefault();$('#search').focus()}
 else if(e.key==='Enter'&&t===$('#search')){e.preventDefault();onSearch()}});
