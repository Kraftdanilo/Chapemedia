/* CHAPE-MEDIA 1.0.4 remix — micro-couche UX non-destructive.
   Aucun id existant renommé, aucune API ajoutée : embellit + fiabilise. */
(function(){
'use strict';
function $(s){return document.querySelector(s)}
/* 1. Badge version dynamique : affiche la version servie par le backend
      (display_version = "1.0.4 remix"), repli sur le texte statique. */
function paintVersion(v){
  var badge=$('#app-version-badge');if(!badge)return;
  var txt=(v&&(v.display_version||(v.app_version+(v.edition?' '+v.edition:''))))||'';
  if(txt)badge.textContent='v'+txt;
}
function fetchVersion(){
  if(!window.pywebview||!window.pywebview.api||!window.pywebview.api.get_version)return;
  window.pywebview.api.get_version().then(paintVersion).catch(function(){});
}
document.addEventListener('pywebviewready',function(){setTimeout(fetchVersion,400)});
window.addEventListener('load',function(){setTimeout(fetchVersion,1200)});
/* 2. Boucle persistante : l'état survit au changement de média.
      openPlayer() réapplique window.DNA_LOOP ; le toggle reste la source. */
window.DNA_LOOP=!!window.DNA_LOOP;
function syncLoopBtn(){
  var b=$('#player-loop');if(!b)return;
  b.textContent=window.DNA_LOOP?'🔁 BOUCLE : OUI':'🔁 BOUCLE : NON';
  b.classList.toggle('active',window.DNA_LOOP);
}
document.addEventListener('click',function(e){
  if(e.target&&e.target.id==='player-loop'){
    setTimeout(function(){
      try{
        var on=$('#player-loop').classList.contains('active')
          ||$('#player-loop').textContent.indexOf('OUI')>=0;
        window.DNA_LOOP=on;
        var v=$('#video-el'),a=$('#audio-el');
        if(v)v.loop=on;if(a)a.loop=on;
      }catch(_){}
    },0);
  }
});
/* 3. Avatar : accepte les chemins Windows bruts (file:///) + repli icône. */
function fixAvatar(img){
  if(!img||img.dataset.remixOk)return;img.dataset.remixOk='1';
  img.addEventListener('error',function(){img.src='icon.svg'},{once:true});
  var src=img.getAttribute('src')||'';
  if(/^[A-Za-z]:\\/.test(src))img.src='file:///'+src.replace(/\\/g,'/');
}
new MutationObserver(function(muts){
  muts.forEach(function(m){
    m.addedNodes.forEach(function(n){
      if(n.querySelectorAll)n.querySelectorAll('#profile-avatar,#profile-preview').forEach(fixAvatar);
    });
    if(m.type==='attributes'&&(m.target.id==='profile-avatar'||m.target.id==='profile-preview'))fixAvatar(m.target);
  });
}).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});
['#profile-avatar','#profile-preview'].forEach(function(s){var el=$(s);if(el)fixAvatar(el)});
/* 4. Port média effectif : stocké au boot pour des vignettes stables. */
document.addEventListener('pywebviewready',function(){
  setTimeout(function(){
    try{
      if(window.pywebview&&window.pywebview.api&&window.pywebview.api.get_config)
        window.pywebview.api.get_config().then(function(cfg){
          if(cfg&&cfg.media_port&&window.state)window.state.mediaPort=cfg.media_port;
        }).catch(function(){});
    }catch(_){}
  },600);
});
syncLoopBtn();
})();
