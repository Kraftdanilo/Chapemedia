/* Refresh : les appels partent EN PARALLELE (l'interface est multithread) et la
   mediatheque est servie par l'index local synchronise avec le disque, sauf demande
   explicite (clic sur Actualiser). */
async function refresh(force){try{
 const wantLogs=state.tab==='log';
 /* Mode favoris : une seule requete renvoie l'historique ET la mediatheque filtres */
 const jobs=[state.favOnly?api('get_favorites'):api('get_history',150,false),api('scan_library',!!force)];
 if(wantLogs)jobs.push(api('get_logs',200));
 const [first,lib,logs]=await Promise.all(jobs);
 if(state.favOnly){state.history=(first&&first.history)||[];state.library=(first&&first.library)||[]}
 else{state.history=first||[];state.library=lib||[]}
 if(wantLogs)state.logs=logs||[];
 state.refreshFails=0;
 /* Apres un telechargement : on ramene l'utilisateur sur l'historique, on vide la
    recherche et on fait clignoter la nouvelle ligne -> il voit SA video tout de suite. */
 if(state.lastDoneTitle){
  const want=state.lastDoneTitle;state.lastDoneTitle=null;
  if(state.tab!=='history')selectTab('history');
  if($('#search').value)$('#search').value='';
  /* Un filtre avance actif (erreurs, manquants, 24 h...) masquerait la nouvelle ligne :
     on revient a TOUS pour etre sur que l'utilisateur voit son telechargement. */
  if(state.hf!=='all'){state.hf='all';$$('#hist-filters button[data-hf]').forEach(z=>z.classList.toggle('active',z.dataset.hf==='all'));}
  const top=state.history[0];
  if(top&&top.title===want){state.flashId=top.id;clearTimeout(refresh._flashT);
   refresh._flashT=setTimeout(()=>{state.flashId=null;render()},9000)}
 }
 syncFavBanner();applyCounts();shown=PAGE;render()
 }catch(e){
  /* Plus jamais de liste vide silencieuse : on annonce, on journalise, on retente. */
  console.error('refresh:',e);state.refreshFails=(state.refreshFails||0)+1;
  if(state.refreshFails===1)toast('Actualisation impossible : nouvelle tentative…',true);
  if(state.refreshFails<=3)setTimeout(()=>refresh(true),800);
 }}
/* Bascule programmatique d'onglet (meme logique que le clic utilisateur). */
function selectTab(name){const b=$$('.tabs button[data-tab]').find(z=>z.dataset.tab===name);if(b)b.click()}
/* Bandeau "filtre favoris actif" : l'utilisateur ne doit jamais se retrouver avec
   deux listes vides sans savoir pourquoi. */
function syncFavBanner(){const b=$('#fav-banner');if(b)b.classList.toggle('hidden',!state.favOnly)}
function applyCounts(){$('#count-hist').textContent=state.history.length;
 $('#count-lib').textContent=state.library.length;$('#count-log').textContent=(state.logs||[]).length;
 if($('#hf-count'))$('#hf-count').textContent=state.tab==='history'
  ?(histFilter(state.history).length+' / '+state.history.length):''}
/* Filtre ⭐ FAVORIS : historique et mediatheque viennent filtres par la base. */
async function showFavorites(on){
 state.favOnly=!!on;$('#btn-fav').classList.toggle('on',state.favOnly);
 await refresh(true);
 if(state.favOnly)toast('⭐ Favoris : '+state.history.length+' telechargement(s), '+state.library.length+' fichier(s)')}
function currentList(){return state.tab==='history'?state.history:(state.tab==='library'?state.library:(state.logs||[]))}
function searchable(it){return state.tab==='log'
 ?((it.message||'')+' '+(it.level||'')+' '+(it.ctx||'')).toLowerCase()
 :((it.title||'')+' '+(it.format||'')+' '+(it.ext||'')+' '+(it.uploader||'')).toLowerCase()}
/* Filtres avances de l'historique (TOUS / 24 h / 7 jours / erreurs / fichier manquant).
   Appliques en local sur les lignes deja chargees : aucun appel reseau, rendu immediat. */
function histFilter(src){
 const f=state.hf||'all';
 if(f==='all')return src;
 const now=Date.now()/1000;
 const d=new Date();d.setHours(0,0,0,0);const d0=d.getTime()/1000;
 return src.filter(it=>{
  if(f==='today')return (it.created_at||0)>=d0;
  if(f==='7d')return (it.created_at||0)>=now-604800;
  if(f==='errors'){const s=(it.status||'').toLowerCase();return !!it.error||s.startsWith('erreur')||s.startsWith('error')}
  if(f==='missing')return it.present===false;
  return true})}
function filtered(){const q=$('#search').value.trim().toLowerCase();const src=currentList();
 if(!q||state.tab==='history')return histFilter(src);   /* historique : recherche deja filtree cote donnees */
 return src.filter(i=>searchable(i).includes(q))}
function star(it){return '<button class="icon-btn star'+(it.favorite?' on':'')+'" data-act="fav" data-id="'
 +esc(it.id||('lib:'+it.path))+'" title="'+(it.favorite?'Retirer des favoris':'Ajouter aux favoris ⭐')+'">'
 +(it.favorite?'★':'☆')+'</button>'}
function plays(it){return it.plays>0?'<span class="badge sun">👁 '+it.plays+'</span> ':''}
function rowHtml(it){const isH=state.tab==='history';const id=isH?it.id:('lib:'+it.path);
 /* Badge d'etat : erreur / fichier manquant / OK (le titre porte le detail complet). */
 const st=String(it.status||'OK');const err=!!it.error||/^erreur|^error/i.test(st);
 const stBadge=isH?(err?'<span class="badge sun" title="'+esc(st)+'">⚠ ERREUR</span>'
  :(it.present===false?'<span class="badge warn" title="Fichier absent du disque">🗑 MANQUANT</span>'
   :'<span class="badge" title="'+esc(st)+'">✅ OK</span>'))
  :'<span class="badge">'+esc(fmtSize(it.size))+'</span>';
 const fresh=isH&&state.flashId!=null&&String(it.id)===String(state.flashId)?' fresh':'';
 return '<div class="item'+fresh+'">'+(it.thumbnail?'<img src="'+esc(it.thumbnail)+'" loading="lazy" decoding="async" referrerpolicy="no-referrer">':'<img alt="">')+'<div class="meta"><h4 title="'+esc(it.title)+'">'+esc(it.title||'(sans titre)')+'</h4><p><span class="badge">'+esc((it.ext||it.format||'').toUpperCase())+'</span> '+stBadge+' '+plays(it)+'<span>'+esc(isH?(it.date||''):fmtDate(it.mtime))+'</span></p><div class="row">'+star(it)+'<button class="icon-btn" data-act="play" data-id="'+esc(id)+'">Lire</button><button class="icon-btn" data-act="open" data-id="'+esc(id)+'">Ouvrir</button><button class="icon-btn" data-act="folder" data-id="'+esc(id)+'">Dossier</button>'+(String(it.ext||'').toLowerCase().match(/^(mp4|mkv|webm|mov|m4v)$/)?'<button class="icon-btn" data-act="mute" data-id="'+esc(id)+'" title="Créer une copie sans son (original conservé)">🔇 Muet</button>':'')+(isH?'<button class="icon-btn" data-act="retry" data-id="'+esc(id)+'">Reessayer</button><button class="icon-btn" data-act="del" data-id="'+esc(id)+'">Suppr</button>':'<button class="icon-btn" data-act="dellib" data-id="'+esc(id)+'">Suppr</button>')+'</div></div></div>'}
/* Onglet JOURNAL : une ligne par evenement enregistre dans le journal. */
function logHtml(it){return '<div class="item log-item lvl-'+esc(it.level||'info')+'"><div class="meta"><h4>'+esc(it.message||'')+'</h4><p><span class="badge '+(it.level==='error'?'sun':'')+'">'+esc((it.level||'info').toUpperCase())+'</span> <span>'+esc(fmtStamp(it.ts))+'</span></p>'+(it.ctx?'<p class="ctx" title="'+esc(it.ctx)+'">'+esc(it.ctx)+'</p>':'')+'</div></div>'}
function fmtStamp(t){try{return new Date(t*1000).toLocaleString('fr-FR')}catch(e){return ''}}
/* Delegation d'evenements : 1 seul listener pour toutes les lignes (au lieu de ~150 closures
   recreees a chaque rendu) -> rendu plus rapide et moins de travail pour le garbage collector. */
$('#list').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.id==='more'){shown+=PAGE;render();return}
 if(b.dataset&&b.dataset.act)onItem(b.dataset.act,b.dataset.id)});
/* Barre de filtres de l'historique : rendu immediat, compteur mis a jour. */
$('#hist-filters').addEventListener('click',e=>{const b=e.target.closest('button[data-hf]');if(!b)return;
 state.hf=b.dataset.hf;
 $$('#hist-filters button[data-hf]').forEach(z=>z.classList.toggle('active',z===b));
 shown=PAGE;render();applyCounts()});
function render(){const box=$('#list');const arr=filtered();
 if(!arr.length){const q=$('#search').value.trim();box.innerHTML='<div class="empty">'
  +(q?'Aucun résultat pour <q>'+esc(q)+'</q>.<br>Essayez un autre mot.'
    :(state.favOnly?'Aucun favori ⭐ pour le moment.<br>Cliquez sur ☆ dans une ligne.'
    :(state.tab==='log'?'Journal vide.<br>Les telechargements et les operations apparaitront ici.'
    :(state.hf&&state.hf!=='all'?'Aucune entree avec ce filtre.<br>'
    :'Rien ici pour le moment.<br>Lancez un telechargement !'))))
  +((!q&&!state.favOnly)?'<p style="margin-top:10px"><button class="icon-btn" data-act="retry-list">🔄 Actualiser</button></p>':'')
  +'</div>';render._last=null;return}
 const slice=arr.slice(0,shown);
 const isLog=state.tab==='log';
 const out=new Array(slice.length);
 for(let i=0;i<slice.length;i++)out[i]=isLog?logHtml(slice[i]):rowHtml(slice[i]);
 let html=out.join('');
 if(arr.length>shown)html+='<button id="more" class="btn nb-btn" style="width:100%">+ AFFICHER PLUS ('+(arr.length-shown)+' RESTANTS)</button>';
 /* Rien n'a change au dernier refresh : on ne touche pas au DOM (le scroll est conserve). */
 if(html===render._last)return;
 const prevTop=box.scrollTop;
 box.innerHTML=html;render._last=html;
 if(prevTop>0)box.scrollTop=Math.min(prevTop,box.scrollHeight-box.clientHeight)}
function fmtSize(n){if(!n&&n!==0)return '—';const u=['o','Ko','Mo','Go'];let i=0;while(n>=1024&&i<3){n/=1024;i++}return n.toFixed(1)+' '+u[i]}
function fmtDate(t){try{return new Date(t*1000).toLocaleString('fr-FR')}catch(e){return ''}}
/* Vignette servie par le cache local (~/.chape_media/thumbs) : plus de hotlink casse,
   telechargee une seule fois puis servie par le serveur local (cache navigateur 7 j). */
function thumbUrl(u){if(!u)return '';try{return 'http://127.0.0.1:'+(state.mediaPort||8899)+'/thumb?url='+encodeURIComponent(u)}catch(e){return u}}
async function onItem(act,id){
 if(act==='retry-list'){refresh(true);toast('Actualisation…');return}
 if(act==='fav'){const v=await api('toggle_favorite',String(id),null);
  const isH=!String(id).startsWith('lib:');
  const row=(isH?state.history:state.library).find(x=>String(isH?x.id:('lib:'+x.path))===String(id));
  if(row)row.favorite=!!v;
  toast(v?'⭐ Ajoute aux favoris':'Favori retire');
  if(state.favOnly)showFavorites(true);else{render();refresh()}
  return}
 if(act==='del'){if(confirm('Retirer ce telechargement de l historique ?\n(Les favoris seront aussi retires.)')){await api('delete_history',String(id));refresh()}return}
 if(act==='dellib'){if(confirm('Supprimer ce fichier du disque ?')){await api('delete_file',String(id).slice(4));refresh()}return}
 if(act==='mute'){
  const isL=String(id).startsWith('lib:');
  let p=null;
  if(isL){p=String(id).slice(4)}
  else{const h=state.history.find(x=>String(x.id)===String(id));if(h)p=h.filepath}
  if(!p)return toast('Fichier introuvable',true);
  if(!confirm('Créer une copie SANS son de cette vidéo ?\n(L\'original avec son est conservé.)'))return;
  toast('🔇 Suppression du son en cours…');
  try{const r=await api('remove_audio',p);
   if(r&&r.ok){setStatus('Suppression du son en cours…')}else toast((r&&r.error)||'Suppression du son impossible',true)}
  catch(e){toast('Suppression du son impossible : '+e,true)}
  return}
 let path=null,title='';
 if(String(id).startsWith('lib:')){path=String(id).slice(4);title=path.split(/[/\\]/).pop()}
 else{const h=state.history.find(x=>String(x.id)===String(id));if(!h)return;path=h.filepath;title=h.title;
  if(act==='retry'){$('#url').value=h.url||'';toast('URL remise dans le champ');return}}
 if(!path){toast('Fichier introuvable',true);return}
 if(act==='folder'){api('open_folder',path);return}
 if(act==='open'){api('open_external',path);return}
 markPlayed(id);                      /* compteur de lectures enregistre localement */
 if(!state.playerEnabled){api('open_external',path);return}
 openPlayer(path,title)}
/* Compteur de lectures : incremente localement, puis mis a jour a l'ecran sans rechargement. */
function markPlayed(id){api('mark_played',String(id)).catch(()=>{});
 const isH=!String(id).startsWith('lib:');
 const row=(isH?state.history:state.library).find(x=>String(isH?x.id:('lib:'+x.path))===String(id));
 if(row){row.plays=(row.plays||0)+1;render()}}
async function openPlayer(path,title){
 try{const url=await api('media_url',path);$('#player-title').textContent=title||'Lecture';
  const v=$('#video-el'),a=$('#audio-el');v.pause();a.pause();v.removeAttribute('src');a.removeAttribute('src');
  const audioExt=['mp3','m4a','opus','ogg','wav','flac','aac','wma'];const ext=(path.split('.').pop()||'').toLowerCase();
  const isAudio=audioExt.includes(ext);
  (isAudio?a:v).classList.remove('hidden');(isAudio?v:a).classList.add('hidden');
   const el=isAudio?a:v;try{el.loop=!!window.DNA_LOOP}catch(e){}
  (isAudio?a:v).src=url;$('#player-modal').classList.remove('hidden');if(window.resetPlayerPos)resetPlayerPos();(isAudio?a:v).play().catch(()=>{});
  state.currentPlay=path;
  if(window.setCurrentSharePath)window.setCurrentSharePath(path);
 }catch(e){toast('Lecture impossible, ouverture externe',true);api('open_external',path)}}
