/* Tabs + search + player switch + render pagine */
const PAGE=30;let shown=PAGE,searchT=null;
$$('.tabs button[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;shown=PAGE;
 $$('.tabs button[data-tab]').forEach(z=>z.classList.toggle('active',z===b));
 $('#hist-filters').classList.toggle('hidden',state.tab!=='history');
 $('#search').placeholder=state.tab==='log'?'🔎 FILTRER LE JOURNAL…'
  :(state.tab==='library'?'🔎 RECHERCHER DANS LA MÉDIATHÈQUE…':'🔎 RECHERCHER TITRE, FORMAT…');
 /* le journal vit en base : on va le chercher a la demande (jamais au boot) */
 if(state.tab==='log'&&!state.logs.length)
  api('get_logs',200).then(r=>{state.logs=r||[];applyCounts();render()}).catch(()=>{});
 render()});
/* Recherche : pour l'historique la recherche se fait cote donnees (accents et casse
   ignores, resultats instantanes) ; mediatheque et journal sont filtres en local. */
$('#search').addEventListener('input',()=>{clearTimeout(searchT);searchT=setTimeout(onSearch,180)});
async function onSearch(){
 const q=$('#search').value.trim();
 if(state.tab==='history'&&q.length>=2){
  try{
   if(state.favOnly){            /* mode favoris : on ne sort pas du filtre actif */
    const f=(await api('get_favorites'))||{};const k=q.toLowerCase();
    state.history=(f.history||[]).filter(i=>((i.title||'')+' '+(i.ext||'')+' '+(i.uploader||'')).toLowerCase().includes(k))}
   else state.history=(await api('search_history',q,200))||[];
   applyCounts();shown=PAGE;render();
   setStatus('Recherche : '+state.history.length+' résultat(s)')}catch(e){console.error('search:',e);toast('Recherche impossible',true)}
  return}
 if(state.tab==='history'&&!q){refresh();return}
 shown=PAGE;render()}
$('#toggle-player').onclick=e=>{const b=e.currentTarget;state.playerEnabled=!state.playerEnabled;b.classList.toggle('on',state.playerEnabled);b.setAttribute('aria-pressed',state.playerEnabled);api('set_player_enabled',state.playerEnabled).catch(()=>{});toast(state.playerEnabled?'Lecture integree activee':'Lecture integree coupee (ouverture externe)')};
async function api(name,...args){if(!window.pywebview||!window.pywebview.api){if(name!=='poll_events')toast('Interface non prête',true);throw 'no-bridge'}return await window.pywebview.api[name](...args)}
function esc(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
/* Polling intelligent : long-polling cote application (wait_ms).
   - au repos : 1 seul appel toutes les ~20 s (0 CPU consomme dans le vide)
   - pendant un telechargement : reprise immediate a chaque lot d'evenements
   - fenetre cachee : plus aucun appel, puis resync au retour */
let pollTimer=null,pollBusy=false,pollStop=false;
function pollSoon(ms){clearTimeout(pollTimer);pollTimer=setTimeout(poll,Math.max(0,ms))}
async function poll(){
 if(pollBusy||pollStop)return;
 pollBusy=true;let gap=state.downloading?150:400;
 try{const ev=await api('poll_events',state.downloading?1200:20000);const arr=ev||[];
  for(let i=0;i<arr.length;i++)handleEvent(arr[i]);
  if(arr.length)gap=state.downloading?120:10}
 catch(e){gap=800}
 finally{pollBusy=false}
 if(!pollStop)pollSoon(gap)}
poll();
document.addEventListener('visibilitychange',()=>{pollStop=document.hidden;if(pollStop){clearTimeout(pollTimer)}else{refresh();poll()}});
function handleEvent(ev){
 if(ev.type==='progress'){state.downloading=true;setBar(ev.pct||0);if(!handleEvent._l||Date.now()-handleEvent._l>500){handleEvent._l=Date.now();setStatus('Telechargement '+(ev.pct||0).toFixed(1)+'% '+(ev.speed||''))}}
 else if(ev.type==='status'){setStatus(ev.text||'');if(ev.pct!=null)setBar(ev.pct)}
 else if(ev.type==='done'){state.downloading=false;setBar(100);setStatus('Termine : '+(ev.title||''));toast('Termine '+(ev.title||''));busy($('#btn-download'),0);state.lastDoneTitle=ev.title||'';refresh()}
 else if(ev.type==='error'){state.downloading=false;setStatus('Erreur '+(ev.message||''));toast('Erreur '+(ev.message||''),true);busy($('#btn-download'),0);refresh()}
 else if(ev.type==='update'){
  /* Mise a jour : progression dans le bloc Mentions legales, jamais dans la barre principale
     (sinon un telechargement de paquet serait confondu avec un telechargement de media). */
  const st=ev.stage||'';
  if(st==='downloading')updStatus((ev.text||'Téléchargement')+' '+Math.round(ev.pct||0)+' %');
  else if(st==='preparing')updStatus('Décompression du paquet…');
  else if(st==='ready'){updStatus('Version '+(ev.version||'')+' vérifiée : prête à installer');const b=$('#btn-update-install');if(b)b.classList.remove('hidden');toast('Mise à jour '+(ev.version||'')+' disponible')}
  else if(st==='uptodate')updStatus(ev.text||'Vous utilisez la dernière version');
  else if(st==='available'){updStatus('Version '+(ev.version||'')+' disponible — cliquez sur « Vérifier les mises à jour »');toast('Mise à jour '+(ev.version||'')+' disponible')}
  else if(st==='error')updStatus(ev.text||'Erreur de mise à jour',true);
  else updStatus(ev.text||'');
 }
}
async function boot(){try{const cfg=await api('get_config');$('#dest-path').textContent=cfg.download_dir||'…';if(cfg.player_enabled!=null){state.playerEnabled=!!cfg.player_enabled;$('#toggle-player').classList.toggle('on',state.playerEnabled)}}catch(e){}
 refresh();setTimeout(()=>{try{if(!document.hidden&&$('#url')!==document.activeElement)$('#url').focus()}catch(e){}},200)}
