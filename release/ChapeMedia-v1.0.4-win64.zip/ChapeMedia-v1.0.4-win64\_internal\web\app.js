/* CHAPE-MEDIA - frontend */
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={mode:'video',vf:'mp4',vq:'best',af:'mp3',aq:'192',silent:false,tab:'history',playerEnabled:true,history:[],library:[],logs:[],favOnly:false,hf:'all',flashId:null,lastDoneTitle:null,refreshFails:0,currentPlay:null};
function toast(m,err=false){const d=document.createElement('div');d.className='toast'+(err?' err':'');d.setAttribute('role','status');d.textContent=m;$('#toasts').appendChild(d);setTimeout(()=>d.remove(),3800)}
/* Etat "occupe" d'un bouton : desactivation + libelle provisoire, restauration auto. */
function busy(btn,on,label){if(!btn)return;if(on){if(btn.dataset.lbl==null)btn.dataset.lbl=btn.textContent;btn.disabled=true;if(label)btn.textContent=label}else{btn.disabled=false;if(btn.dataset.lbl!=null)btn.textContent=btn.dataset.lbl}}
function setBar(p){$('#bar').style.width=Math.max(0,Math.min(100,p))+'%'}
function setStatus(t){$('#status').textContent=t}
/* ---- fond anime ECO : respecte ?eco=1 / memoire faible, 45% opacite via CSS ---- */
(function(){const c=$('#bg-canvas');if(!c)return;
const QS=new URLSearchParams(location.search);
const ECO=QS.has('eco')||QS.get('lite')==='1'||(navigator.deviceMemory&&navigator.deviceMemory<=4);
let N=ECO?14:46;
try{const v=parseInt(localStorage.getItem('dna_eco_n')||'0');if(v>0)N=Math.min(v,ECO?18:60)}catch(e){}
const x=c.getContext('2d',{alpha:true});let W,H,run=true;
function rs(){const dpr=ECO?1:Math.min(devicePixelRatio||1,1.5);W=innerWidth;H=innerHeight;c.width=W*dpr|0;c.height=H*dpr|0;x.setTransform(dpr,0,0,dpr,0,0)}
addEventListener('resize',rs);rs();
const SUN=['#ff5a3c','#ff8a5b','#c81e1e'],TREE=['#2d6a4f','#74c69d','#16442e'],BLACK='#111510';
const P=[];for(let i=0;i<N;i++)P.push({x:Math.random()*2200,y:Math.random()*1400,s:8+Math.random()*24,vx:-.2-Math.random()*.4,vy:-.1-Math.random()*.3,r:Math.random()*6.28,vr:(Math.random()-.5)*.02,k:i%4,sun:Math.random()>.42,o:.4+Math.random()*.6});
function frame(){x.clearRect(0,0,W,H);
for(const p of P){p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;
if(p.x<-40){p.x=W+40;p.y=Math.random()*H}if(p.y<-40){p.y=H+40;p.x=Math.random()*W}
const col=p.sun?SUN[p.s%3|0]:TREE[p.s%3|0];x.globalAlpha=p.o;
const px=p.x%W,py=p.y%H;
if(p.k===0){x.strokeStyle=col;x.lineWidth=3;x.beginPath();x.moveTo(px-p.s*.5,py);x.lineTo(px+p.s*.5,py);x.moveTo(px,py-p.s*.5);x.lineTo(px,py+p.s*.5);x.stroke()}
else if(p.k===1){x.save();x.translate(px,py);x.rotate(p.r);x.fillStyle=col;x.beginPath();x.moveTo(0,-p.s*.6);x.lineTo(p.s*.55,p.s*.45);x.lineTo(-p.s*.55,p.s*.45);x.closePath();x.fill();x.restore()}
else if(p.k===2){x.lineWidth=3;x.strokeStyle=col;x.beginPath();x.arc(px,py,p.s*.45,0,7);x.stroke()}
else{x.save();x.translate(px,py);x.rotate(p.r);x.fillStyle=col;x.fillRect(-p.s/2,-p.s/2,p.s,p.s);x.restore()}}
x.globalAlpha=1}
let last=0;
/* Delai sans interaction avant de considers la fenetre « au repos ». */
const IDLE_MS=15000;
/* Cadence adaptative : le fond ralentit pendant un telechargement ou la lecture d'une video
   pour laisser 100% du CPU au moteur de telechargement (le rendu reste fluide visuellement).
   RAM/CPU : inactif (aucun clic ni mouvement de souris depuis IDLE_MS), le fond passe en
   tres basse frequence - c'est l'etat de repos reel d'une fenetre laissee ouverte. */
const modalEl=$('#player-modal');
let lastAct=Date.now();
addEventListener('pointermove',()=>{lastAct=Date.now()},{passive:true});
addEventListener('keydown',()=>{lastAct=Date.now()});
addEventListener('pointerdown',()=>{lastAct=Date.now()});
function stepMs(){
  if(state.downloading||(modalEl&&!modalEl.classList.contains('hidden')))return ECO?180:100;
  if(Date.now()-lastAct>IDLE_MS)return ECO?900:500;   // fenetre inactive : 2 a 5 images/s
  return ECO?66:33;
}
/* Fenetre masquee : on arrete DEFINITIVEMENT la boucle (plus de requestAnimationFrame).
   Le navigateur ne fait que limiter le debit, les callbacks restaient empiles ; on les
   supprime et on relance a la visibilite. */
document.addEventListener('visibilitychange',()=>{run=!document.hidden;if(run){last=0;requestAnimationFrame(fr)}});
function fr(t){if(!run)return;if(t-last>=stepMs()){last=t;frame()}requestAnimationFrame(fr)}
requestAnimationFrame(fr);
window.DNA_ECO={on:ECO,set(n){try{localStorage.setItem('dna_eco_n',String(n))}catch(e){}location.reload()}}})();
/* ---- segments / pills ---- */
$('#seg-mode').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;state.mode=b.dataset.mode;$$('#seg-mode button').forEach(z=>z.classList.toggle('active',z===b));$('#video-opts').classList.toggle('hidden',state.mode!=='video');$('#audio-opts').classList.toggle('hidden',state.mode!=='audio')});
function pill(id,key){$(id).addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;$$(id+' button').forEach(z=>z.classList.toggle('active',z===b));state[key]=b.dataset.vf||b.dataset.vq||b.dataset.af||b.dataset.aq})}
pill('#video-formats','vf');pill('#video-quality','vq');pill('#audio-formats','af');pill('#audio-quality','aq');
/* Option « 🔇 Sans son » : retire la piste audio de la video telechargee (l'original avec son est garde). */
$('#toggle-silent').addEventListener('click',()=>{state.silent=!state.silent;
 const b=$('#toggle-silent');b.classList.toggle('on',state.silent);b.setAttribute('aria-pressed',state.silent);
 setStatus(state.silent?'🔇 Sans son activé : la vidéo téléchargée sera muette (l\'original avec son reste gardé).':'🔊 Son réactivé.')});
