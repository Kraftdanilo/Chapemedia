"""Persistance locale de CHAPE-MEDIA.

Depuis cette version tout passe par une base SQLite (`~/.chape_media/chape_media.db`) :
reglages, historique des telechargements, index de la mediatheque, journal et statistiques.

Les anciens fichiers `config.json` / `history.json` sont importes automatiquement au premier
lancement (une seule fois, marqueur `json_migrated` en base) puis laisses sur le disque en
temoins : rien n'est perdu pour les utilisateurs existants.
"""
import json
import os
import time

from .config import CONFIG_FILE, DB_FILE, HISTORY_FILE
from .database import Database


class StorageManager:
    """API haut niveau de la base : reglages, historique, mediatheque, journal, stats."""

    # pywebview parcourt recursivement les attributs publics de l'objet expose au JS
    # (webview.util.get_functions) et publie chaque methode trouvee dans window.pywebview.api.
    # Sans ce marqueur, les methodes internes de la base seraient exposees au front.
    _serializable = False

    def __init__(self, db_path=DB_FILE):
        self.db = Database(db_path)
        self.migrated = self.migrate_json_once()

    # ------------------------------------------------------------------ utilitaires
    @staticmethod
    def _read_json(path, default):
        try:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except (OSError, ValueError):
            pass
        return default

    @staticmethod
    def _dl_out(row):
        """Normalise une ligne `downloads` pour le front (compatibilite avec l'ancien format).

        Ajoute `present` : le fichier existe-t-il encore sur le disque ? (permet d'afficher
        un badge "fichier manquant" et de proposer le nettoyage de l'historique).
        """
        out = dict(row)
        out["format"] = out.get("kind") or out.get("format") or "video"
        out["favorite"] = bool(out.get("favorite"))
        out["plays"] = int(out.get("plays") or 0)
        out["size"] = int(out.get("size") or 0)
        out["error"] = out.get("error") or ""
        fp = out.get("filepath")
        out["present"] = bool(fp) and os.path.isfile(str(fp))
        return out

    @staticmethod
    def _lib_out(row):
        out = dict(row)
        out["favorite"] = bool(out.get("favorite"))
        out["plays"] = int(out.get("plays") or 0)
        out["size"] = int(out.get("size") or 0)
        out["present"] = bool(out.get("present", 1))
        return out

    # ------------------------------------------------------------------ migration
    def migrate_json_once(self):
        """Importe config.json + history.json dans la base (une seule fois)."""
        if self.db.get_setting("json_migrated") == "1":
            return False
        imported = {"config": 0, "history": 0}

        cfg = self._read_json(CONFIG_FILE, {})
        if isinstance(cfg, dict) and cfg and not self.db.get_setting("config"):
            self.save_config(cfg)
            imported["config"] = len(cfg)

        hist = self._read_json(HISTORY_FILE, [])
        if isinstance(hist, list) and hist and self.db.count_downloads() == 0:
            for entry in hist:
                if isinstance(entry, dict) and self.add_download(entry):
                    imported["history"] += 1

        self.db.set_setting("json_migrated", "1")
        if imported["config"] or imported["history"]:
            self.log("info", "Migration JSON -> SQLite terminee", json.dumps(imported))
        return bool(imported["config"] or imported["history"])

    # ------------------------------------------------------------------ reglages
    def load_config(self):
        raw = self.db.get_setting("config")
        if raw:
            try:
                cfg = json.loads(raw)
                if isinstance(cfg, dict):
                    return cfg
            except ValueError:
                pass
        return {}

    def save_config(self, cfg):
        try:
            return self.db.set_setting("config", json.dumps(cfg or {}, ensure_ascii=False))
        except (TypeError, ValueError):
            return False

    def get_setting(self, key, default=None):
        return self.db.get_setting(key, default)

    def set_setting(self, key, value):
        return self.db.set_setting(key, value)

    # ------------------------------------------------------------------ historique
    def add_download(self, entry):
        """Enregistre un telechargement (complete taille/ext depuis le disque si possible)."""
        if not isinstance(entry, dict):
            return None
        data = dict(entry)
        path = data.get("filepath")
        if path and not data.get("ext"):
            data["ext"] = os.path.splitext(str(path))[1].lstrip(".").lower()
        if path and not data.get("size"):
            try:
                data["size"] = os.path.getsize(path)
            except OSError:
                data["size"] = 0
        data.setdefault("finished_at", time.time())
        row_id = self.db.upsert_download(data)
        if row_id:
            failed = bool(data.get("error")) or str(data.get("status", "")).lower().startswith("erreur")
            self.log("error" if failed else "info",
                     ("Echec du telechargement : " if failed else "Telechargement termine : ")
                     + str(data.get("title") or data.get("url") or ""),
                     str(data.get("url") or ""))
            # Le fichier telecharge entre aussitot dans l'index de la mediatheque
            if path and os.path.isfile(path):
                self.sync_library([{
                    "path": str(path),
                    "title": str(data.get("title") or os.path.basename(str(path))),
                    "ext": data.get("ext"), "size": data.get("size"), "mtime": time.time(),
                }], prune=False)
        return row_id

    def load_history(self, limit=150, offset=0, favorites_only=False):
        """Historique du plus ancien au plus recent (compatibilite avec l'ancienne API JSON)."""
        rows = self.db.list_downloads(limit=limit, offset=offset, only_favorites=favorites_only)
        return [self._dl_out(r) for r in reversed(rows)]

    def save_history(self, hist):
        """Remplace tout l'historique (compatibilite / imports)."""
        self.db.clear_downloads(keep_favorites=False)
        if isinstance(hist, list):
            for entry in hist:
                if isinstance(entry, dict):
                    self.db.upsert_download(entry)
        return True

    def list_downloads(self, limit=150, offset=0, favorites_only=False):
        """Historique du plus recent au plus ancien (ce que consomme l'interface)."""
        return [self._dl_out(r) for r in
                self.db.list_downloads(limit=limit, offset=offset, only_favorites=favorites_only)]

    def search_downloads(self, text, limit=200, favorites_only=False):
        return [self._dl_out(r) for r in
                self.db.search_downloads(text, limit=limit, only_favorites=favorites_only)]

    def get_download(self, row_id):
        row = self.db.get_download(row_id)
        return self._dl_out(row) if row else None

    def count_downloads(self, favorites_only=False):
        return self.db.count_downloads(only_favorites=favorites_only)

    def delete_download(self, row_id):
        removed = self.db.delete_download(row_id)
        if removed:
            self.log("info", "Entree retiree de l'historique", "id=%s" % row_id)
        return removed

    def clear_downloads(self, keep_favorites=True):
        removed = self.db.clear_downloads(keep_favorites=keep_favorites)
        self.log("info", "Historique vide", "%d ligne(s) supprimee(s)" % removed)
        return removed

    def set_download_favorite(self, row_id, value=True):
        ok = self.db.set_download_favorite(row_id, value)
        if ok:
            self.log("info", "Favori %s" % ("ajoute" if value else "retire"), "download id=%s" % row_id)
        return ok

    def prune_missing_downloads(self):
        """Retire les entrees dont le fichier n'existe plus (favoris conserves)."""
        removed = self.db.prune_missing_downloads()
        if removed:
            self.log("info", "Historique nettoye", "%d entree(s) sans fichier sur le disque" % removed)
        return removed

    def mark_download_played(self, row_id):
        return self.db.mark_download_played(row_id)

    # ------------------------------------------------------------------ mediatheque
    def sync_library(self, files, prune=True):
        return self.db.sync_library(files, prune=prune)

    def list_library(self, limit=400, favorites_only=False, include_missing=False):
        return [self._lib_out(r) for r in self.db.list_library(
            limit=limit, only_favorites=favorites_only, include_missing=include_missing)]

    def search_library(self, text, limit=400, favorites_only=False):
        return [self._lib_out(r) for r in self.db.search_library(
            text, limit=limit, only_favorites=favorites_only)]

    def count_library(self, favorites_only=False):
        return self.db.count_library(only_favorites=favorites_only)

    def set_library_favorite(self, path, value=True):
        ok = self.db.set_library_favorite(path, value)
        if ok:
            self.log("info", "Favori %s" % ("ajoute" if value else "retire"), str(path))
        return ok

    def mark_library_played(self, path):
        return self.db.mark_library_played(path)

    def remove_library(self, path):
        return self.db.remove_library(path)

    # ------------------------------------------------------------------ journal / stats
    def log(self, level, message, ctx=""):
        return self.db.log(level, message, ctx)

    def list_logs(self, limit=200, level=None):
        return self.db.list_logs(limit=limit, level=level)

    def clear_logs(self):
        return self.db.clear_logs()

    def stats(self, days=14):
        return self.db.stats(days=days)

    def info(self):
        return self.db.info()

    # ------------------------------------------------------------------ maintenance
    def backup(self):
        """Sauvegarde coherente de la base dans ~/.chape_media/backups ; retourne le chemin."""
        return self.db.backup()

    def export_json(self, path=None):
        """Export lisible (JSON) de tout le contenu de la base."""
        return self.db.export_history_json(path)

    def export_csv(self, path=None):
        """Export tableur (CSV) de l'historique des telechargements."""
        return self.db.export_history_csv(path)

    def checkpoint(self):
        """Ecrit le journal WAL dans le fichier principal (appele a l'arret de l'application)."""
        return self.db.checkpoint()

    def optimize(self):
        return self.db.optimize()

    def integrity_check(self):
        return self.db.integrity_check()

    def file_size(self):
        return self.db.file_size()

    def close(self):
        self.db.close_all()

    # ------------------------------------------------------------------ compatibilite
    @staticmethod
    def load_json(path, default):
        """Ancien utilitaire JSON conserve pour les appels existants (lecture seule)."""
        return StorageManager._read_json(path, default)

    @staticmethod
    def save_json(path, data):
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except (OSError, TypeError, ValueError):
            return False
