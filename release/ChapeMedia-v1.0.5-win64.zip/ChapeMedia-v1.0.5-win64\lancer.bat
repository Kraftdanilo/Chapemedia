@echo off
rem CHAPE-MEDIA - lanceur (mode sources, aucun exe)
rem Installe les dependances au premier lancement, puis demarre l'application.
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo Python introuvable. Installez Python 3.11+ depuis https://www.python.org/downloads/
    echo et cochez "Add python.exe to PATH" pendant l'installation.
    pause
    exit /b 1
)
if not exist .venv goto install
goto run

:install
echo Premiere installation : creation de l'environnement Python...
python -m venv .venv
if errorlevel 1 (
    echo Echec de la creation du venv
    pause
    exit /b 1
)
.venv\Scripts\python.exe -m pip install --quiet --upgrade pip
.venv\Scripts\python.exe -m pip install --quiet -r requirements.txt
if errorlevel 1 (
    echo Echec de l'installation des dependances
    pause
    exit /b 1
)

:run
".venv\Scripts\python.exe" app.py
if errorlevel 1 pause
