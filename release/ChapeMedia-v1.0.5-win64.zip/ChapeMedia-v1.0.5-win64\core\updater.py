"""Mise a jour automatique de CHAPE-MEDIA (verification, telechargement, installation).

Pourquoi ce module : distribuer une application portable veut dire devoir corriger
les bugs et les extracteurs yt-dlp sans re-installer quoi que ce soit chez
l'utilisateur. Le paquet reste autonome : aucune dependance externe, uniquement la
bibliotheque standard.

Deroule (each step is independent and can be retried) :
  1. check()    : lit manifest.json (URL http(s), fichier, ou dossier local / cle USB)
                  et compare `version` a APP_VERSION.
  2. download() : recupere le zip dans ~/.chape_media/update/, verifie le SHA-256
                  annonce (un paquet tronque ou falsifie est detruit).
  3. install()  : decompresse dans ~/.chape_media/update/stage/, ecrit un petit
                  `updater.bat` a cote de l'executable, le lance en dehors du
                  processus courant puis ferme l'application. Le batch attend la
                  fin du processus, remplace ChapeMedia.exe et _internal/, et en cas
                  d'echec remet l'ancienne version en place (retour arriere) avant
                  de relancer l'application.

Les donnees de l'utilisateur (~/.chape_media : base SQLite, reglages, journal,
telechargements) ne sont jamais touchees : seule la partie programme est remplacee.
"""
import hashlib
import json
import os
import shutil
import subprocess
import time
import zipfile
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

from .config import (APP_CHANNEL, APP_DIR, APP_NAME, APP_VERSION, IS_FROZEN, UPDATE_CHUNK,
                     UPDATE_DIR, UPDATE_MANIFEST, UPDATE_STAGE_DIR, UPDATE_TIMEOUT, UPDATE_URLS,
                     is_newer)

USER_AGENT = "ChapeMediaUpdater/%s" % APP_VERSION
# Le paquet doit contenir ces elements : on refuse d'installer n'importe quel zip.
REQUIRED_ENTRIES = ("ChapeMedia.exe", "_internal")


def _human_error(exc, source):
    """Traduit une erreur reseau en message comprenable par l'utilisateur.

    Un « HTTP Error 404: Not Found » ne dit rien : l'utilisateur ne sait pas s'il doit
    attendre une publication, corriger une adresse ou simplement reessayer. On nomme la cause.
    """
    where = source if len(str(source)) <= 90 else (str(source)[:87] + "...")
    if isinstance(exc, HTTPError):
        if exc.code == 404:
            return ("Manifeste introuvable (404) : aucune publication a cette adresse — %s.\n"
                    "Soit le depot est vide / le fichier manifest.json n'y est pas encore "
                    "depose, soit l'adresse est erronee." % where)
        if exc.code in (401, 403):
            return ("Acces refuse (%d) a la source de mise a jour — %s.\n"
                    "L'adresse exige une authentification : utilisez une source publique." % (exc.code, where))
        if exc.code == 429:
            return ("Trop de requetes (429) : GitHub limite le nombre de appels. "
                    "Reessayez dans quelques minutes — %s." % where)
        return ("Serveur de mise a jour indisponible (HTTP %d) — %s." % (exc.code, where))
    if isinstance(exc, URLError):
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, TimeoutError) or "timed out" in str(reason).lower():
            return ("Le serveur de mise a jour ne repond pas (delai depasse) — %s.\n"
                    "Connexion internet indisponible ou serveur occupe." % where)
        return ("Serveur de mise a jour injoignable (%s) — %s.\n"
                "Verifiez la connexion internet." % (reason, where))
    return "%s : %s" % (type(exc).__name__, exc)


def _is_http(source):
    return urlparse(str(source or "")).scheme.lower() in ("http", "https")


def _local_path(source):
    """Convertit une source locale (chemin, partage reseau, file://) en chemin absolu."""
    text = str(source or "").strip()
    if not text:
        return ""
    parsed = urlparse(text)
    if parsed.scheme.lower() == "file":
        text = parsed.path.lstrip("/")
        if len(text) >= 2 and text[1] == ":":
            text = text[0].upper() + text[1:]
    return os.path.abspath(os.path.expandvars(os.path.expanduser(text)))


class Updater:
    """Verifie, telecharge et installe une nouvelle version du programme."""

    # Objet interne : ne doit pas etre expose au JS (cf. StorageManager._serializable).
    _serializable = False

    def __init__(self, on_event=None, update_url=None, app_dir=None, work_dir=None,
                 stage_dir=None, current_version=None, frozen=None):
        """Tous les chemins sont surchargeables : c'est ce qui permet de tester
        l'installateur complet sur un faux dossier d'application."""
        self.on_event = on_event
        self.update_url = update_url
        self.app_dir = os.path.abspath(app_dir or APP_DIR)
        self.work_dir = os.path.abspath(work_dir or UPDATE_DIR)
        self.stage_dir = os.path.abspath(stage_dir or UPDATE_STAGE_DIR)
        self.current_version = current_version or APP_VERSION
        self.frozen = IS_FROZEN if frozen is None else bool(frozen)
        self.manifest = {}
        self.source = ""
        self.package = ""
        self.stage = ""
        self.error = ""
        os.makedirs(self.work_dir, exist_ok=True)

    # ------------------------------------------------------------------ evenements
    def _emit(self, stage, pct=0.0, text="", **extra):
        """Pousse un evenement `update` vers l'interface (le front affiche la barre)."""
        if not self.on_event:
            return
        payload = {"type": "update", "stage": stage, "pct": round(float(pct), 1), "text": text}
        payload.update(extra)
        try:
            self.on_event(payload)
        except Exception:
            pass

    # --------------------------------------------------------------------- sources
    def source_url(self):
        """Premiere source utilisable : reglange, variable d'env, puis liste par defaut."""
        candidates = []
        if self.update_url:
            candidates.append(self.update_url)
        candidates.append(os.environ.get("CHAPE_MEDIA_UPDATE_URL", ""))
        candidates.extend(UPDATE_URLS)
        for cand in candidates:
            cand = str(cand or "").strip()
            if not cand:
                continue
            if _is_http(cand):
                return cand
            path = _local_path(cand)
            if os.path.isfile(path) or os.path.isdir(path):
                return path
        return ""

    def _manifest_sources(self):
        """Liste des emplacements tries : la source explicite d'abord, puis les autres."""
        main = self.source_url()
        out = [main] if main else []
        for cand in UPDATE_URLS:
            if cand and cand not in out:
                out.append(cand)
        return out

    def _read_manifest_text(self, source):
        if _is_http(source):
            req = Request(source, headers={"User-Agent": USER_AGENT,
                                           "Accept": "application/json"})
            with urlopen(req, timeout=UPDATE_TIMEOUT) as resp:
                return resp.read().decode("utf-8-sig", "replace")
        path = _local_path(source)
        if os.path.isdir(path):
            path = os.path.join(path, UPDATE_MANIFEST)
        if not os.path.isfile(path):
            raise IOError("manifeste introuvable : %s" % path)
        with open(path, "rb") as fh:
            return fh.read().decode("utf-8-sig", "replace")


    # -------------------------------------------------------------------- controle
    def check(self, source=None):
        """Compare la version publiee a la version installee. Ne leve jamais d'exception."""
        result = {"ok": False, "current": self.current_version, "latest": "",
                  "available": False, "mandatory": False, "notes": "", "package": "",
                  "url": "", "size": 0, "sha256": "", "channel": APP_CHANNEL,
                  "source": "", "error": ""}
        sources = [source] if source else self._manifest_sources()
        last_error = "Serveur de mise a jour non configure"
        for src in sources:
            if not src:
                continue
            try:
                data = json.loads(self._read_manifest_text(src))
                if not isinstance(data, dict):
                    raise ValueError("le manifeste doit etre un objet JSON")
            except ValueError as exc:
                # Manifeste trouve mais illisible : inutile d'essayer les autres sources,
                # on remonte l'erreur telle quelle (aucun appel reseau supplementaire).
                result["error"] = "Manifeste invalide (%s) : %s" % (src, exc)
                self.error = result["error"]
                return result
            except Exception as exc:
                # 404 / reseau indisponible : on essaie la source suivante, mais on retient
                # un message explicite (le dernier) plutot qu'un 'HTTP Error 404' opaque.
                last_error = _human_error(exc, src)
                continue
            self.manifest, self.source = data, src
            latest = str(data.get("version") or "")
            result.update({
                "ok": True,
                "latest": latest,
                "channel": str(data.get("channel") or APP_CHANNEL),
                "available": bool(is_newer(latest, self.current_version)),
                "mandatory": bool(data.get("mandatory")) and self._older_than(data.get("min_version")),
                "notes": str(data.get("notes") or ""),
                "package": str(data.get("package") or ""),
                "size": int(data.get("size") or 0),
                "sha256": str(data.get("sha256") or "").lower(),
                "source": src,
                "url": self.package_url(),
                "app": str(data.get("app") or APP_NAME),
                "date": str(data.get("date") or ""),
            })
            if result["app"] and "CHAPE" not in result["app"].upper().replace(" ", ""):
                result["available"] = False
                result["error"] = "Manifeste prevu pour une autre application"
            return result
        result["error"] = last_error
        self.error = last_error
        return result

    def _older_than(self, minimum):
        """Vrai si la version installee est trop ancienne pour la nouvelle."""
        return bool(minimum) and is_newer(minimum, self.current_version)

    def package_url(self):
        """URL reelle du paquet : absolue (relative au manifeste) ou voisine du manifeste."""
        name = str(self.manifest.get("url") or self.manifest.get("package") or "")
        if not name:
            return ""
        if _is_http(name):
            return name
        if _is_http(self.source):
            return urljoin(self.source, name)
        base = _local_path(self.source)
        if os.path.isdir(base):
            return os.path.join(base, name)
        return os.path.join(os.path.dirname(base), name)

    # ------------------------------------------------------------- telechargement
    def sha256_file(self, path, chunk=UPDATE_CHUNK):
        """Empreinte SHA-256 d'un fichier (identique a Get-FileHash -Algorithm SHA256)."""
        digest = hashlib.sha256()
        with open(path, "rb") as fh:
            while True:
                block = fh.read(chunk)
                if not block:
                    break
                digest.update(block)
        return digest.hexdigest().lower()

    def download(self, source=None):
        """Recupere le paquet dans le dossier de donnees et verifie son empreinte."""
        info = self.check(source)
        if not info.get("ok"):
            self.error = info.get("error") or "Manifeste illisible"
            return {"ok": False, "error": self.error}
        if not info.get("available"):
            return {"ok": True, "available": False, "current": self.current_version,
                    "latest": info.get("latest")}
        url = self.package_url()
        if not url:
            self.error = "Le manifeste n'indique aucun paquet a telecharger"
            return {"ok": False, "error": self.error}
        name = os.path.basename(urlparse(url).path if _is_http(url) else url) or \
            ("ChapeMedia-%s-win64.zip" % info.get("latest"))
        target = os.path.join(self.work_dir, name)
        part = target + ".part"
        expected = str(info.get("sha256") or "").lower()
        total = int(info.get("size") or 0)
        self._emit("downloading", 0.0, "Preparation du telechargement", version=info.get("latest"))
        done, started, last_emit = 0, time.time(), 0.0
        try:
            if os.path.exists(part):
                os.remove(part)
            src = urlopen(Request(url, headers={"User-Agent": USER_AGENT}),
                          timeout=UPDATE_TIMEOUT) if _is_http(url) else open(url, "rb")
            with src, open(part, "wb") as out:
                length = int(getattr(src, "length", 0) or 0) or total
                while True:
                    block = src.read(UPDATE_CHUNK)
                    if not block:
                        break
                    out.write(block)
                    done += len(block)
                    now = time.time()
                    if now - last_emit >= 0.3:
                        last_emit = now
                        pct = (done * 100.0 / length) if length else 0.0
                        speed = done / max(now - started, 0.001) / 1048576.0
                        self._emit("downloading", pct, "Telechargement %.1f Mo/s" % speed,
                                   version=info.get("latest"), bytes=done, total=length)
            digest = self.sha256_file(part)
            if expected and digest != expected:
                os.remove(part)
                self.error = "Empreinte SHA-256 differente : paquet abandonne"
                self._emit("error", 0.0, self.error)
                return {"ok": False, "error": self.error}
            if os.path.exists(target):
                os.remove(target)
            os.rename(part, target)
            self.package = target
            self._emit("downloaded", 100.0, "Paquet verifie, pret a installer",
                       version=info.get("latest"), sha256=digest, path=target)
            return {"ok": True, "available": True, "path": target, "sha256": digest,
                    "size": done, "version": info.get("latest"), "notes": info.get("notes")}
        except Exception as exc:
            self.error = "%s : %s" % (type(exc).__name__, exc)
            try:
                if os.path.exists(part):
                    os.remove(part)
            except OSError:
                pass
            self._emit("error", 0.0, self.error)
            return {"ok": False, "error": self.error}

    # ---------------------------------------------------------------- preparation
    def writable(self):
        """Le dossier programme est-il modifiable (condition indispensable a l'install) ?"""
        probe = os.path.join(self.app_dir, ".chape_write_test")
        try:
            with open(probe, "wb"):
                pass
            os.remove(probe)
            return True
        except OSError:
            return False

    def _find_root(self):
        """Le zip contient une racine : on retourne le dossier qui porte l'application."""
        try:
            children = [os.path.join(self.stage_dir, name)
                        for name in sorted(os.listdir(self.stage_dir))]
        except OSError:
            children = []
        for cand in [self.stage_dir] + [c for c in children if os.path.isdir(c)]:
            if all(os.path.exists(os.path.join(cand, entry)) for entry in REQUIRED_ENTRIES):
                return cand
        return ""

    def prepare(self):
        """Decompresse le paquet verifie dans le dossier d'attente, puis le valide."""
        if not self.package or not os.path.isfile(self.package):
            self.error = "Aucun paquet telecharge"
            return {"ok": False, "error": self.error}
        self._emit("preparing", 0.0, "Decompression du paquet")
        try:
            shutil.rmtree(self.stage_dir, ignore_errors=True)
            os.makedirs(self.stage_dir, exist_ok=True)
            with zipfile.ZipFile(self.package) as zf:
                for name in zf.namelist():
                    flat = os.path.normpath(name)
                    if flat.startswith("..") or os.path.isabs(flat) or ":" in flat:
                        raise ValueError("entree suspecte dans le paquet : %s" % name)
                zf.extractall(self.stage_dir)
        except Exception as exc:
            self.error = "%s : %s" % (type(exc).__name__, exc)
            self._emit("error", 0.0, self.error)
            return {"ok": False, "error": self.error}
        root = self._find_root()
        if not root:
            self.error = ("Paquet invalide : %s et %s sont requis a la racine"
                          % REQUIRED_ENTRIES)
            self._emit("error", 0.0, self.error)
            return {"ok": False, "error": self.error}
        self.stage = root
        self._emit("prepared", 100.0, "Nouvelle version prete a etre installee", staged=root)
        return {"ok": True, "stage": root, "version": self.manifest.get("latest")
                or self.manifest.get("version")}

    # ----------------------------------------------------------------- installation
    def bat_script(self, pid, stage, log):
        """Script d'echange : attend la fin du processus, remplace, remet en place si echec.

        Trois details appris a l'usage (verifies par tests/update_selftest.py --e2e) :
          - on ne surveille PAS le pid avec `tasklist | find` : le tube fait mourir le
            script quand il est lance sans console (processus detache, cas reel ici).
            On teste directement l'operation dont on a besoin : RENOMMER ChapeMedia.exe.
            Tant que l'application tourne, Windows refuse le renommage (partage) : le
            script attend donc exactement le bon moment, sans dependance externe.
          - l'attente est longue (300 essais) : les processus WebView2 enfants relachent
            leurs dll de _internal parfois longtemps apres la fermeture de la fenetre.
          - robocopy est retente jusqu'a 3 fois : memes dll, quelques secondes plus tard.
        """
        safe = lambda value: str(value).replace('"', "").replace("&", "").replace("|", "")
        lines = [
            "@echo off",
            "rem CHAPE-MEDIA - installateur de mise a jour genere automatiquement (auto-supprime)",
            "setlocal enableextensions",
            'set "APPDIR=%s"' % safe(self.app_dir),
            'set "STAGE=%s"' % safe(stage),
            'set "LOG=%s"' % safe(log),
            'set "EXE=ChapeMedia.exe"',
            'set "ANCIEN=ChapeMedia_old.exe"',
            'set "BACKUP=_old"',
            "set /a ESSAIS=0",
            "set /a COPIES=0",
            'echo updater demarre (pid %s) > "%%LOG%%"' % int(pid),
            'echo app=%APPDIR% >> "%LOG%"',
            'echo stage=%STAGE% >> "%LOG%"',
            'cd /d "%APPDIR%" >nul 2>&1',
            "if errorlevel 1 goto echec_dossier",
            'if not exist "%EXE%" goto echec_dossier',
            ":attente",
            "rem Le renommage echoue tant que l'application tourne : c'est notre signal d'attente.",
            "rem 300 essais x ~1 s = 5 min : WebView2 peut garder ses DLL ouvertes longtemps.",
            'ren "%EXE%" "%ANCIEN%" >nul 2>&1',
            "if not errorlevel 1 goto exe_renomme",
            "set /a ESSAIS=%ESSAIS%+1",
            "if %ESSAIS% GEQ 300 goto echec_attente",
            "ping -n 2 127.0.0.1 >nul",
            "goto attente",
            ":exe_renomme",
            'echo application fermee (essais %ESSAIS%) >> "%LOG%"',
            "ping -n 3 127.0.0.1 >nul",
            'if exist "%BACKUP%" rd /s /q "%BACKUP%"',
            'ren "_internal" "%BACKUP%"',
            "if errorlevel 1 goto restore",
            ":copie",
            'robocopy "%STAGE%" "%APPDIR%" /E /NFL /NDL /NJH /NJS /R:2 /W:2 >> "%LOG%" 2>&1',
            "if not errorlevel 8 goto copie_ok",
            "set /a COPIES=%COPIES%+1",
            'echo copie incomplete (tentative %COPIES%) >> "%LOG%"',
            "if %COPIES% GEQ 3 goto restore",
            "ping -n 3 127.0.0.1 >nul",
            "goto copie",
            ":copie_ok",
            'del /q "%ANCIEN%" >nul 2>nul',
            'rd /s /q "%BACKUP%" >nul 2>nul',
            'rd /s /q "%STAGE%" >nul 2>nul',
            'echo installation reussie >> "%LOG%"',
            'start "" "%APPDIR%\\%EXE%"',
            "goto cleanup",
            ":restore",
            'ren "%BACKUP%" "_internal" >nul 2>nul',
            'ren "%ANCIEN%" "%EXE%" >nul 2>nul',
            'echo installation echouee : ancienne version restauree >> "%LOG%"',
            "goto redemarrage",
            ":echec_attente",
            'echo l''application ne s''est pas fermee : mise a jour abandonnee >> "%LOG%"',
            "goto cleanup",
            ":echec_dossier",
            'echo dossier ou executable introuvable : mise a jour abandonnee >> "%LOG%"',
            ":redemarrage",
            'if exist "%APPDIR%\\%EXE%" start "" "%APPDIR%\\%EXE%"',
            ":cleanup",
            'del "%~f0" >nul 2>nul',
            "endlocal",
        ]
        return "\r\n".join(lines) + "\r\n"

    def install(self, confirm=False, dry_run=False, on_ready=None, pid=None):
        """Installe la version preparee : `confirm=True` est obligatoire (l'app va se fermer).

        `dry_run=True` prepare tout (decompression + script + log) sans rien lancer :
        c'est ce que verifie l'auto-test, et ce qui permet un remplacement manuel.
        `pid` : processus a attendre avant de remplacer les fichiers (l'application
        elle-meme par defaut ; surchargeable uniquement pour les tests).
        """
        if not confirm:
            return {"ok": False, "error": "Confirmation requise (l'application va se fermer)"}
        if not self.stage or not os.path.isdir(self.stage):
            prepared = self.prepare()
            if not prepared.get("ok"):
                return prepared
        if not self.writable():
            self.error = ("Dossier programme non modifiable : deplacez %s dans un dossier "
                          "personnel (ou lancez-le en administrateur)" % os.path.basename(self.app_dir))
            self._emit("error", 0.0, self.error)
            return {"ok": False, "error": self.error}
        log = os.path.join(self.work_dir, "update.log")
        # Le script vit dans le dossier de travail (~/.chape_media/update), jamais dans le
        # dossier programme : rien ne traine chez l'utilisateur et il est nettoye au
        # demarrage suivant (Updater.cleanup).
        bat = os.path.join(self.work_dir, "updater.bat")
        script = self.bat_script(os.getpid() if pid is None else int(pid), self.stage, log)
        try:
            with open(bat, "w", encoding="mbcs", errors="replace", newline="") as fh:
                fh.write(script)
        except (OSError, LookupError):
            try:
                with open(bat, "w", encoding="ascii", errors="replace", newline="") as fh:
                    fh.write(script)
            except OSError as exc:
                self.error = "Impossible d'ecrire l'installateur : %s" % exc
                return {"ok": False, "error": self.error}
        version = str(self.manifest.get("latest") or self.manifest.get("version") or "")
        if dry_run:
            return {"ok": True, "dry_run": True, "bat": bat, "log": log,
                    "stage": self.stage, "version": version, "script": script}
        self._emit("installing", 100.0, "Fermeture de l'application puis remplacement",
                   version=version, log=log)
        try:
            flags = getattr(subprocess, "DETACHED_PROCESS", 0) | \
                getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            devnull = open(os.devnull, "wb")
            subprocess.Popen('cmd.exe /d /c ""%s"' % bat, cwd=self.work_dir,
                             creationflags=flags, close_fds=True,
                             stdout=devnull, stderr=devnull, stdin=subprocess.DEVNULL)
        except Exception as exc:
            self.error = "Lancement de l'installateur impossible : %s" % exc
            self._emit("error", 0.0, self.error)
            return {"ok": False, "error": self.error, "bat": bat, "log": log}
        if on_ready:
            try:
                on_ready()
            except Exception:
                pass
        return {"ok": True, "started": True, "version": version, "bat": bat, "log": log}

    # --------------------------------------------------------------------- etat
    def cleanup(self):
        """Efface les restes d'une installation precedente (appelee au demarrage).

        Le script `updater.bat` ne peut pas toujours s'auto-supprimer (cmd.exe garde le
        fichier ouvert pendant son execution) : c'est donc l'application, au lancement
        suivant, qui fait le menage. Le paquet telecharge et le journal sont conserves
        (utiles en cas de probleme).
        """
        reste = os.path.join(self.work_dir, "updater.bat")
        supprime = False
        if os.path.isfile(reste):
            try:
                os.remove(reste)
                supprime = True
            except OSError:
                supprime = False
        return {"ok": True, "removed": supprime, "path": reste}

    def status(self):
        """Etat synthetique pour l'interface (boutons, libelles, dossier de log)."""
        return {
            "version": APP_VERSION,
            "current": self.current_version,
            "channel": APP_CHANNEL,
            "installed_package": self.frozen,
            "app_dir": self.app_dir,
            "writable": self.writable() if self.frozen else True,
            "source": self.source or self.source_url(),
            "pending": bool(self.package and os.path.isfile(self.package)),
            "package": self.package,
            "stage": self.stage,
            "log": os.path.join(self.work_dir, "update.log"),
            "error": self.error,
        }



