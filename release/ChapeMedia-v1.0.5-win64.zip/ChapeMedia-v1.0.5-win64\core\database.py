"""Couche base de donnees SQLite de CHAPE-MEDIA.

Remplace les fichiers JSON (historique + config) par une vraie base SQL embarquee :

  settings   : preferences cle/valeur (JSON encode -> les types Python survivent)
  downloads  : historique complet des telechargements (favoris, lectures, erreurs, taille...)
  library    : index de la mediatheque locale (remplace le scan disque a chaque refresh)
  logs       : journal applicatif (diagnostic, export, support)
  daily      : agregats par jour (statistiques instantanees sans recompter les lignes)

Points techniques :
  - `sqlite3` de la bibliotheque standard : aucune dependance a installer.
  - une connexion par thread (le pont pywebview et yt-dlp travaillent dans des threads differents)
  - journal WAL + busy_timeout : lectures et ecritures concurrentes sans "database is locked"
  - recherche plein texte FTS5 (insensible aux accents et a la casse) avec repli automatique
    sur LIKE normalise si FTS5 n'est pas disponible dans la compilation SQLite
  - schema versionne via `PRAGMA user_version` -> migrations automatiques aux prochaines versions
"""
import contextlib
import os
import re
import sqlite3
import threading
import time
import unicodedata
from datetime import datetime

from .config import (
    DB_BACKUP_DIR,
    DB_BACKUP_KEEP,
    DB_BUSY_TIMEOUT,
    DB_FILE,
    DB_SCHEMA_VERSION,
    DOWNLOAD_KEEP,
    LOG_KEEP,
)

_TOKEN_RE = re.compile(r"[^\w]+", re.UNICODE)


def norm(text):
    """Normalise une chaine pour la recherche : minuscules, accents retires."""
    s = unicodedata.normalize("NFKD", str(text or ""))
    s = "".join(c for c in s if not unicodedata.combining(c))
    return s.lower().strip()


def day_key(ts=None):
    """Cle de jour 'AAAA-MM-JJ' (heure locale)."""
    return time.strftime("%Y-%m-%d", time.localtime(ts if ts is not None else time.time()))


def _to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


class Database:
    """Acces bas niveau a la base SQLite (thread-safe, tolerant aux erreurs)."""

    def __init__(self, path=DB_FILE, backup_dir=DB_BACKUP_DIR):
        self.path = path
        self.backup_dir = backup_dir
        self.fts = False            # FTS5 disponible et actif ?
        self.last_error = None      # derniere erreur avalee (utile aux tests/diagnostics)
        self._local = threading.local()
        self._lock = threading.RLock()          # serialise les ecritures
        self._all = []                          # toutes les connexions (fermeture propre)
        parent = os.path.dirname(os.path.abspath(self.path))
        if parent:
            os.makedirs(parent, exist_ok=True)
        try:
            os.makedirs(self.backup_dir, exist_ok=True)
        except OSError:
            pass
        self._setup()

    # ------------------------------------------------------------------ connexions
    def _new_con(self):
        # isolation_level=None : autocommit ; les regroupements passent par tx() (1 seul commit)
        con = sqlite3.connect(self.path, timeout=DB_BUSY_TIMEOUT / 1000.0, check_same_thread=False,
                              isolation_level=None)
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA journal_mode=WAL")      # lectures pendant les ecritures
            con.execute("PRAGMA synchronous=NORMAL")    # bon compromis vitesse/surete
            con.execute("PRAGMA foreign_keys=ON")
            con.execute("PRAGMA busy_timeout=%d" % DB_BUSY_TIMEOUT)
            con.execute("PRAGMA temp_store=MEMORY")
        except sqlite3.Error:
            pass
        with self._lock:
            self._all.append(con)
        return con

    @property
    def con(self):
        """Connexion du thread courant (creation paresseuse)."""
        con = getattr(self._local, "con", None)
        if con is None:
            con = self._local.con = self._new_con()
        return con

    def close(self):
        """Ferme la connexion du thread courant."""
        con = getattr(self._local, "con", None)
        self._local.con = None
        if con is not None:
            try:
                con.close()
            except sqlite3.Error:
                pass

    def close_all(self):
        """Ferme toutes les connexions ouvertes (appel a l'arret de l'application)."""
        with self._lock:
            cons, self._all = self._all, []
        self._local.con = None
        for con in cons:
            try:
                con.close()
            except sqlite3.Error:
                pass

    # ------------------------------------------------------------------ primitives
    def _write(self, sql, params=()):
        with self._lock:
            return self.con.execute(sql, params)

    def _write_many(self, sql, seq):
        with self._lock:
            return self.con.executemany(sql, seq)

    @contextlib.contextmanager
    def tx(self):
        """Transaction explicite : plusieurs ecritures groupees en un seul commit.

        Un commit unique au lieu de un par requete = beaucoup moins d'E/S disque
        (c'est ce qui rend l'enregistrement d'un telechargement et la synchro de la
        mediatheque quasi instantanes, meme avec plusieurs milliers de lignes).
        """
        with self._lock:
            con = self.con
            con.execute("BEGIN IMMEDIATE")
            try:
                yield con
                con.commit()
            except Exception:
                con.rollback()
                raise

    def query(self, sql, params=()):
        return self.con.execute(sql, params).fetchall()

    def query_one(self, sql, params=()):
        return self.con.execute(sql, params).fetchone()

    def _rows(self, sql, params=()):
        """Liste de dictionnaires (au lieu de sqlite3.Row) : directement serialisable en JSON."""
        return [dict(r) for r in self.query(sql, params)]

    # ------------------------------------------------------------------ schema
    def _setup(self):
        """Cree ou met a jour le schema, puis active la recherche plein texte."""
        con = self.con
        first_run = False
        with self.tx():
            for sql in _SCHEMA:
                con.execute(sql)
            version = _to_int(con.execute("PRAGMA user_version").fetchone()[0])
            first_run = version < 1
            if version != DB_SCHEMA_VERSION:
                con.execute("PRAGMA user_version=%d" % DB_SCHEMA_VERSION)
        self.fts = self._setup_fts()
        if first_run:
            self.optimize()

    def _setup_fts(self):
        """Table FTS5 miroir (recherche accents/casse insensibles). False si FTS5 indisponible."""
        try:
            self._write(
                "CREATE VIRTUAL TABLE IF NOT EXISTS downloads_fts USING fts5("
                "title, uploader, ext, tokenize='unicode61 remove_diacritics 2')")
            self._reindex_fts()
            return True
        except sqlite3.Error:
            return False

    def _reindex_fts(self):
        """Recopie l'index FTS depuis la table downloads (1er lancement ou apres migration)."""
        with self.tx() as con:
            rows = [(r["id"], r["title"] or "", r["uploader"] or "", r["ext"] or "")
                    for r in con.execute("SELECT id, title, uploader, ext FROM downloads").fetchall()]
            con.execute("DELETE FROM downloads_fts")
            con.executemany(
                "INSERT INTO downloads_fts(rowid, title, uploader, ext) VALUES (?, ?, ?, ?)", rows)

    def _fts_put(self, row_id, title, uploader, ext, con=None):
        """Met a jour l'index FTS (dans la transaction fournie si `con` est passe)."""
        if not self.fts:
            return
        ctx = contextlib.nullcontext(con) if con is not None else self.tx()
        with ctx as cur:
            cur.execute("DELETE FROM downloads_fts WHERE rowid=?", (row_id,))
            cur.execute(
                "INSERT INTO downloads_fts(rowid, title, uploader, ext) VALUES (?, ?, ?, ?)",
                (row_id, title or "", uploader or "", ext or ""))

    def _fts_del(self, row_id):
        if self.fts:
            self._write("DELETE FROM downloads_fts WHERE rowid=?", (row_id,))

    @staticmethod
    def _fts_query(text):
        """Transforme une saisie libre en requete FTS5 sure (tokens echappes + prefixe)."""
        tokens = [t for t in _TOKEN_RE.split(norm(text)) if t]
        return " ".join('"%s"*' % t.replace('"', '""') for t in tokens)

    # ------------------------------------------------------------------ reglages
    def get_setting(self, key, default=None):
        try:
            row = self.query_one("SELECT value FROM settings WHERE key=?", (key,))
            return default if row is None else row["value"]
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return default

    def set_setting(self, key, value):
        try:
            self._write(
                "INSERT INTO settings(key, value) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, "" if value is None else str(value)),
            )
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def del_setting(self, key):
        try:
            self._write("DELETE FROM settings WHERE key=?", (key,))
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def all_settings(self):
        try:
            return {r["key"]: r["value"] for r in self.query("SELECT key, value FROM settings")}
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return {}

    # ------------------------------------------------------------------ telechargements
    def upsert_download(self, entry):
        """Insere ou met a jour une ligne d'historique (favoris et lectures conserves).

        Boost : tout part dans UNE transaction (historique + index FTS + agregats du jour),
        soit 1 commit par telechargement au lieu de 4 -> ecriture disque minimale.
        """
        if not isinstance(entry, dict):
            return None
        now = time.time()
        row_id = _to_int(entry.get("id") or entry.get("created_at") or int(now * 1000))
        title = str(entry.get("title") or "")
        uploader = str(entry.get("uploader") or "")
        ext = str(entry.get("ext") or "").lower()
        status = str(entry.get("status") or "OK")
        error = str(entry.get("error") or "")
        if not error and status.lower().startswith(("erreur", "error")):
            error = status.split(":", 1)[1].strip() if ":" in status else status
        created = _to_float(entry.get("created_at"))
        if not created and row_id > 10 ** 11:      # ancien id = epoch en millisecondes
            created = row_id / 1000.0
        if not created:
            created = now
        size = _to_int(entry.get("size"))
        try:
            with self.tx() as con:
                con.execute(_INSERT_DOWNLOAD, {
                    "id": row_id,
                    "url": str(entry.get("url") or ""),
                    "title": title,
                    "title_norm": norm(title),
                    "uploader": uploader,
                    "uploader_norm": norm(uploader),
                    "kind": str(entry.get("kind") or entry.get("format") or "video"),
                    "ext": ext,
                    "quality": str(entry.get("quality") or ""),
                    "extractor": str(entry.get("extractor") or ""),
                    "filepath": entry.get("filepath"),
                    "thumbnail": entry.get("thumbnail"),
                    "size": size,
                    "duration": str(entry.get("duration") or entry.get("duration_string") or ""),
                    "status": status,
                    "error": error,
                    "created_at": created,
                    "date": str(entry.get("date")
                                or datetime.fromtimestamp(created).strftime("%d/%m/%Y %H:%M")),
                    "finished_at": _to_float(entry.get("finished_at"), now),
                })
                self._fts_put(row_id, title, uploader, ext, con=con)
                self._bump_day(created, downloads=0 if error else 1, errors=1 if error else 0,
                               size=size, con=con)
            self.prune_downloads()
            return row_id
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return None

    def _bump_day(self, ts, downloads=0, errors=0, size=0, plays=0, con=None):
        """Met a jour les agregats du jour (statistiques instantanees)."""
        try:
            ctx = contextlib.nullcontext(con) if con is not None else self.tx()
            with ctx as cur:
                cur.execute(_BUMP_DAY, (day_key(ts), max(0, _to_int(downloads)),
                                        max(0, _to_int(errors)), max(0, _to_int(size)),
                                        max(0, _to_int(plays))))
        except sqlite3.Error as exc:
            self.last_error = str(exc)

    def prune_downloads(self, keep=DOWNLOAD_KEEP):
        """Garde les `keep` telechargements les plus recents (les favoris sont toujours conserves)."""
        try:
            total = _to_int(self.query_one("SELECT COUNT(*) FROM downloads")[0])
            if total <= keep:
                return 0
            victims = [r["id"] for r in self.query(
                "SELECT id FROM downloads WHERE favorite=0 ORDER BY created_at DESC LIMIT -1 OFFSET ?",
                (max(0, int(keep)),))]
            if victims:
                self._write_many("DELETE FROM downloads WHERE id=?", [(v,) for v in victims])
                if self.fts:
                    self._write_many("DELETE FROM downloads_fts WHERE rowid=?", [(v,) for v in victims])
            return len(victims)
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return 0

    def list_downloads(self, limit=150, offset=0, only_favorites=False):
        """Historique, du plus recent au plus ancien."""
        try:
            sql = "SELECT * FROM downloads"
            if only_favorites:
                sql += " WHERE favorite=1"
            sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
            return self._rows(sql, (max(1, _to_int(limit, 150)), max(0, _to_int(offset))))
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return []

    def search_downloads(self, text, limit=200, only_favorites=False):
        """Recherche plein texte (FTS5, accents/casse ignores) avec repli LIKE.

        Boost : l'index FTS5 donne d'abord les identifiants des correspondances les plus
        recentes (tres rapide), puis la table principale est lue par cle primaire. On evite
        ainsi le tri couteux de toutes les correspondances par date.
        """
        text = (text or "").strip()
        if not text:
            return self.list_downloads(limit, only_favorites=only_favorites)
        limit = max(1, _to_int(limit, 200))
        fav = " AND favorite=1" if only_favorites else ""
        try:
            if self.fts:
                match = self._fts_query(text)
                if match:
                    # On ne remonte que les correspondances les plus recentes (2x la page
                    # demandee) : la clause IN reste petite et la recherche reste sous 10 ms.
                    cap = max(200, limit * 2)
                    ids = [r["rowid"] for r in self.query(
                        "SELECT rowid FROM downloads_fts WHERE downloads_fts MATCH ? "
                        "ORDER BY rowid DESC LIMIT ?", (match, cap))]
                    if ids:
                        # LIMIT pousse dans la requete : seules les lignes affichees sont lues
                        marks = ",".join("?" * len(ids))
                        return self._rows(
                            "SELECT * FROM downloads WHERE id IN (%s)%s"
                            " ORDER BY created_at DESC, id DESC LIMIT ?" % (marks, fav),
                            tuple(ids) + (limit,))
            like = "%" + norm(text) + "%"
            return self._rows(
                "SELECT * FROM downloads WHERE (title_norm LIKE ? OR uploader_norm LIKE ?"
                " OR LOWER(ext) LIKE ?)" + fav + " ORDER BY created_at DESC LIMIT ?",
                (like, like, like, limit),
            )
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return self.list_downloads(limit, only_favorites=only_favorites)

    def count_downloads(self, only_favorites=False):
        try:
            sql = "SELECT COUNT(*) FROM downloads" + (" WHERE favorite=1" if only_favorites else "")
            return _to_int(self.query_one(sql)[0])
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return 0

    def get_download(self, row_id):
        try:
            row = self.query_one("SELECT * FROM downloads WHERE id=?", (_to_int(row_id),))
            return dict(row) if row else None
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return None

    def delete_download(self, row_id):
        try:
            self._write("DELETE FROM downloads WHERE id=?", (_to_int(row_id),))
            self._fts_del(_to_int(row_id))
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def clear_downloads(self, keep_favorites=True):
        """Vide l'historique. Les favoris sont conserves par defaut. Retourne le nombre de lignes."""
        try:
            before = self.count_downloads()
            self._write("DELETE FROM downloads" + (" WHERE favorite=0" if keep_favorites else ""))
            if self.fts:
                if keep_favorites:
                    # On retire seulement les lignes d'index devenues orphelines
                    alive = {r["id"] for r in self.query("SELECT id FROM downloads")}
                    stale = [r["rowid"] for r in self.query("SELECT rowid FROM downloads_fts")
                             if r["rowid"] not in alive]
                    if stale:
                        self._write_many("DELETE FROM downloads_fts WHERE rowid=?", [(v,) for v in stale])
                else:
                    self._write("DELETE FROM downloads_fts")
            return before - self.count_downloads()
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return 0

    def prune_missing_downloads(self, keep_favorites=True):
        """Gestion avancee : supprime les telechargements dont le fichier n'existe plus.

        Les favoris sont conserves par defaut (meme s'ils sont devenus orphelins).
        Retourne le nombre de lignes supprimees.
        """
        try:
            rows = self.query(
                "SELECT id, filepath FROM downloads"
                " WHERE filepath IS NOT NULL AND filepath != ''"
                + (" AND favorite=0" if keep_favorites else ""))
            victims = [r["id"] for r in rows if not os.path.isfile(str(r["filepath"]))]
            if victims:
                self._write_many("DELETE FROM downloads WHERE id=?", [(v,) for v in victims])
                if self.fts:
                    self._write_many("DELETE FROM downloads_fts WHERE rowid=?", [(v,) for v in victims])
            return len(victims)
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return 0

    def set_download_favorite(self, row_id, value=True):
        try:
            self._write("UPDATE downloads SET favorite=? WHERE id=?",
                        (1 if value else 0, _to_int(row_id)))
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def mark_download_played(self, row_id):
        """Comptabilise une lecture (compteur + date + agregat du jour)."""
        try:
            self._write("UPDATE downloads SET plays=plays+1, last_played=? WHERE id=?",
                        (time.time(), _to_int(row_id)))
            self._bump_day(time.time(), plays=1)
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    # ------------------------------------------------------------------ mediatheque
    def sync_library(self, files, prune=True):
        """Indexe les fichiers trouves sur le disque.

        `files` : liste de dicts {path, title, ext, size, mtime}.
        Les lignes disparues sont supprimees, sauf si elles sont en favori (marquees `present=0`).
        Retourne (ajoutes, mis_a_jour, disparus).
        """
        now = time.time()
        added = updated = 0
        try:
            known = {r["path"]: dict(r) for r in self.query("SELECT * FROM library")}
            rows, seen = [], set()
            for item in files or ():
                path = str(item.get("path") or "")
                if not path:
                    continue
                seen.add(path)
                title = str(item.get("title") or os.path.basename(path))
                prev = known.get(path)
                if prev is None:
                    added += 1
                elif (prev.get("size") != _to_int(item.get("size"))
                      or float(prev.get("mtime") or 0) != _to_float(item.get("mtime"))):
                    updated += 1
                rows.append({
                    "path": path,
                    "title": title,
                    "title_norm": norm(title),
                    "ext": str(item.get("ext") or os.path.splitext(path)[1].lstrip(".")).lower(),
                    "size": _to_int(item.get("size")),
                    "mtime": _to_float(item.get("mtime")),
                    "now": now,
                })
            gone = [p for p in known if p not in seen]
            kept = [p for p in gone if known[p].get("favorite")] if prune else []
            drop = [p for p in gone if not known[p].get("favorite")] if prune else []
            # Un seul commit pour toute la synchro (insertions + mises a jour + disparitions)
            with self.tx() as con:
                if rows:
                    con.executemany(_UPSERT_LIBRARY, rows)
                if drop:
                    con.executemany("DELETE FROM library WHERE path=?", [(p,) for p in drop])
                if kept:
                    con.executemany("UPDATE library SET present=0 WHERE path=?", [(p,) for p in kept])
            return added, updated, (len(gone) if prune else 0)
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return 0, 0, 0

    def list_library(self, limit=400, only_favorites=False, include_missing=False):
        try:
            where = []
            if only_favorites:
                where.append("favorite=1")
            if not include_missing:
                where.append("present=1")
            sql = "SELECT * FROM library"
            if where:
                sql += " WHERE " + " AND ".join(where)
            sql += " ORDER BY mtime DESC, title COLLATE NOCASE LIMIT ?"
            return self._rows(sql, (max(1, _to_int(limit, 400)),))
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return []

    def search_library(self, text, limit=400, only_favorites=False):
        """Recherche dans la mediatheque (accent/casse insensibles)."""
        text = (text or "").strip()
        if not text:
            return self.list_library(limit, only_favorites=only_favorites)
        like = "%" + norm(text) + "%"
        try:
            return self._rows(
                "SELECT * FROM library WHERE present=1 AND (title_norm LIKE ? OR ext LIKE ?)"
                + (" AND favorite=1" if only_favorites else "")
                + " ORDER BY mtime DESC LIMIT ?",
                (like, like, max(1, _to_int(limit, 400))),
            )
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return []

    def count_library(self, only_favorites=False):
        try:
            sql = "SELECT COUNT(*) FROM library WHERE present=1"
            if only_favorites:
                sql += " AND favorite=1"
            return _to_int(self.query_one(sql)[0])
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return 0

    def set_library_favorite(self, path, value=True):
        try:
            self._write("UPDATE library SET favorite=? WHERE path=?",
                        (1 if value else 0, str(path)))
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def mark_library_played(self, path):
        try:
            self._write("UPDATE library SET plays=plays+1, last_played=? WHERE path=?",
                        (time.time(), str(path)))
            self._bump_day(time.time(), plays=1)
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def remove_library(self, path):
        try:
            self._write("DELETE FROM library WHERE path=?", (str(path),))
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    # ------------------------------------------------------------------ journal
    def log(self, level, message, ctx=""):
        """Ecrit une ligne de journal (puis purge les plus anciennes)."""
        try:
            self._write("INSERT INTO logs(ts, level, message, ctx) VALUES(?, ?, ?, ?)",
                        (time.time(), str(level or "info")[:16], str(message or "")[:2000],
                         str(ctx or "")[:2000]))
            self.prune_logs()
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def prune_logs(self, keep=LOG_KEEP):
        try:
            total = _to_int(self.query_one("SELECT COUNT(*) FROM logs")[0])
            if total <= keep:
                return 0
            victims = [r["id"] for r in self.query(
                "SELECT id FROM logs ORDER BY ts DESC LIMIT -1 OFFSET ?", (max(0, int(keep)),))]
            if victims:
                self._write_many("DELETE FROM logs WHERE id=?", [(v,) for v in victims])
            return len(victims)
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return 0

    def list_logs(self, limit=200, level=None):
        try:
            if level:
                return self._rows(
                    "SELECT * FROM logs WHERE level=? ORDER BY ts DESC, id DESC LIMIT ?",
                    (str(level), max(1, _to_int(limit, 200))))
            return self._rows("SELECT * FROM logs ORDER BY ts DESC, id DESC LIMIT ?",
                              (max(1, _to_int(limit, 200)),))
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return []

    def clear_logs(self):
        try:
            self._write("DELETE FROM logs")
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    # ------------------------------------------------------------------ statistiques
    def stats(self, days=14):
        """Tableau de bord complet en une passe (bouton STATS)."""
        out = {
            "db_path": self.path, "db_size": self.file_size(), "schema": DB_SCHEMA_VERSION,
            "fts": self.fts, "downloads": 0, "errors": 0, "favorites": 0, "plays": 0,
            "bytes": 0, "video": 0, "audio": 0, "last": None, "library": 0,
            "library_bytes": 0, "library_favorites": 0, "library_missing": 0, "logs": 0,
            "top_sites": [], "daily": [],
        }
        try:
            row = self.query_one(
                "SELECT COUNT(*) n, COALESCE(SUM(error != ''), 0) err, COALESCE(SUM(favorite), 0) fav,"
                " COALESCE(SUM(plays), 0) p, COALESCE(SUM(size), 0) b,"
                " COALESCE(SUM(kind='audio'), 0) a, COALESCE(MAX(created_at), 0) last FROM downloads")
            if row:
                out.update({
                    "downloads": _to_int(row["n"]), "errors": _to_int(row["err"]),
                    "favorites": _to_int(row["fav"]), "plays": _to_int(row["p"]),
                    "bytes": _to_int(row["b"]), "audio": _to_int(row["a"]),
                    "video": _to_int(row["n"]) - _to_int(row["a"]),
                    "last": datetime.fromtimestamp(row["last"]).strftime("%d/%m/%Y %H:%M")
                            if row["last"] else None,
                })
            lib = self.query_one(
                "SELECT COALESCE(SUM(present), 0) n, COALESCE(SUM(size), 0) b,"
                " COALESCE(SUM(favorite), 0) f, COALESCE(SUM(present=0), 0) m FROM library")
            if lib:
                out.update({
                    "library": _to_int(lib["n"]), "library_bytes": _to_int(lib["b"]),
                    "library_favorites": _to_int(lib["f"]), "library_missing": _to_int(lib["m"]),
                })
            out["logs"] = _to_int(self.query_one("SELECT COUNT(*) FROM logs")[0])
            out["top_sites"] = self._rows(
                "SELECT CASE WHEN extractor != '' THEN extractor ELSE 'autre' END site,"
                " COUNT(*) n, COALESCE(SUM(size), 0) b FROM downloads"
                " GROUP BY site ORDER BY n DESC LIMIT 6")
            out["daily"] = self._rows(
                "SELECT day, downloads, errors, bytes, plays FROM daily ORDER BY day DESC LIMIT ?",
                (max(1, _to_int(days, 14)),))
            out["daily"].reverse()
        except (sqlite3.Error, TypeError) as exc:
            self.last_error = str(exc)
        return out

    # ------------------------------------------------------------------ maintenance
    def file_size(self):
        try:
            return os.path.getsize(self.path)
        except OSError:
            return 0

    def checkpoint(self):
        """Force l'ecriture du journal WAL dans le fichier principal (arret propre)."""
        try:
            with self._lock:
                self.con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def optimize(self):
        """Checkpoint WAL + VACUUM + ANALYZE : compacte le fichier et accelere les requetes."""
        try:
            with self._lock:
                con = self.con
                con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                con.execute("VACUUM")
                con.execute("ANALYZE")
            return True
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return False

    def integrity_check(self):
        """Verifie l'integrite du fichier ('ok' si tout va bien)."""
        try:
            return str(self.query_one("PRAGMA integrity_check")[0])
        except sqlite3.Error as exc:
            self.last_error = str(exc)
            return "erreur: " + str(exc)

    def backup(self, folder=None, keep=DB_BACKUP_KEEP):
        """Sauvegarde coherente de la base (API sqlite3.backup). Retourne le chemin du fichier."""
        folder = folder or self.backup_dir
        try:
            os.makedirs(folder, exist_ok=True)
            # horodatage a la milliseconde : les sauvegardes rapprochees ne s'ecrasent plus
            stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime())
            stamp += "-%03d" % int((time.time() % 1) * 1000)
            target = os.path.join(folder, "chape_media-%s.db" % stamp)
            n = 1
            while os.path.exists(target):
                target = os.path.join(folder, "chape_media-%s-%d.db" % (stamp, n))
                n += 1
            with self._lock:
                dest = sqlite3.connect(target)
                try:
                    self.con.backup(dest)
                finally:
                    dest.close()
            backups = sorted(f for f in os.listdir(folder)
                             if f.startswith("chape_media-") and f.endswith(".db"))
            for old in (backups[:-keep] if keep > 0 else backups):
                try:
                    os.remove(os.path.join(folder, old))
                except OSError:
                    pass
            self.log("info", "Sauvegarde de la base creee", target)
            return target
        except (sqlite3.Error, OSError) as exc:
            self.last_error = str(exc)
            return None

    def export_history_json(self, path=None):
        """Export lisible (JSON) de l'historique et de la mediatheque."""
        import json

        target = path or os.path.join(os.path.dirname(self.path), "export_chape_media.json")
        try:
            payload = {
                "exported_at": datetime.now().isoformat(timespec="seconds"),
                "schema": DB_SCHEMA_VERSION,
                "downloads": self.list_downloads(limit=DOWNLOAD_KEEP),
                "library": self.list_library(limit=5000),
                "stats": self.stats(),
            }
            with open(target, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            self.log("info", "Export JSON de la base", target)
            return target
        except (OSError, TypeError, ValueError) as exc:
            self.last_error = str(exc)
            return None

    def export_history_csv(self, path=None):
        """Export tableur (CSV) de l'historique des telechargements.

        Separateur point-virgule et BOM UTF-8 : le fichier s'ouvre directement dans Excel
        (accent et caracteres francais corrects), contrairement a un CSV a virgules.
        """
        import csv

        target = path or os.path.join(os.path.dirname(self.path), "export_chape_media.csv")
        colonnes = [
            ("id", "Identifiant"),
            ("title", "Titre"),
            ("kind", "Type"),
            ("ext", "Format"),
            ("quality", "Qualite"),
            ("uploader", "Auteur"),
            ("extractor", "Plateforme"),
            ("duration", "Duree"),
            ("size", "Taille (octets)"),
            ("status", "Statut"),
            ("error", "Erreur"),
            ("favorite", "Favori"),
            ("plays", "Lectures"),
            ("date", "Date"),
            ("url", "URL"),
            ("filepath", "Fichier"),
        ]
        try:
            # utf-8-sig : ajoute le BOM attendu par Excel (sinon les accents sont illisibles).
            with open(target, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f, delimiter=";", quoting=csv.QUOTE_MINIMAL)
                w.writerow([label for _, label in colonnes])
                for row in self.list_downloads(limit=DOWNLOAD_KEEP):
                    line = []
                    for key, _ in colonnes:
                        val = row[key] if key in row.keys() else ""
                        if key == "favorite":
                            val = "oui" if val else "non"
                        line.append("" if val is None else val)
                    w.writerow(line)
            self.log("info", "Export CSV de la base", target)
            return target
        except (OSError, TypeError, ValueError) as exc:
            self.last_error = str(exc)
            return None

    def info(self):
        """Resume technique (panneau STATS / journal)."""
        try:
            journal = str(self.query_one("PRAGMA journal_mode")[0])
        except sqlite3.Error:
            journal = "?"
        try:
            tables = [r["name"] for r in self.query(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        except sqlite3.Error:
            tables = []
        try:
            backups = sorted(f for f in os.listdir(self.backup_dir) if f.startswith("chape_media-"))
        except OSError:
            backups = []
        return {"path": self.path, "size": self.file_size(), "journal": journal, "fts": self.fts,
                "schema": DB_SCHEMA_VERSION, "tables": tables, "backups": backups}


# ---------------------------------------------------------------------- requetes
_INSERT_DOWNLOAD = (
    "INSERT INTO downloads ("
    "id, url, title, title_norm, uploader, uploader_norm, kind, ext, quality, extractor,"
    " filepath, thumbnail, size, duration, status, error, favorite, plays,"
    " created_at, date, finished_at) "
    "VALUES (:id, :url, :title, :title_norm, :uploader, :uploader_norm, :kind, :ext,"
    " :quality, :extractor, :filepath, :thumbnail, :size, :duration, :status, :error,"
    " COALESCE((SELECT favorite FROM downloads WHERE id=:id), 0),"
    " COALESCE((SELECT plays FROM downloads WHERE id=:id), 0),"
    " :created_at, :date, :finished_at) "
    "ON CONFLICT(id) DO UPDATE SET "
    " url=excluded.url, title=excluded.title, title_norm=excluded.title_norm,"
    " uploader=excluded.uploader, uploader_norm=excluded.uploader_norm, kind=excluded.kind,"
    " ext=excluded.ext, quality=excluded.quality, extractor=excluded.extractor,"
    " filepath=excluded.filepath, thumbnail=excluded.thumbnail, size=excluded.size,"
    " duration=excluded.duration, status=excluded.status, error=excluded.error,"
    " date=excluded.date, finished_at=excluded.finished_at"
)

_BUMP_DAY = (
    "INSERT INTO daily(day, downloads, errors, bytes, plays) VALUES(?, ?, ?, ?, ?) "
    "ON CONFLICT(day) DO UPDATE SET "
    " downloads=downloads+excluded.downloads, errors=errors+excluded.errors,"
    " bytes=bytes+excluded.bytes, plays=plays+excluded.plays"
)

_UPSERT_LIBRARY = (
    "INSERT INTO library(path, title, title_norm, ext, size, mtime, first_seen,"
    " last_seen, present) VALUES(:path, :title, :title_norm, :ext, :size, :mtime,"
    " :now, :now, 1) ON CONFLICT(path) DO UPDATE SET title=excluded.title,"
    " title_norm=excluded.title_norm, ext=excluded.ext, size=excluded.size,"
    " mtime=excluded.mtime, last_seen=excluded.last_seen, present=1"
)


# ---------------------------------------------------------------------- schema SQL
# Execute a chaque ouverture : CREATE ... IF NOT EXISTS est idempotent.
_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS settings ("
    " key TEXT PRIMARY KEY, value TEXT NOT NULL)",

    "CREATE TABLE IF NOT EXISTS downloads ("
    " id INTEGER PRIMARY KEY, url TEXT, title TEXT NOT NULL DEFAULT '',"
    " title_norm TEXT NOT NULL DEFAULT '', uploader TEXT DEFAULT '', uploader_norm TEXT DEFAULT '',"
    " kind TEXT DEFAULT 'video', ext TEXT DEFAULT '', quality TEXT DEFAULT '',"
    " extractor TEXT DEFAULT '', filepath TEXT, thumbnail TEXT, size INTEGER NOT NULL DEFAULT 0,"
    " duration TEXT DEFAULT '', status TEXT DEFAULT 'OK', error TEXT DEFAULT '',"
    " favorite INTEGER NOT NULL DEFAULT 0, plays INTEGER NOT NULL DEFAULT 0, last_played REAL,"
    " created_at REAL NOT NULL, date TEXT NOT NULL DEFAULT '', finished_at REAL)",
    "CREATE INDEX IF NOT EXISTS idx_dl_created ON downloads(created_at DESC)",
    "CREATE INDEX IF NOT EXISTS idx_dl_title ON downloads(title_norm)",
    "CREATE INDEX IF NOT EXISTS idx_dl_fav ON downloads(favorite, created_at DESC)",

    "CREATE TABLE IF NOT EXISTS library ("
    " path TEXT PRIMARY KEY, title TEXT DEFAULT '', title_norm TEXT DEFAULT '', ext TEXT DEFAULT '',"
    " size INTEGER NOT NULL DEFAULT 0, mtime REAL NOT NULL DEFAULT 0,"
    " favorite INTEGER NOT NULL DEFAULT 0, plays INTEGER NOT NULL DEFAULT 0, last_played REAL,"
    " first_seen REAL, last_seen REAL, present INTEGER NOT NULL DEFAULT 1)",
    "CREATE INDEX IF NOT EXISTS idx_lib_title ON library(title_norm)",
    "CREATE INDEX IF NOT EXISTS idx_lib_fav ON library(favorite, mtime DESC)",

    "CREATE TABLE IF NOT EXISTS logs ("
    " id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL,"
    " level TEXT NOT NULL DEFAULT 'info', message TEXT NOT NULL DEFAULT '', ctx TEXT DEFAULT '')",
    "CREATE INDEX IF NOT EXISTS idx_log_ts ON logs(ts DESC)",

    "CREATE TABLE IF NOT EXISTS daily ("
    " day TEXT PRIMARY KEY, downloads INTEGER NOT NULL DEFAULT 0,"
    " errors INTEGER NOT NULL DEFAULT 0, bytes INTEGER NOT NULL DEFAULT 0,"
    " plays INTEGER NOT NULL DEFAULT 0)",
)

