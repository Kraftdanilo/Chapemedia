"""Constantes, chemins et configuration globale de CHAPE-MEDIA."""
import os
import sys

APP_NAME = "CHAPE-MEDIA"

# ---------------- Version & mise a jour ----------------
# APP_VERSION est la SOURCE UNIQUE de la version : elle alimente l'interface, les
# proprietes Windows de l'exe (scripts/gen_version_file.py), le nom du paquet et le
# manifest.json publie par scripts/make_release.ps1. Rien d'autre ne porte de version.
APP_VERSION = "1.0.5"
# Edition d'affichage : garde la version technique intacte (updater, manifest)
# tout en affichant "1.0.4 remix" dans l'interface.
APP_EDITION = "remix"
APP_DISPLAY_VERSION = APP_VERSION + (" " + APP_EDITION if APP_EDITION else "")
APP_CHANNEL = "stable"        # "stable" | "beta" : le manifest peut publier plusieurs canaux
# Emplacements du manifeste de mise a jour, tries par ordre de priorite.
# manifest.json peut etre servi par n'importe quoi : GitHub/GitHub Raw, Forgejo,
# serveur HTTP interne, simple partage reseau, ou cle USB (chemin de dossier).
# Surcharge sans recompiler : reglage "update_url" (base SQLite) ou variable
# d'environnement CHAPE_MEDIA_UPDATE_URL.
UPDATE_URLS = [
    "https://raw.githubusercontent.com/Kraftdanilo/Chapemedia/main/release/manifest.json",
]
UPDATE_MANIFEST = "manifest.json"
UPDATE_TIMEOUT = 12.0         # s : ne jamais bloquer l'interface si le serveur ne repond pas
UPDATE_CHUNK = 256 * 1024     # 256 Ko par paquet pendant le telechargement du paquet


VIDEO_EXTS = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v", ".flv", ".ts", ".wmv"}
AUDIO_EXTS = {".mp3", ".m4a", ".m4b", ".opus", ".ogg", ".oga", ".wav", ".flac", ".aac", ".wma"}
ALL_MEDIA = VIDEO_EXTS | AUDIO_EXTS

# Repertoires de base
# En mode compile (Nuitka/PyInstaller), __file__ pointe vers un emplacement temporaire :
# on remonte alors au dossier de l'executable, la ou vivent web/ et ffmpeg.exe.
_IS_FROZEN = "__compiled__" in globals() or getattr(sys, "frozen", False)
IS_FROZEN = _IS_FROZEN
if _IS_FROZEN:
    _MEI = getattr(sys, "_MEIPASS", None)
    BASE_DIR = _MEI if (_MEI and os.path.isdir(os.path.join(_MEI, "web"))) \
        else os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Dossier "programme" : celui de l'executable, c'est lui que la mise a jour remplace
# (BASE_DIR peut pointer vers _internal en mode PyInstaller 6, ce n'est pas le bon).
APP_DIR = os.path.dirname(os.path.abspath(sys.executable)) if _IS_FROZEN else BASE_DIR

WEB_DIR = os.path.join(BASE_DIR, "web")
# Le dossier de donnees peut etre redirige (tests isoles, cle USB, multi-profils)
APP_DATA = os.environ.get("CHAPE_MEDIA_DATA") or os.path.join(os.path.expanduser("~"), ".chape_media")
# Anciens fichiers JSON : conserves uniquement pour la migration automatique vers SQLite
HISTORY_FILE = os.path.join(APP_DATA, "history.json")
CONFIG_FILE = os.path.join(APP_DATA, "config.json")
os.makedirs(APP_DATA, exist_ok=True)

# ---------------- Ports reseau locaux ----------------
# Modifiables sans recompiler : variable d'environnement, sinon reglage en base.
# API_PORT     : API REST FastAPI (127.0.0.1 uniquement)
# MEDIA_PORT   : serveur de streaming des medias (0.0.0.0, partage reseau)
# INSTANCE_PORT: verrou d'instance unique (socket garde ouvert)
_DEFAULT_PORTS = {"api_port": 8928, "media_port": 8929, "instance_port": 8907}


def _port_setting(key, env_name, config_key=None):
    """Port effectif : env > reglage en base (config.json) > defaut.

    Accepte uniquement 1024-65535 ; toute valeur invalide retombe sur le defaut.
    """
    raw = os.environ.get(env_name)
    if not raw and config_key:
        try:
            import json
            path = os.path.join(APP_DATA, "config.json")
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    raw = json.load(f).get(config_key)
        except (OSError, ValueError, AttributeError):
            raw = None
    try:
        port = int(raw) if raw not in (None, "") else _DEFAULT_PORTS[key]
    except (TypeError, ValueError):
        port = _DEFAULT_PORTS[key]
    return port if 1024 <= port <= 65535 else _DEFAULT_PORTS[key]


API_PORT = _port_setting("api_port", "CHAPE_MEDIA_API_PORT", "api_port")
MEDIA_PORT = _port_setting("media_port", "CHAPE_MEDIA_MEDIA_PORT", "media_port")
INSTANCE_PORT = _port_setting("instance_port", "CHAPE_MEDIA_INSTANCE_PORT", "instance_port")
# Ports de repli si celui demande est deja occupe (jamais un port fixe qui bloque l'app).
API_PORT_FALLBACKS = tuple(p for p in (API_PORT + 1, API_PORT + 2, API_PORT + 10) if p <= 65535)

# ---------------- Base de donnees SQLite ----------------
DB_FILE = os.path.join(APP_DATA, "chape_media.db")
DB_BACKUP_DIR = os.path.join(APP_DATA, "backups")
DB_SCHEMA_VERSION = 1       # incrementer a chaque evolution du schema (migrations)
DB_BUSY_TIMEOUT = 5000      # ms d'attente si la base est verrouillee par un autre thread
LOG_KEEP = 800              # lignes de journal conservees (les plus anciennes sont purgees)
DOWNLOAD_KEEP = 2000        # telechargements conserves (les plus anciens sont purges)
DB_BACKUP_KEEP = 8          # nombre de sauvegardes .db conservees

# Cache disque persistant (extracteurs yt-dlp, JS YouTube...) : analyses suivantes plus rapides
CACHE_DIR = os.path.join(APP_DATA, "cache")
os.makedirs(CACHE_DIR, exist_ok=True)

# Vignettes des videos, telechargees UNE fois puis servies depuis le disque local.
# Pourquoi : les hotlinks de vignettes (i.ytimg.com...) expirent, cassent ou bloquent
# le referer -> l'historique affichait des images brisees. En local, la vignette reste
# disponible hors ligne et n'est plus re-telechargee a chaque affichage.
THUMBS_DIR = os.path.join(APP_DATA, "thumbs")
os.makedirs(THUMBS_DIR, exist_ok=True)
THUMB_MAX = 120             # nombre de vignettes conservees sur le disque (les plus anciennes sont purgees)

# ---------------- Reglages de performance (boost) ----------------
FRAGMENT_WORKERS = 4            # fragments telecharges en parallele (yt-dlp concurrent_fragment_downloads)
NET_BUFFER = 1024 * 1024        # 1 Mo de buffer reseau -> moins d'ecritures disque
STREAM_CHUNK = 256 * 1024       # 256 Ko par paquet servi par le serveur local (lecture/seek fluides)
LIB_CACHE_TTL = 3.0             # duree (s) du cache du scan de la mediatheque
EVENT_QUEUE_MAX = 120           # taille max de la file d'evenements en attente de lecture
INFO_CACHE_TTL = 1800.0         # duree (s) du cache memoire des metadonnees oEmbed
POLL_WAIT_MAX = 25.0            # attente maxi (s) du long-polling des evenements


def ffmpeg_path():
    """Localise l'executable ffmpeg : a cote de l'app, sinon dans le PATH systeme."""
    for name in ("ffmpeg.exe", "ffmpeg"):
        p = os.path.join(BASE_DIR, name)
        if os.path.exists(p):
            return p
    from shutil import which
    return which("ffmpeg")


# Dossier de travail des mises a jour (telechargement + decompressement) : il vit dans
# les donnees utilisateur, jamais dans le dossier programme, pour ne rien corrompre.
UPDATE_DIR = os.path.join(APP_DATA, "update")
os.makedirs(UPDATE_DIR, exist_ok=True)
UPDATE_STAGE_DIR = os.path.join(UPDATE_DIR, "stage")


def version_tuple(value=None):
    """Renvoie une comparaison fiable : "v1.2" -> (1, 2, 0), "1.10.3" -> (1, 10, 3, 0).

    Seuls les chiffres de tete de chaque segment comptent : un suffixe de canal
    ("1.0.0b2") est ignore, donc une beta ne remplace jamais la version finale
    portant le meme numero. Aucune exception n'est levee (version vide -> 0.0.0),
    condition indispensable pour qu'une publication hasardeuse ne bloque pas l'app.
    """
    src = APP_VERSION if value is None else str(value or "")
    parts = []
    for chunk in src.strip().lstrip("vV").replace("-", ".").split("."):
        digits = ""
        for char in chunk:
            if not char.isdigit():
                break
            digits += char
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def is_newer(candidate, current=None):
    """Vrai si `candidate` est strictement plus recente que `current` (APP_VERSION par defaut)."""
    new, old = version_tuple(candidate), version_tuple(current)
    size = max(len(new), len(old))
    return new + (0,) * (size - len(new)) > old + (0,) * (size - len(old))

