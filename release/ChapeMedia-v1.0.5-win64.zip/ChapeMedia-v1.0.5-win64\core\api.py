"""Passerelle API du backend : chaque methode publique est exposee en REST
par server.py (POST/GET /api/<nom>). Le front y accede via web/bridge.js."""
import os
import threading
import time
import urllib.parse
from .config import (APP_CHANNEL, APP_DATA, APP_DIR, APP_DISPLAY_VERSION, APP_NAME, APP_VERSION, EVENT_QUEUE_MAX,
                     LIB_CACHE_TTL, MEDIA_PORT, POLL_WAIT_MAX)
from .config import AUDIO_EXTS, VIDEO_EXTS
from .downloader import Downloader
from .file_manager import FileManager
from .storage import StorageManager
from .stream import MediaServer
from .updater import Updater


class Api:
    """Metier expose au front via FastAPI (server.py)."""

    def __init__(self):
        self.events = []
        self.lock = threading.Lock()
        # Fermeture demandee par le metier (installation d'une mise a jour) : `app.py`
        # y branche la fermeture de la fenetre. Le metier ne tue jamais le processus.
        self.request_close = None
        self.storage = StorageManager()
        self._lib_cache = []      # cache du scan de la mediatheque (evite de rescanner a chaque refresh)
        self._lib_time = 0.0

        self.config = self.storage.load_config()
        # Mise a jour : la source peut etre choisie par l'utilisateur (reglage "update_url"),
        # sinon la variable d'environnement, sinon la liste par defaut de core/config.py.
        self._update_thread = None
        self.updater = Updater(on_event=self._push_event,
                               update_url=self.config.get("update_url"))
        # Menage : si une mise a jour vient d'etre installee, le script d'echange et la
        # version decompressee sont encore la. On ne touche jamais aux donnees.
        self.updater.cleanup()
        self.storage.log(
            "info", "Demarrage de %s" % APP_NAME,
            "base=%s schema=%s fts=%s" % (self.storage.db.path, self.storage.info().get("schema"),
                                          self.storage.info().get("fts")),
        )

        default_dir = os.path.join(os.path.expanduser("~"), "Downloads", "CHAPE-MEDIA")
        os.makedirs(default_dir, exist_ok=True)
        self.download_dir = self.config.get("download_dir", default_dir)
        if not isinstance(self.download_dir, str) or not self.download_dir:
            self.download_dir = default_dir
        try:
            os.makedirs(self.download_dir, exist_ok=True)
        except OSError:
            self.download_dir = default_dir
            os.makedirs(self.download_dir, exist_ok=True)

        self.player_enabled = bool(self.config.get("player_enabled", True))
        self._mute_busy = False     # une seule conversion ffmpeg a la fois
        # Port de streaming : reglage en base, sinon MEDIA_PORT de core/config.py.
        try:
            media_port = int(self.config.get("media_port") or MEDIA_PORT)
        except (TypeError, ValueError):
            media_port = MEDIA_PORT

        self.server = MediaServer(default_port=media_port)
        # Portee du serveur media (0.0.0.0) : uniquement les donnees de l'app et le
        # dossier de telechargement. A poser AVANT start() pour qu'une requete arrivee
        # dans la fenetre de demarrage soit deja filtree.
        # APP_DATA en entier exclurait chape_media.db (historique, reglages) : on ne
        # publie que le dossier des medias de l'app.
        self.server.set_roots(os.path.join(APP_DATA, "thumbs"), self.download_dir)
        actual_port = self.server.start()
        if actual_port:
            self.media_port = actual_port
        else:
            self.media_port = media_port

        self.downloader = Downloader(
            download_dir_getter=lambda: self.download_dir,
            on_event_callback=self._push_event,
            on_complete_callback=self._on_download_complete,
        )

    def _push_event(self, ev):
        with self.lock:
            self.events.append(ev)
            if len(self.events) > EVENT_QUEUE_MAX:
                # File bornee : on jette les vieux evenements de progression (deja perimes)
                del self.events[: len(self.events) - EVENT_QUEUE_MAX // 2]

    def _drain_events(self):
        with self.lock:
            ev, self.events = self.events, []
        return ev

    def _invalidate_library(self):
        """Force le prochain scan_library() a relire le disque."""
        self._lib_cache = []
        self._lib_time = 0.0

    def _ensure_library_synced(self, force=False):
        """Synchronise la table `library` de la base avec le dossier puis met le cache a jour.

        Boost : le disque n'est lu qu'une fois toutes les LIB_CACHE_TTL secondes ; entre-temps
        l'interface est servie par SQLite (lecture quasi instantanee, favoris et lectures inclus).
        """
        now = time.time()
        if not force and self._lib_cache and (now - self._lib_time) < LIB_CACHE_TTL:
            return self._lib_cache
        data = FileManager.scan_library(self.download_dir, max_files=200)
        # Scan tronque (dossier charge) : la purge effacerait des fichiers encore presents.
        self.storage.sync_library(data, prune=not getattr(data, "truncated", False))
        rows = self.storage.list_library(limit=400)
        self._lib_cache = rows if rows else data   # si la base est indisponible, on sert le disque
        self._lib_time = now
        return self._lib_cache

    def _on_download_complete(self, entry):
        """Telechargement termine : historique + journal + index de la mediatheque en base."""
        self.storage.add_download(entry)
        self._invalidate_library()  # le nouveau fichier doit apparaitre au prochain refresh

    def get_config(self):
        return {
            "download_dir": self.download_dir,
            "player_enabled": self.player_enabled,
            "media_port": self.media_port,
            "profile_name": self.config.get("profile_name", ""),
            "profile_photo": self.config.get("profile_photo", ""),
        }

    # ------------------------------------------------------------------ profil utilisateur
    def get_profile(self):
        """Profil local : nom et photo choisis par l'utilisateur (stockes en base)."""
        photo = self.config.get("profile_photo", "")
        if photo and not os.path.isfile(photo):
            photo = ""
        url = ""
        if photo:
            try:
                url = self.server.profile_url(photo)
            except Exception:
                url = ""
        # `photo` reste le chemin disque (compatibilite) ; `photo_url` est ce que le
        # front DOIT mettre dans <img src> : une URL http servie par le serveur local.
        return {"name": self.config.get("profile_name", ""), "photo": photo,
                "photo_url": url}

    def set_profile(self, name, photo=""):
        """Enregistre le profil. `photo` = chemin local d'une image copiee dans APP_DATA."""
        # Appel objet : set_profile({name, photo}) -> ne jamais stocker le dict en texte.
        if isinstance(name, dict):
            payload = name
            name = payload.get("name", "")
            photo = photo or payload.get("photo", "")
        name = str(name or "").strip()[:40]
        self.config["profile_name"] = name
        if photo:
            photo = str(photo)
            if os.path.isfile(photo):
                import shutil
                dest_dir = os.path.join(APP_DATA, "profile")
                os.makedirs(dest_dir, exist_ok=True)
                ext = os.path.splitext(photo)[1].lower() or ".png"
                dest = os.path.join(dest_dir, "avatar" + ext)
                try:
                    # save_profile_photo ecrit DEJA dans dest : copier un fichier sur
                    # lui-meme leve SameFileError (sous-classe d'OSError, donc avalee
                    # ici) et la photo etait perdue sans aucun message.
                    same = os.path.normcase(os.path.abspath(photo)) == \
                        os.path.normcase(os.path.abspath(dest))
                    if not same:
                        shutil.copyfile(photo, dest)
                    self.config["profile_photo"] = dest
                except OSError:
                    # Tout autre echec est remonte a l'interface au lieu d'etre masque.
                    self.storage.save_config({**self.config, "download_dir": self.download_dir})
                    return {**self.get_profile(), "ok": False,
                            "error": "Photo non copiee : %s" % photo}
        self.storage.save_config({**self.config, "download_dir": self.download_dir})
        return self.get_profile()

    def save_profile_photo(self, data_url):
        """Recoit une image en data-URL (base64) depuis l'interface et la stocke.

        Le navigateur ne transmet pas le chemin local d'un fichier choisi via
        <input type=file> : on transite donc par une data-URL. L'image est copiee
        dans APP_DATA/profile/avatar.* et le chemin est retourne pour set_profile.
        """
        import base64
        import binascii
        import re
        m = re.match(r"data:image/([a-zA-Z+.-]+);base64,(.+)$", str(data_url or ""), re.S)
        if not m:
            return {"ok": False, "error": "Format d'image non reconnu"}
        ext = {"jpeg": ".jpg", "jpg": ".jpg", "png": ".png", "gif": ".gif",
               "webp": ".webp", "bmp": ".bmp", "svg": ".svg"}.get(m.group(1).lower(), ".png")
        try:
            raw = base64.b64decode(m.group(2), validate=True)
        except (binascii.Error, ValueError):
            return {"ok": False, "error": "Image corrompue"}
        if len(raw) > 8 * 1024 * 1024:
            return {"ok": False, "error": "Image trop volumineuse (max 8 Mo)"}
        dest_dir = os.path.join(APP_DATA, "profile")
        try:
            os.makedirs(dest_dir, exist_ok=True)
            # une seule image garde : on supprime l'ancienne quel que soit son format
            for old in os.listdir(dest_dir):
                if old.startswith("avatar"):
                    try:
                        os.remove(os.path.join(dest_dir, old))
                    except OSError:
                        pass
            dest = os.path.join(dest_dir, "avatar" + ext)
            with open(dest, "wb") as f:
                f.write(raw)
        except OSError as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "path": dest}

    def set_player_enabled(self, enabled):
        self.player_enabled = bool(enabled)
        self.config["player_enabled"] = self.player_enabled
        self.storage.save_config({**self.config, "download_dir": self.download_dir})
        return self.player_enabled

    def set_download_dir(self, path):
        """Change et enregistre le dossier de destination (deja valide par l'appelant)."""
        path = str(path or "").strip()
        if not path or not os.path.isdir(path):
            return self.download_dir
        self.download_dir = path
        # Le serveur media doit suivre : sinon le nouveau dossier serait refuse (403)
        # et les anciens medias resteraient servis.
        self.server.set_roots(os.path.join(APP_DATA, "thumbs"), path)
        self.storage.save_config({
            **self.config,
            "download_dir": path,
            "player_enabled": self.player_enabled,
        })
        self._invalidate_library()  # nouvelle destination : rescan au prochain refresh
        return self.download_dir

    def choose_folder(self):
        """Ancien dialogue Tk : conserve pour un lancement sans fenetre pywebview.

        Le front n'emprunte plus ce chemin (il appelle le selecteur natif expose par
        `app.py`) : Tk exige le thread principal alors qu'une methode Api tourne dans
        le pool de threads du serveur. On garde neanmoins un repli fonctionnel.
        """
        d = None
        # Tk doit tourner dans le thread qui l'a cree : on lui dedie un thread court
        # (Tk accepte d'etre cree et detruit dans le meme thread secondaire).
        try:
            from tkinter import Tk, filedialog
            initial = self.download_dir
            box = {}

            def _ask():
                r = Tk()
                try:
                    r.withdraw()
                    r.attributes("-topmost", True)
                    box["dir"] = filedialog.askdirectory(initialdir=initial)
                finally:
                    r.destroy()

            t = threading.Thread(target=_ask, name="chape-folder", daemon=True)
            t.start()
            t.join(300)          # 5 min : jamais de blocage infini du pool
            d = box.get("dir")
        except Exception:
            d = None

        if d:
            self.set_download_dir(d)
        return self.download_dir

    def poll_events(self, wait_ms=0):
        """Renvoie les evenements en attente.

        Boost : si `wait_ms` > 0, l'appel reste ouvert jusqu'a l'arrivee d'un evenement
        (long-polling). Le front n'appelle donc plus le pont 2 a 3 fois par seconde dans le
        vide : beaucoup moins de POST, de JSON et de CPU pendant les telechargements.
        """
        try:
            wait = max(0.0, min(float(wait_ms or 0) / 1000.0, POLL_WAIT_MAX))
        except (TypeError, ValueError):
            wait = 0.0

        ev = self._drain_events()
        if ev or wait <= 0:
            return ev

        deadline = time.monotonic() + wait
        while time.monotonic() < deadline:
            time.sleep(0.05)
            ev = self._drain_events()
            if ev:
                break
        return ev

    def get_history(self, limit=150, favorites_only=False):
        """Historique servi par la base (du plus recent au plus ancien)."""
        rows = self.storage.list_downloads(limit=limit, favorites_only=favorites_only)
        return rows

    def search_history(self, query, limit=200):
        """Recherche plein texte dans l'historique (FTS5 : accents et casse ignores)."""
        return self.storage.search_downloads(query, limit=limit)

    def clear_history(self, keep_favorites=True):
        """Vide l'historique (les favoris sont conserves par defaut)."""
        self.storage.clear_downloads(keep_favorites=keep_favorites)
        return True

    def delete_history(self, hid):
        self.storage.delete_download(hid)
        return True

    def prune_history_missing(self):
        """Gestion avancee : retire de l'historique les entrees dont le fichier n'existe plus.

        Les favoris sont conserves. Retourne le nombre d'entrees retirees.
        """
        removed = self.storage.prune_missing_downloads()
        return {"ok": True, "removed": int(removed or 0)}

    def scan_library(self, force=False):
        """Mediatheque servie par la base (index synchronise avec le disque).

        Boost : les refresh en rafale (boot, fin de telechargement, clic) ne rescannent plus le
        disque a chaque fois ; un clic manuel sur Actualiser passe `force=True`.
        """
        return self._ensure_library_synced(force)

    def get_favorites(self):
        """Favoris ⭐ de l'historique et de la mediatheque."""
        self._ensure_library_synced(False)
        return {
            "history": self.storage.list_downloads(favorites_only=True),
            "library": self.storage.list_library(favorites_only=True, include_missing=True),
        }

    @staticmethod
    def _flip(current, value):
        """Nouvelle valeur d'un favori : bascule si `value` est None, sinon valeur demandee."""
        return (not bool(current)) if value is None else bool(value)

    def toggle_favorite(self, ident, value=None):
        """Ajoute/retire un favori. `ident` = id d'historique ou 'lib:<chemin>'."""
        s = str(ident)
        if s.startswith("lib:"):
            path = s[4:]
            row = self.storage.db.query_one("SELECT favorite FROM library WHERE path=?", (path,))
            new = self._flip(row["favorite"], value) if row else bool(value)
            if row:
                self.storage.set_library_favorite(path, new)
            return new
        rid = s if s.isdigit() else ident
        row = self.storage.db.query_one("SELECT favorite, filepath FROM downloads WHERE id=?", (rid,))
        if not row:
            return bool(value)
        new = self._flip(row["favorite"], value)
        self.storage.set_download_favorite(rid, new)
        if row["filepath"]:                     # coherence historique <-> mediatheque
            self.storage.set_library_favorite(row["filepath"], new)
        return new

    def mark_played(self, ident):
        """Comptabilise une lecture (compteur + statistiques du jour)."""
        s = str(ident)
        if s.startswith("lib:"):
            self.storage.mark_library_played(s[4:])
        elif s.isdigit():
            row = self.storage.db.query_one("SELECT filepath FROM downloads WHERE id=?", (s,))
            self.storage.mark_download_played(s)
            if row and row["filepath"]:
                self.storage.mark_library_played(row["filepath"])
        else:
            self.storage.mark_library_played(s)
        return True

    def delete_file(self, path):
        ok = FileManager.delete_file(path)
        if ok:
            self.storage.remove_library(path)
            self.storage.log("info", "Fichier supprime", str(path))
            self._invalidate_library()
        return ok

    def remove_audio(self, path):
        """Supprime le son d'une video deja telechargee (copie muette, l'original est garde).

        Tache de fond : ffmpeg peut prendre quelques secondes sur un gros fichier ; on ne
        bloque jamais l'interface. La mediatheque est rafraichie a la fin.
        """
        path = str(path or "")
        if not path or not os.path.isfile(path):
            return {"ok": False, "error": "Fichier introuvable"}
        if self._mute_busy:
            return {"ok": False, "error": "Une conversion est deja en cours"}
        self._mute_busy = True

        def _run():
            try:
                ok, res = FileManager.remove_audio(path)
                if ok:
                    self.storage.log("info", "Version sans son creee", str(res))
                    self._push_event({"type": "status", "text": "Version sans son : "
                                     + os.path.basename(str(res)), "pct": 100})
                else:
                    self.storage.log("warning", "Echec suppression du son", str(res))
                    self._push_event({"type": "error", "message": "Suppression du son : " + str(res)})
            finally:
                self._mute_busy = False
                self._invalidate_library()

        threading.Thread(target=_run, name="chape-mute", daemon=True).start()
        return {"ok": True, "started": True}

    def open_external(self, path):
        return FileManager.open_external(path)

    def open_folder(self, path):
        return FileManager.open_folder(path)

    def media_url(self, path):
        # Fichier hors des racines (video choisie ailleurs) : son dossier devient
        # lisible le temps de la session. Loopback -> le jeton n'est pas exige.
        self.server.allow_read(os.path.dirname(os.path.abspath(str(path or "."))))
        return self.server.get_url(path)

    def poster_url(self, path):
        """URL de la vignette fabriquee depuis un media local (/poster?path=...).

        Le dossier du fichier est autorise en lecture seule pour la session : une video
        choisie hors mediatheque (POSTER d'un fichier local) peut produire sa vignette.
        """
        path = str(path or "")
        if not os.path.isfile(path) or self.server.server is None:
            raise ValueError("Fichier introuvable")
        self.server.allow_read(os.path.dirname(os.path.abspath(path)))
        q = urllib.parse.quote(path, safe="")
        return self.server.sign(f"http://127.0.0.1:{self.media_port}/poster?path={q}")

    def media_kind(self, path):
        """'audio' / 'video' d'apres l'extension seule : reponse instantanee, sans ffprobe."""
        ext = os.path.splitext(str(path or ""))[1].lower()
        if ext in AUDIO_EXTS:
            return "audio"
        if ext in VIDEO_EXTS:
            return "video"
        return ""

    def media_info(self, path):
        """Nature et duree du fichier, pour preparer le lecteur (aucun blocage).

        `kind` d'abord deduit de l'extension (instantane), affine par ffprobe quand il
        est disponible : un .mkv de musique doit s'ouvrir en <audio>. `duration` evite
        au lecteur d'attendre un scan complet avant d'afficher la barre de temps.
        """
        path = str(path or "")
        if not os.path.isfile(path):
            return {"ok": False, "error": "Fichier introuvable"}
        ext = os.path.splitext(path)[1].lower()
        kind = "audio" if ext in AUDIO_EXTS else ("video" if ext in VIDEO_EXTS else "")
        info = {}
        try:
            info = self.server.probe(path) or {}
        except Exception:
            info = {}
        probed = info.get("kind") or ""
        # ffprobe a la priorite : il voit la piste reelle, pas l'extension.
        return {"ok": True, "kind": probed or kind, "duration": float(info.get("duration") or 0.0),
                "video_codec": info.get("video_codec", ""),
                "audio_codec": info.get("audio_codec", "")}

    def share_media(self, path):
        """Partage un fichier via un lien navigateur (appareils du meme reseau).

        Retourne une URL http://<ip-reseau>:<port>/share?path=... lisible par n'importe
        quel appareil connecte au meme reseau (telephone, tablette, autre PC).
        """
        path = str(path or "")
        if not os.path.isfile(path):
            return {"ok": False, "error": "Fichier introuvable"}
        try:
            url = self.server.get_url(path, lan=True)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        self.storage.log("info", "Media partage via lien reseau", url)
        return {"ok": True, "url": url}

    def thumb_url(self, remote_url):
        """URL locale d'une vignette (servie par le serveur local avec cache disque).

        Retourne l'URL distante d'origine si le serveur est indisponible : l'affichage
        ne se degrade jamais a cause du cache de vignettes.
        """
        try:
            return self.server.get_thumb_url(remote_url) or remote_url
        except Exception:
            return remote_url

    def fetch_info(self, url):
        return self.downloader.fetch_info(url)

    def start_download(self, opts):
        return self.downloader.start_download(opts)

    def cancel_queue(self):
        """Vide la file d'attente (le telechargement en cours continue jusqu'au bout)."""
        return {"ok": True, "cleared": self.downloader.cancel_all()}

    def queue_state(self):
        """Etat de la file d'attente : nombre d'elements restants."""
        return {"ok": True, "pending": self.downloader.pending_count()}

    # ------------------------------------------------------------------ base de donnees
    def get_stats(self):
        """Panneau STATS : tout est calcule en SQL (une requete par bloc)."""
        stats = self.storage.stats()
        stats["download_dir"] = self.download_dir
        stats["media_port"] = self.media_port
        stats["app_data"] = APP_DATA
        stats["queue"] = len(self.events)
        return stats

    def get_logs(self, limit=200, level=None):
        """Journal applicatif (onglet JOURNAL) : plus recent en premier."""
        try:
            limit = max(1, min(int(limit or 200), 1000))
        except (TypeError, ValueError):
            limit = 200
        return self.storage.list_logs(limit=limit, level=level or None)

    def clear_logs(self):
        return self.storage.clear_logs()

    def export_history(self):
        """Ecrit un export JSON lisible de la base et retourne le chemin du fichier."""
        path = self.storage.export_json()
        if path:
            self.storage.log("info", "Export JSON demande par l'utilisateur", path)
        return {"ok": bool(path), "path": path or ""}

    def export_csv(self):
        """Ecrit un export CSV (tableur) de l'historique et retourne le chemin du fichier."""
        path = self.storage.export_csv()
        if path:
            self.storage.log("info", "Export CSV demande par l'utilisateur", path)
        return {"ok": bool(path), "path": path or ""}

    def backup_db(self):
        """Sauvegarde la base SQLite (fichier .db horodate)."""
        path = self.storage.backup()
        return {"ok": bool(path), "path": path or "", "size": self.storage.file_size()}

    def optimize_db(self):
        """Compacte la base (VACUUM + ANALYZE) et verifie son integrite."""
        before = self.storage.file_size()
        ok = self.storage.optimize()
        return {"ok": bool(ok), "before": before, "after": self.storage.file_size(),
                "integrity": self.storage.integrity_check()}

    def open_db_folder(self):
        """Ouvre le dossier contenant la base dans l'explorateur."""
        return FileManager.open_folder(self.storage.db.path)

    def db_info(self):
        """Informations techniques sur la base (tables, taille, journal WAL, sauvegardes)."""
        info = dict(self.storage.info())
        info["downloads"] = self.storage.count_downloads()
        info["library"] = self.storage.count_library()
        info["logs"] = len(self.storage.list_logs(limit=1000))
        return info

    # ------------------------------------------------------------ mise a jour
    def get_version(self):
        """Version installee + etat du mecanisme de mise a jour (affiche dans l'interface)."""
        info = self.updater.status()
        info["name"] = APP_NAME
        info["data_dir"] = APP_DATA
        info["app_version"] = APP_VERSION
        info["display_version"] = APP_DISPLAY_VERSION
        info["update_url"] = self.config.get("update_url", "")
        return info

    def check_update(self, source=None):
        """Interroge le manifeste publie et dit s'il existe une version plus recente."""
        res = self.updater.check(source or None)
        try:
            self.storage.set_setting("update_last_check", time.time())
        except Exception:
            pass
        self.storage.log(
            "info" if res.get("ok") else "warning",
            "Verification de la mise a jour",
            "installee=%s publiee=%s" % (res.get("current"), res.get("latest") or res.get("error")),
        )
        return res

    def auto_check_update(self):
        """Verification silencieuse a CHAQUE demarrage (l'installation reste manuelle).

        Une verification echouee depuis moins de 30 min n'est pas rejouee (machine
        hors ligne, source indisponible) pour ne pas ralentir chaque relance : mais
        un demarrage avec reseau interroge toujours le manifeste.
        """
        try:
            last = float(self.storage.get_setting("update_last_check", 0) or 0)
            last_ok = float(self.storage.get_setting("update_last_check_ok", 0) or 0)
        except (TypeError, ValueError):
            last, last_ok = 0.0, 0.0
        # Si la derniere verification REUSSIE date de moins de 30 min, inutile de
        # reinterroger le reseau : rien n'a pu changer depuis (et on evite un
        # aller-retour a chaque redemarrage rapproche pendant une session de test).
        if last_ok and (time.time() - last_ok) < 1800:
            return {"ok": True, "skipped": True, "current": APP_VERSION}
        res = self.check_update()
        if res.get("ok"):
            try:
                self.storage.set_setting("update_last_check_ok", time.time())
            except Exception:
                pass
        if res.get("ok") and res.get("available"):
            # Simple information : l'installation reste au choix de l'utilisateur.
            self._push_event({"type": "update", "stage": "available", "pct": 0,
                              "text": "Version %s disponible" % (res.get("latest") or ""),
                              "version": res.get("latest") or "",
                              "notes": res.get("notes") or ""})
        return res

    def download_update(self):
        """Telecharge le paquet en tache de fond ; la progression arrive par evenements."""
        if self._update_thread is not None and self._update_thread.is_alive():
            return {"ok": False, "error": "Un telechargement est deja en cours"}

        def _run():
            res = self.updater.download()
            if res.get("error"):
                stage, text = "error", res["error"]
            elif res.get("available"):
                stage, text = "ready", "Nouvelle version verifiee, prete a installer"
            else:
                stage, text = "uptodate", "Vous utilisez deja la derniere version"
            self._push_event({"type": "update", "stage": stage, "pct": 100 if res.get("ok") else 0,
                              "text": text, "version": res.get("version") or ""})
            self.storage.log("info" if res.get("ok") else "warning",
                             "Telechargement de la mise a jour",
                             res.get("version") or res.get("error") or "")

        self._update_thread = threading.Thread(target=_run, name="chape-update", daemon=True)
        self._update_thread.start()
        return {"ok": True, "started": True}

    def install_update(self, confirm=False):
        """Installe la version telechargee : l'app se ferme, les fichiers sont remplaces, elle redemarre."""
        # Mode sources (python app.py) : il n'y a pas de ChapeMedia.exe a remplacer,
        # l'installateur chercherait l'exe dans le dossier du projet et echouerait
        # silencieusement. On refuse d'emblee avec un message clair.
        if not self.updater.frozen:
            return {"ok": False, "error": "Mise a jour disponible uniquement pour la version "
                                          "installee (ChapeMedia.exe). En mode sources, "
                                          "recuperez la nouvelle version sur le depot."}
        res = self.updater.install(confirm=bool(confirm), on_ready=self._close_for_update)
        self.storage.log("info" if res.get("ok") else "warning",
                         "Installation de la mise a jour",
                         res.get("version") or res.get("error") or res.get("bat", ""))
        return res

    def set_update_url(self, url=""):
        """Change la source des mises a jour : depot, serveur interne, partage ou cle USB."""
        url = str(url or "").strip()
        self.updater.update_url = url or None
        self.config["update_url"] = url
        self.storage.save_config({**self.config, "download_dir": self.download_dir,
                                  "player_enabled": self.player_enabled})
        return {"ok": True, "source": self.updater.source_url()}

    def _close_for_update(self):
        """Demande la fermeture de la fenetre, pas du processus.

        L'installateur attend que ce pid disparaisse. On delegue donc a `app.py`
        (injecte au demarrage) qui ferme la fenetre : `main()` se termine, ses
        gestionnaires d'arret (stream, checkpoint WAL, verrou d'instance) tournent,
        puis le processus s'arrete proprement. Un `os._exit(0)` ici court-circuiterait
        tout cela et laisserait le journal WAL non checkpointe.
        """
        if self.request_close is not None:
            self.request_close()

    def shutdown(self):
        """Arret propre : checkpoint du journal WAL puis fermeture des connexions."""
        try:
            self.storage.log("info", "Arret de %s" % APP_NAME)
            self.storage.checkpoint()
        except Exception:
            pass
        self.storage.close()
        return True
