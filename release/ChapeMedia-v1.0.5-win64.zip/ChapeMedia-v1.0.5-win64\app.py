"""CHAPE-MEDIA - Point d'entree : demarre le backend FastAPI puis la fenetre pywebview.

Architecture :
- server.py            : Backend FastAPI (API REST /api/*, port 8928, sert web/)
- core/config.py       : Constantes, chemins, formats media, detection ffmpeg + reglages de perf
- core/database.py     : Couche SQLite (schema, requetes, FTS5, sauvegardes, migrations)
- core/storage.py      : Persistance (base chape_media.db : reglages, historique, mediatheque, journal)
- core/stream.py       : Serveur HTTP local streaming (HTTP/1.1, 206 Range, keep-alive)
- core/downloader.py   : Moteur de telechargement/conversion yt-dlp (fragments paralleles, oEmbed)
- core/file_manager.py : Scan de la mediatheque locale et interactions explorateur/OS
- core/api.py          : Metier expose en REST par server.py (long-polling evenements, cache)
- core/updater.py      : Mise a jour automatique (manifeste, SHA-256, remplacement + retour arriere)
Le front (web/) communique avec le backend via bridge.js -> fetch HTTP (plus de pont js_api).
"""
import os
import sys
import threading

# Windows : la console utilise par defaut le codec charmap (cp1252), qui ne connait
# pas les emojis ni certains caracteres des titres TikTok/YouTube. Sans ce bloc,
# print(titre) leve « 'charmap' codec can't encode character ... ».
# NB : en exe (PyInstaller windowed), sys.stdout/stderr valent None — on ne
# reconfigure donc que s'ils existent.
if sys.stdout is not None:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if sys.stderr is not None:
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from core.config import APP_DATA, APP_NAME, APP_VERSION, INSTANCE_PORT, WEB_DIR
import server as _server

webview = None
_INSTANCE_LOCK = None  # socket garde ouvert : sert de verrou "instance unique"


class NativeApi:
    """Ponts UI exposes au front par pywebview (window.pywebview.api.<nom>).

    Uniquement des dialogues natifs : le metier (choix, validation, sauvegarde du
    reglage) reste dans core/api.py. Le front retombe sur `choose_folder` si ce pont
    n'est pas disponible (ancienne version de pywebview).
    """

    def __init__(self, pick_folder):
        self._pick_folder = pick_folder

    def pick_folder(self, initial=None):
        return self._pick_folder(initial)


def _shared_webview_dir():
    """Dossier de cache WebView2 persistant (demarrage plus rapide, vignettes en cache).

    Retourne None si une autre instance de l'application tourne deja : dans ce cas on
    repasse en mode prive temporaire, comme avant, pour ne pas bloquer le profil WebView2.
    """
    import socket
    global _INSTANCE_LOCK
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # SO_REUSEADDR absent volontairement : le port doit signaler une instance active.
        s.bind(("127.0.0.1", INSTANCE_PORT))
        s.listen(1)
        _INSTANCE_LOCK = s
    except OSError:
        return None
    path = os.path.join(APP_DATA, "webview")
    try:
        os.makedirs(path, exist_ok=True)
        return path
    except OSError:
        return None


def _release_lock():
    """Ferme le socket de verrou d'instance unique (le port doit etre rendu a l'OS)."""
    global _INSTANCE_LOCK
    s, _INSTANCE_LOCK = _INSTANCE_LOCK, None
    if s is not None:
        try:
            s.close()
        except OSError:
            pass


def main():
    global webview
    try:
        import webview as _wv
        webview = _wv
    except ImportError:
        print("Installez pywebview : pip install pywebview")
        return

    # Backend FastAPI : le front (web/bridge.js) appelle l'API REST locale.
    # bind_port() choisit un port libre AVANT de lancer le thread : l'URL de la
    # fenetre doit pointer sur le port reellement occupe (repli si 8928 est pris).
    port = _server.bind_port()
    server_thread = threading.Thread(
        target=_server.uvicorn_run, kwargs={"port": port},
        name="chape-fastapi", daemon=True)
    server_thread.start()
    api = _server.get_api()
    url = "http://127.0.0.1:%d" % port
    icon = os.path.join(WEB_DIR, "icon.ico")
    if not os.path.exists(icon):
        icon = os.path.join(WEB_DIR, "icon.png")
        if not os.path.exists(icon):
            icon = None

    win = webview.create_window(
        "%s v%s" % (APP_NAME, APP_VERSION),
        url=url,
        width=1160,
        height=780,
        text_select=True,
        min_size=(900, 600),
        zoomable=False,
        easy_drag=False,
    )

    # Selecteur de dossier natif : expose cote front via window.pywebview.api.
    # Tk est exclu (thread principal), le dialogue vit donc ici, dans app.py.
    def _native_pick_folder(initial=None):
        try:
            picked = win.create_file_dialog(
                webview.FOLDER_DIALOG,
                directory=initial or api.download_dir,
            )
        except Exception:
            return ""
        if not picked:
            return ""
        path = picked[0] if isinstance(picked, (list, tuple)) else picked
        return str(path or "")

    native = NativeApi(_native_pick_folder)
    try:
        win.expose(native.pick_folder, name="pick_folder")
    except Exception:
        pass       # version de pywebview sans expose() : le front retombe sur choose_folder

    # Installation d'une mise a jour : le metier demande la fermeture, c'est ici qu'on
    # l'execute. La fenetre se ferme -> webview.start() rend la main -> main() se
    # termine -> _on_closed fait son menage -> le script d'installation prend le relais.
    def _request_close():
        try:
            win.destroy()
        except Exception:
            pass

    api.request_close = _request_close

    def _auto_update_check():
        """Verifie en tache de fond s'il existe une version publiee plus recente
        (une fois par 24 h) : l'utilisateur est simplement informe, rien ne s'installe seul."""
        try:
            api.auto_check_update()
        except Exception:
            pass

    threading.Thread(target=_auto_update_check, name="chape-update-check", daemon=True).start()

    def _on_closed():
        """Libere le serveur de streaming et ferme proprement la base des la fermeture."""
        try:
            api.server.stop()
        except Exception:
            pass
        try:
            api.shutdown()      # checkpoint WAL + fermeture des connexions SQLite
        except Exception:
            pass
        _release_lock()        # libere le port d'instance pour la prochaine execution

    try:
        win.events.closed += _on_closed
    except Exception:
        pass

    storage = _shared_webview_dir()
    try:
        webview.settings["OPEN_DEVTOOLS_IN_DEBUG"] = False
    except Exception:
        pass

    webview.start(debug=False, icon=icon, private_mode=storage is None, storage_path=storage)


if __name__ == "__main__":
    main()
