"""Serveur HTTP local de streaming des medias (lecteur integre + partage reseau).

Points de performance et de compatibilite du lecteur :

- HTTP/1.1 keep-alive : une seule connexion TCP pour toute la lecture et les seeks.
- Requetes Range completes : simple, ouverte (« bytes=N- »), suffixe (« bytes=-N »)
  et MULTI-PLAGES. Reponse 416 conforme.
- Transfert sans open()/close() par requete : un descripteur, lu par os.pread.
- Taille de paquet adaptee : un petit seek ne paie plus 256 Ko de lecture.
- MIME corrects pour m4a/opus/webm : sans cela `<audio>` refusait le fichier
  (application/octet-stream) et le lecteur restait muet.
- ETag + Last-Modified + If-Range : reprise de lecture propre.
- En-tete X-Media-Kind : le front choisit <audio> ou <video> sans deviner.
- TCP_NODELAY : moins de latence sur chaque seek.
"""
import mimetypes
import os
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .config import STREAM_CHUNK
from .thumb_cache import get as thumb_get

# Cache de types MIME : evite un appel au registre Windows a chaque requete
_CTYPE_CACHE = {}

# Table locale : Windows ne connait pas toujours .m4a/.opus/.webm audio et renvoie
# application/octet-stream, ce qui fait echouer la lecture integree.
_CTYPE_TABLE = {
    ".mp4": "video/mp4", ".m4v": "video/mp4", ".mov": "video/quicktime",
    ".mkv": "video/x-matroska", ".webm": "video/webm", ".avi": "video/x-msvideo",
    ".flv": "video/x-flv", ".wmv": "video/x-ms-wmv", ".ts": "video/mp2t",
    ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".m4b": "audio/mp4",
    ".aac": "audio/aac", ".opus": "audio/opus", ".ogg": "audio/ogg",
    ".oga": "audio/ogg", ".wav": "audio/wav", ".flac": "audio/flac",
    ".wma": "audio/x-ms-wma", ".weba": "audio/webm",
}

# Conteneurs dont le type ne dit pas s'il y a de l'image : le lecteur doit tester.
_CONTAINER_AUDIO = {"audio/mpeg", "audio/ogg", "audio/wav", "audio/x-wav", "audio/flac",
                    "audio/x-flac", "audio/aac", "audio/opus", "audio/x-ms-wma",
                    "audio/mp4"}
_CONTAINER_VIDEO = {"video/mp4", "video/x-matroska", "video/webm", "video/quicktime",
                    "video/x-msvideo", "video/mp2t", "video/x-flv", "video/x-ms-wmv"}

# Plage ouverte (« bytes=N- ») : un seek ne rapatrie pas tout le fichier d'un coup.
_OPEN_RANGE_MAX = 8 * 1024 * 1024
# Sentinelle : « pas d'en-tete Range » (different de [] = Range insatisfaisable).
_NO_RANGE = object()
_EXPOSE_HEADERS = "Content-Range, Accept-Ranges, Content-Length, X-Media-Kind, ETag"

# Page HTML servie a l'appareil invite (partage par lien sur le reseau local).
_SHARE_PAGE = """<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>%TITLE% — CHAPE-MEDIA</title>
<style>
 body{margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;
      justify-content:center;background:#0a0a0a;color:#f5f5f5;font-family:system-ui,sans-serif}
 h1{font-size:16px;font-weight:600;margin:0 0 18px;text-align:center;padding:0 16px}
 video,audio{max-width:94vw;max-height:80vh;outline:none}
 p{color:#9c9;font-size:13px;margin-top:18px}
</style></head><body>
<h1>%TITLE%</h1>
%MEDIA%
<p>Partagé depuis CHAPE-MEDIA</p>
</body></html>"""


def _content_type(path):
    ext = os.path.splitext(path)[1].lower()
    ctype = _CTYPE_CACHE.get(ext)
    if ctype is None:
        ctype = _CTYPE_TABLE.get(ext)
        if ctype is None:
            ctype, _ = mimetypes.guess_type("f" + ext)
            ctype = ctype or "application/octet-stream"
        _CTYPE_CACHE[ext] = ctype
    return ctype


def media_kind(path, ctype=""):
    """'audio', 'video' ou 'unknown' : indice envoye au front (X-Media-Kind).

    Le conteneur ne suffit pas a decider : un .mkv peut ne contenir que de l'audio.
    Le front s'en sert pour ouvrir le bon element, puis bascule si rien ne se charge.
    """
    ctype = (ctype or _content_type(path)).lower()
    if ctype in _CONTAINER_AUDIO:
        return "audio"
    if ctype in _CONTAINER_VIDEO:
        return "video"
    return "unknown"


def _parse_ranges(header, size):
    """Analyse « Range: bytes=... » -> [(start, end), ...], [] si non satisfaisable.

    Gere les plages simple, ouverte (« N- ») et suffixe (« -N »). Une plage hors
    fichier est ignoree, comme le demande la RFC 7233.
    """
    if not header or not header.startswith("bytes="):
        return _NO_RANGE            # pas d'en-tete : 200 complet
    specs = [s.strip() for s in header[6:].split(",") if s.strip()]
    out = []
    for spec in specs:
        if "-" not in spec:
            return []               # syntaxe invalide -> 416
        a, b = spec.split("-", 1)
        try:
            if not a:
                n = int(b)
                if n <= 0:
                    return []
                start, end = max(0, size - n), size - 1
            else:
                start = int(a)
                end = int(b) if b else min(size - 1, start + _OPEN_RANGE_MAX - 1)
                end = min(end, size - 1)
        except ValueError:
            return []
        if start > end or start >= size:
            continue                # plage insatisfaisable : ignoree (RFC 7233)
        out.append((start, end))
    return out


class MediaHandler(BaseHTTPRequestHandler):
    """Sert les fichiers locaux avec support HTTP Range (seek fluide en lecteur integre)."""
    server_version = "CHAPE-MEDIA/1.1"
    # HTTP/1.1 + Content-Length toujours envoye => connexion TCP reutilisee (keep-alive)
    # => moins de handshakes et de requetes lors des seeks dans le lecteur integre.
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        # Desactive les logs serveur dans la console pour eviter le bruit
        pass

    def setup(self):
        super().setup()
        try:                                     # chaque seek accuse 1 ms de moins
            import socket
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass

    def do_OPTIONS(self):
        """CORS du lecteur en mode navigateur (dev) : pas de preflight a chaque seek."""
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Range, If-Range")
        self.send_header("Access-Control-Expose-Headers", _EXPOSE_HEADERS)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_HEAD(self):
        self._serve(False)

    def do_GET(self):
        self._serve(True)

    def _serve(self, with_body):
        try:
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path == "/thumb":
                self._serve_thumb(with_body)
                return
            if parsed.path.startswith("/profile/"):
                self._serve_profile(parsed.path, with_body)
                return
            if parsed.path == "/poster":
                self._serve_poster(parsed.query, with_body)
                return
            if parsed.path == "/" or parsed.path == "/share":
                self._serve_share_page(with_body)
                return
            if parsed.path != "/media":
                self.send_error(404)
                return
            qs = urllib.parse.parse_qs(parsed.query)
            path = qs.get("path", [None])[0]
            # 404 d'abord (fichier inexistant / vide), puis 403 hors des racines : la
            # reponse reste celle d'avant pour un chemin legitime.
            if not path or not os.path.isfile(path):
                self.send_error(404, "Fichier introuvable")
                return
            if not self._allowed(path):
                self.send_error(403, "Fichier hors des dossiers autorises")
                return
            self._serve_media(path, with_body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self.send_error(500, str(e))
            except Exception:
                pass

    def _allowed(self, path, kind="media"):
        r"""Filtre de portee : seuls les dossiers autorises sont servis.

        Le serveur ecoute sur 0.0.0.0 (partage reseau) : sans ce test,
        /media?path=C:\... exposait tout le disque au reseau local.
        """
        owner = getattr(self.server, "owner", None)
        return bool(owner is not None and owner.is_allowed(path, kind))

    def _write(self, data):
        """Ecriture tolérante : un client qui a fermé la connexion n'arrête pas le serveur."""
        try:
            self.wfile.write(data)
            return True
        except (BrokenPipeError, ConnectionResetError, OSError):
            return False

    def _send_file_range(self, path, start, length):
        """Envoie [start, start+length) via un descripteur unique (os.pread).

        - un seul open() pour tout le transfert (l'ouverture coutait ~0,1 ms par requete) ;
        - paquet de 64 Ko pour une plage courte, STREAM_CHUNK pour un flux continu :
          plus de lecture inutile apres un seek de quelques centaines de Ko.
        """
        try:
            fd = os.open(path, os.O_RDONLY | getattr(os, "O_BINARY", 0))
        except OSError:
            return
        chunk_size = STREAM_CHUNK
        try:
            pos, remaining = start, length
            while remaining > 0:
                n = min(chunk_size, remaining)
                try:
                    chunk = os.pread(fd, n, pos)
                except (AttributeError, OSError):   # plateforme sans pread
                    os.lseek(fd, pos, os.SEEK_SET)
                    chunk = os.read(fd, n)
                if not chunk:
                    return
                if not self._write(chunk):
                    return
                pos += len(chunk)
                remaining -= len(chunk)
        finally:
            try:
                os.close(fd)
            except OSError:
                pass

    def _serve_media(self, path, with_body):
        try:
            st = os.stat(path)
            size = st.st_size
        except OSError:
            self.send_error(404, "Fichier introuvable")
            return
        if size <= 0:
            self.send_error(404, "Fichier vide")
            return

        ctype = _content_type(path)
        etag = '"%x-%x"' % (int(st.st_mtime), size)
        last_modified = self.date_time_string(int(st.st_mtime))

        # If-Range : une reprise n'est valable que si le fichier n'a pas change.
        range_hdr = self.headers.get("Range")
        if_range = self.headers.get("If-Range")
        if if_range and if_range not in (etag, last_modified):
            range_hdr = None

        ranges = _parse_ranges(range_hdr, size) if range_hdr else _NO_RANGE
        if ranges == []:
            self.send_response(416)
            self.send_header("Content-Range", "bytes */%d" % size)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", "0")
            self.send_header("ETag", etag)
            self.end_headers()
            return

        # Plusieurs plages : multipart/byteranges (certains decodeurs le demandent).
        if ranges is not _NO_RANGE and len(ranges) > 1:
            boundary = "%x%x" % (size, int(st.st_mtime))
            members, total = [], 0
            for start, end in ranges:
                head = ("--%s\r\nContent-Type: %s\r\nContent-Range: bytes %d-%d/%d\r\n\r\n"
                        % (boundary, ctype, start, end, size)).encode("ascii")
                members.append((head, start, end - start + 1))
                total += len(head) + (end - start + 1) + 2
            tail = ("--%s--\r\n" % boundary).encode("ascii")
            self.send_response(206)
            self.send_header("Content-Type", "multipart/byteranges; boundary=" + boundary)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(total + len(tail)))
            self.send_header("ETag", etag)
            self.end_headers()
            if with_body:
                for head, start, length in members:
                    if not self._write(head):
                        return
                    self._send_file_range(path, start, length)
                    if not self._write(b"\r\n"):
                        return
                self._write(tail)
            return

        start, end = ranges[0] if ranges is not _NO_RANGE else (0, size - 1)
        length = end - start + 1
        status = 206 if ranges is not _NO_RANGE else 200

        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if status == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("ETag", etag)
        self.send_header("Last-Modified", last_modified)
        # Indice de nature : evite au front de charger <video> pour un mkv audio.
        self.send_header("X-Media-Kind", media_kind(path, ctype))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Expose-Headers", _EXPOSE_HEADERS)
        self.end_headers()
        if with_body:
            self._send_file_range(path, start, length)

    def _serve_profile(self, url_path, with_body):
        """Sert la photo de profil depuis APP_DATA/profile.

        Pourquoi ici et pas en file:// : la page est servie en http://127.0.0.1, donc
        file:// est bloque par la politique de securite de la webview (et Chromium
        desactive file:// depuis une origine http). C'est ce qui faisait disparaitre
        la photo des que l'interface se rechargeait.
        """
        try:
            name = os.path.basename(urllib.parse.unquote(url_path))
            if not name or name.startswith(".") or not name.startswith("avatar"):
                self.send_error(404)
                return
            from .config import APP_DATA
            local = os.path.join(APP_DATA, "profile", name)
            if not os.path.isfile(local):
                self.send_error(404)
                return
            size = os.path.getsize(local)
            st = os.stat(local)
            etag = '"%x-%x"' % (int(st.st_mtime), size)
            if self.headers.get("If-None-Match") == etag:
                self.send_response(304)
                self.send_header("ETag", etag)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", _content_type(local))
            self.send_header("Content-Length", str(size))
            self.send_header("ETag", etag)
            # L'avatar change rarement mais DOIT se rafraichir quand on le remplace.
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            if with_body:
                self._send_file_range(local, 0, size)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            try:
                self.send_error(500)
            except Exception:
                pass

    def _serve_poster(self, query, with_body):
        """Vignette fabriquee depuis le media local (repli quand aucune n'est disponible).

        /poster?path=<fichier> : ffmpeg extrait une image a 10 % de la duree, cachee
        dans APP_DATA/thumbs sous le nom du fichier. Coût paye une seule fois, et la
        vignette existe meme hors ligne ou pour un media sans cover.
        """
        try:
            qs = urllib.parse.parse_qs(query)
            path = qs.get("path", [None])[0]
            if not path or not os.path.isfile(path):
                self.send_error(404)
                return
            if not self._allowed(path, "poster"):
                self.send_error(403, "Fichier hors des dossiers autorises")
                return
            from .config import APP_DATA, ffmpeg_path
            import hashlib
            import subprocess
            key = hashlib.sha1(os.path.abspath(path).encode("utf-8", "ignore")).hexdigest()
            st = os.stat(path)
            out = os.path.join(APP_DATA, "thumbs", "poster_%s_%d.jpg" % (key, int(st.st_mtime)))
            if not (os.path.isfile(out) and os.path.getsize(out) > 0):
                ff = ffmpeg_path()
                if not ff:
                    self.send_error(404)
                    return
                duration = 0.0
                try:
                    owner = getattr(self.server, "owner", None)
                    duration = float(owner.probe(path).get("duration") or 0.0) if owner else 0.0
                except Exception:
                    duration = 0.0
                at = max(0.5, duration * 0.1) if duration else 1.0
                cmd = [ff, "-y", "-v", "error", "-ss", "%.2f" % at, "-i", path,
                       "-frames:v", "1", "-vf", "scale=320:-2", "-q:v", "5", out]
                try:
                    subprocess.run(cmd, capture_output=True, timeout=20,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                except Exception:
                    pass
                if not (os.path.isfile(out) and os.path.getsize(out) > 0):
                    self.send_error(404)
                    return
            size = os.path.getsize(out)
            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", "public, max-age=604800, immutable")
            self.end_headers()
            if with_body:
                self._send_file_range(out, 0, size)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            try:
                self.send_error(500)
            except Exception:
                pass

    def _serve_share_page(self, with_body):
        """Page de lecture minimaliste pour les appareils distants (partage reseau).

        /?path=<chemin> : lit le fichier servi par /media avec l'element <video>/<audio>
        natif du navigateur de l'appareil invite. Aucune dependance externe.
        """
        try:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            path = qs.get("path", [None])[0]
            if path and not self._allowed(path):
                self.send_error(403, "Fichier hors des dossiers autorises")
                return
            page = _SHARE_PAGE
            if path:
                import html as _html
                med = self._media_query(path)
                title = _html.escape(os.path.basename(path))
                page = page.replace("%TITLE%", title).replace("%MEDIA%", med)
            else:
                page = page.replace("%TITLE%", "CHAPE-MEDIA").replace("%MEDIA%", "")
            body = page.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if with_body:
                self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            try:
                self.send_error(500)
            except Exception:
                pass

    def _media_query(self, path):
        return "/media?path=" + urllib.parse.quote(path, safe="")

    def _serve_thumb(self, with_body):
        """Sert une vignette locale : /thumb?url=<URL distante>

        La vignette est telechargee UNE fois (thumb_cache.get) puis servie depuis le
        disque, avec un cache navigateur long. Le type MIME vient du fichier reel
        (hash + extension detectee) : sans extension, Windows renvoyait
        application/octet-stream et Chromium refusait d'afficher l'image.
        """
        try:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            url = qs.get("url", [None])[0]
            local = thumb_get(url) if url else None
            if local and not os.path.isfile(local):
                local = None
            if not local:
                # Vignette jamais telechargee / hotlink mort : image 1x1 transparente,
                # statut 404 avec un corps valide (le <img> du front ne se casse pas).
                body = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
                        b"\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
                        b"\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-"
                        b"\xb4\xdc\x00\x00\x00\x00IEND\xaeB`\x82")
                self.send_response(404)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                if with_body:
                    self._write(body)
                return
            size = os.path.getsize(local)
            ctype = _content_type(local)
            if ctype == "application/octet-stream":
                ctype = "image/jpeg"     # ancien cache sans extension mais bien une image
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(size))
            # Cache long : le fichier local est immuable (nom = hash de l'URL).
            self.send_header("Cache-Control", "public, max-age=604800, immutable")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            if with_body:
                self._send_file_range(local, 0, size)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            try:
                self.send_error(500)
            except Exception:
                pass


def _real(path):
    """Chemin absolu, liens resolus (None si le chemin est invalide)."""
    try:
        return os.path.normcase(os.path.realpath(os.path.abspath(path)))
    except (OSError, ValueError):
        return None


def _within(path, root):
    """Vrai si `path` est `root` ou se trouve sous `root` (comparaison de composants)."""
    p, r = _real(path), _real(root)
    if not p or not r:
        return False
    try:
        return os.path.commonpath([p, r]) == r
    except ValueError:          # lecteurs differents (C: vs D:) : jamais sous root
        return False


class _MediaHTTPServer(ThreadingHTTPServer):
    """Serveur multithread : plusieurs requetes Range simultanees pour des seeks instantanes."""
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64


class MediaServer:
    """Controleur du serveur de streaming local."""

    # Objet interne : ne doit pas etre expose au JS (cf. StorageManager._serializable).
    # Le socket / les HTTPRequestHandler feraient sinon exploser l'introspection de pywebview.
    _serializable = False

    def __init__(self, default_port=8899):
        self.port = default_port
        self.server = None
        self.thread = None
        self._probe_cache = {}          # chemin -> (mtime, infos) : ffprobe une seule fois
        self._probe_lock = threading.Lock()
        self._roots = ()                # racines autorisees (cf. set_roots)
        # Dossiers d'ou une video peut etre lue (vignette /poster) sans que le fichier
        # soit servi par /media : seuls les medias locaux y sont exposes.
        self._read_roots = ()
        # Ancien cache : fichiers sans extension, servis en application/octet-stream
        # (donc refuses par le navigateur). On leur rend leur vraie extension.
        try:
            from .thumb_cache import migrate
            migrate()
        except Exception:
            pass

    def start(self):
        # 0.0.0.0 : le partage par lien (appareils du meme reseau) doit pouvoir se connecter.
        # L'app locale reste servie via 127.0.0.1, identique pour le lecteur integre.
        # Port demande, puis replis proches (jamais un port fixe qui bloque le lecteur).
        candidates = [self.port] + [p for p in (self.port + 1, self.port + 2, self.port + 3,
                                                self.port + 5, self.port + 10) if p <= 65535]
        for port in candidates:
            try:
                self.server = _MediaHTTPServer(("0.0.0.0", port), MediaHandler)
                self.server.owner = self      # /poster a besoin de probe() (duree du media)
                self.port = port
                self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
                self.thread.start()
                return self.port
            except OSError:
                self.server = None
                continue
        return None

    def set_roots(self, *roots):
        """Restreint les fichiers servis a ces dossiers (et leurs sous-dossiers).

        Sans cette liste, /media?path= servait N'IMPORTE QUEL fichier du disque a
        quiconque sur le reseau local (0.0.0.0). On n'expose que les donnees de
        l'application et le dossier de telechargement. Un chemin relatif est ignore.
        """
        clean = []
        for root in roots:
            if root and isinstance(root, str) and os.path.isabs(root):
                real = _real(root)
                if real and real not in clean:
                    clean.append(real)
        self._roots = tuple(clean)
        return self._roots

    def allow_read(self, *roots):
        """Autorise des dossiers pour la vignette /poster uniquement (media local).

        Un fichier hors mediatheque (video choisie ailleurs) peut ainsi produire sa
        vignette, sans que /media ne serve tout le contenu de ce dossier.
        """
        clean = list(self._read_roots)
        for root in roots:
            if root and isinstance(root, str) and os.path.isabs(root):
                real = _real(root)
                if real and real not in clean and real not in self._roots:
                    clean.append(real)
        self._read_roots = tuple(clean)
        return self._read_roots

    def sign(self, url):
        """Point d'extension : identite. Les URLs media sont servies telles quelles."""
        return url

    def is_allowed(self, path, kind="media"):
        """Filtre de portee : racines autorisees, ou dossier lisible pour /poster."""
        if not path:
            return False
        if any(_within(path, root) for root in self._roots):
            return True
        if kind == "poster":
            # Lu a chaque appel : allow_read() peut avoir ete appele apres start().
            return any(_within(path, root) for root in self._read_roots)
        return False

    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()  # libere immediatement le port 127.0.0.1
            except Exception:
                pass
            self.server = None

    def get_url(self, file_path, lan=False):
        if not file_path or not os.path.isfile(file_path):
            raise ValueError("Fichier introuvable")
        if self.server is None:
            raise ValueError("Serveur media local indisponible")
        if lan:
            host = self.lan_ip()
            if host:
                return self.sign(f"http://{host}:{self.port}/share?path=" + urllib.parse.quote(file_path, safe=""))
        q = urllib.parse.quote(file_path, safe="")
        return self.sign(f"http://127.0.0.1:{self.port}/media?path={q}")

    @staticmethod
    def lan_ip():
        """IP locale (reseau) de la machine, ou None si introuvable (pas de reseau)."""
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("10.255.255.255", 1))   # aucune trame envoyee, juste le routage
            ip = s.getsockname()[0]
        except OSError:
            ip = None
        finally:
            try:
                s.close()
            except OSError:
                pass
        return ip

    def probe(self, file_path):
        """Duree, nature et codecs du fichier, mis en cache par (chemin, mtime).

        ffprobe est facultatif : sans lui, on renvoie {} et le lecteur suit son cours.
        Appele depuis le thread pool (jamais la boucle asyncio).
        """
        try:
            st = os.stat(file_path)
        except OSError:
            return {}
        stamp = int(st.st_mtime)
        with self._probe_lock:
            hit = self._probe_cache.get(file_path)
            if hit and hit[0] == stamp:
                return hit[1]
        info = {}
        try:
            from .config import ffmpeg_path
            ff = ffmpeg_path()
            probe_bin = None
            if ff:
                cand = os.path.join(os.path.dirname(ff), "ffprobe.exe")
                probe_bin = cand if os.path.isfile(cand) else None
            if probe_bin:
                import json
                import subprocess
                cmd = [probe_bin, "-v", "error", "-print_format", "json",
                       "-show_format", "-show_streams", file_path]
                out = subprocess.run(cmd, capture_output=True, timeout=8,
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                data = json.loads(out.stdout.decode("utf-8", "replace") or "{}")
                streams = data.get("streams") or []
                kinds = {s.get("codec_type") for s in streams}
                dur = (data.get("format") or {}).get("duration")
                info = {
                    "duration": float(dur) if dur else 0.0,
                    "kind": "video" if "video" in kinds else ("audio" if "audio" in kinds else ""),
                    "video_codec": next((s.get("codec_name") for s in streams
                                         if s.get("codec_type") == "video"), ""),
                    "audio_codec": next((s.get("codec_name") for s in streams
                                         if s.get("codec_type") == "audio"), ""),
                }
        except Exception:
            info = {}
        with self._probe_lock:
            self._probe_cache[file_path] = (stamp, info)
        return info

    def profile_url(self, local_path=""):
        """URL http de la photo de profil (jamais file:// : bloque depuis une origine http).

        Le nom vient du chemin enregistre ; l'URL porte le mtime pour qu'un remplacement
        d'avatar soit visible tout de suite malgre le cache du client.
        """
        if self.server is None:
            return ""
        name = os.path.basename(str(local_path or ""))
        if not name:
            return ""
        full = os.path.join(os.path.dirname(str(local_path)), name)
        try:
            ver = int(os.path.getmtime(full))
        except OSError:
            ver = 0
        return "http://127.0.0.1:%d/profile/%s?v=%d" % (
            self.port, urllib.parse.quote(name), ver)

    def get_thumb_url(self, remote_url):
        """URL locale de la vignette (telechargee au premier appel via thumb_cache).

        Retourne "" si le serveur est indisponible ou l'URL vide : le front gardera
        alors l'URL distante d'origine (comportement degrade).
        """
        if not remote_url or self.server is None:
            return ""
        q = urllib.parse.quote(str(remote_url), safe="")
        return f"http://127.0.0.1:{self.port}/thumb?url={q}"
