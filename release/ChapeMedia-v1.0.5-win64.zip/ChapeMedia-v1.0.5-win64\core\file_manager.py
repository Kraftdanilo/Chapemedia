"""Exploration du systeme de fichiers et ouverture d'applications externes."""
import os
import subprocess
import sys
import threading
from .config import ALL_MEDIA, ffmpeg_path


class ScanResult(list):
    """Liste de fichiers medias + attribut `truncated` (scan borne : le dossier n'a pas
    ete parcouru en entier -> la synchro ne doit PAS supprimer les lignes non vues)."""
    truncated = False


class FileManager:
    """Operations de fichiers : scanner mediatheque, suppression, ouverture systeme."""

    @staticmethod
    def scan_library(directory, max_files=200):
        """Scan borne et rapide : 1 niveau, sans image, avec les stats deja lues par scandir.

        Boost : on s'arrete des qu'on a `max_files` medias (au lieu de tout lister puis filtrer)
        et on utilise DirEntry.stat() qui evite un appel systeme par fichier sous Windows.

        La liste retournee porte `.truncated = True` si une borne a ete atteinte : l'appelant
        doit alors eviter de purger la base (les fichiers non vus ne sont pas disparus).
        """
        out = ScanResult()
        if not os.path.isdir(directory):
            out.truncated = True          # dossier absent : ne rien conclure sur le disque
            return out
        scanned = 0
        try:
            with os.scandir(directory) as it:
                for e in it:
                    if len(out) >= max_files or scanned >= 4000:
                        out.truncated = True
                        break
                    scanned += 1
                    try:
                        if not e.is_file(follow_symlinks=False):
                            continue
                        name = e.name
                        ext = os.path.splitext(name)[1].lower()
                        if ext not in ALL_MEDIA:
                            continue
                        st = e.stat()  # mis en cache par scandir : aucun appel systeme supplementaire
                    except OSError:
                        continue
                    out.append({
                        "path": e.path,
                        "title": os.path.splitext(name)[0],
                        "ext": ext.lstrip("."),
                        "size": st.st_size,
                        "mtime": st.st_mtime,
                        "thumbnail": None,
                    })
        except OSError:
            out.truncated = True          # dossier illisible (partage coupe…) : ne rien purger
            return out
        out.sort(key=lambda x: x["mtime"], reverse=True)
        return out

    @staticmethod
    def remove_audio(src):
        """Cree une copie SANS PISTE AUDIO d'une video (ffmpeg -an, sans re-encodage).

        Le fichier original n'est jamais modifie : la copie muette prend le meme nom
        avec le suffixe « (sans son) ». Retourne (ok, chemin_cree ou message d'erreur).
        Aucune dependance externe au-dela de ffmpeg, deja requis par l'application.
        """
        src = str(src or "")
        ext = os.path.splitext(src)[1].lower()
        if not src or not os.path.isfile(src):
            return False, "Fichier introuvable"
        if ext not in {".mp4", ".mkv", ".webm", ".mov", ".m4v"}:
            return False, "Pas une video"
        ff = ffmpeg_path()
        if not ff:
            return False, "ffmpeg introuvable"
        base = os.path.splitext(src)[0]
        dst = base + " (sans son)" + ext
        try:
            os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
            # -an : supprime toutes les pistes audio ; -c:v copy : la video est copiee
            # bit-a-bit (instantane, aucune perte de qualite). -y : ecrase une copie
            # muette precedente (regeneration, pas d'erreur bloquante).
            r = subprocess.run(
                [ff, "-y", "-i", src, "-an", "-c:v", "copy", "-movflags", "+faststart", dst],
                capture_output=True, timeout=1800,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if r.returncode != 0 or not os.path.isfile(dst) or os.path.getsize(dst) == 0:
                msg = (r.stderr or b"").decode("utf-8", "replace").strip()
                return False, (msg[-1] if msg else "Echec de la conversion")
            return True, dst
        except Exception as e:
            return False, str(e)

    @staticmethod
    def delete_file(path):
        """Supprime un fichier sur le disque."""
        try:
            if path and os.path.isfile(path):
                os.remove(path)
                return True
        except OSError:
            pass
        return False

    @staticmethod
    def open_external(path):
        """Ouvre un fichier avec le lecteur par defaut de l'OS."""
        try:
            if os.name == "nt":
                os.startfile(path)  # type: ignore # noqa
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
            return True
        except Exception as e:
            return str(e)

    @staticmethod
    def open_folder(path):
        """Ouvre l'explorateur de fichiers au bon emplacement avec le fichier selectionne."""
        try:
            folder = path if os.path.isdir(path) else os.path.dirname(path)
            if os.name == "nt":
                if os.path.isfile(path):
                    subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
                else:
                    subprocess.Popen(["explorer", os.path.normpath(folder)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
            return True
        except Exception as e:
            return str(e)
