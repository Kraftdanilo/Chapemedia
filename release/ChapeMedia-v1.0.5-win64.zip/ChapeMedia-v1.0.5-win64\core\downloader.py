"""Moteur de telechargement et extraction via yt-dlp."""
import asyncio
import json
import os
import sys
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime
from .config import APP_VERSION, CACHE_DIR, FRAGMENT_WORKERS, INFO_CACHE_TTL, NET_BUFFER, ffmpeg_path

try:
    import yt_dlp  # type: ignore
except ImportError:
    yt_dlp = None

# ---- Moteurs de secours (3 niveaux, du plus rapide au plus large) ----
# 1. yt-dlp reessaie avec des strategies de connexion differentes :
#   a. cookies du navigateur installe (contourne la plupart des blocages 403)
#   b. sans impersonation curl_cffi (certains sites se font bloquer AVEC une empreinte
#      navigateur trop recente)
#   c. client mobile (User-Agent + formats du player mobile)
#   Chaque strategie corrige un cas reel : le 403 de YouTube se leve typiquement avec
#   les cookies, et certains sites bloquent l'empreinte chrome.
# 2. Cobalt (pybalt) : extraction cote serveur, robuste aux changements d'extracteurs.
# 3. gallery-dl : extracteurs alternatifs (Facebook, Instagram, X...), execute en
#    sous-processus isole — dernier recours quand les deux premiers ont echoue.
_FALLBACK_STRATEGIES = ("cookies", "no-impersonate", "mobile")

# Impersonation (curl_cffi) : indispensable pour TikTok et certains sites anti-bot.
# On la detecte une fois au demarrage ; si absente, TikTok renverra
# « Unexpected response from webpage request » et l'utilisateur doit faire :
#   pip install curl_cffi
try:
    import curl_cffi  # type: ignore  # noqa: F401
    from yt_dlp.networking.impersonate import ImpersonateTarget
    # Cible "chrome" : la plus universelle et stable (TikTok et la plupart des sites anti-bot)
    _IMPERSONATE = ImpersonateTarget("chrome")
except ImportError:
    _IMPERSONATE = None

# Moteur de secours : pybalt (client Cobalt). Interroge une instance Cobalt en ligne
# qui extrait le lien direct du media : contourne les cas ou yt-dlp ne connait plus
# le format d'un site. Verifie en developpement : YouTube OK, TikTok/Instagram selon
# l'instance. Import optionnel : l'app reste fonctionnelle sans (fallback desactive).
try:
    from pybalt.core.wrapper import InstanceManager as _PYBALT  # type: ignore
except ImportError:
    _PYBALT = None

# 3e moteur de secours : gallery-dl, lance en sous-processus (`python -m gallery_dl`)
# dans _gallery_dl_download ; le module n'est jamais importe ici (il installe ses
# propres handlers de signaux). La presence du paquet est testee via shutil.which/
# importlib au moment de l'appel ; sans lui le fallback echoue avec un message clair.


_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) CHAPE-MEDIA/%s" % APP_VERSION
# APIs oEmbed : une seule requete HTTP legere (~200-600 ms) au lieu de l'extraction complete
# yt-dlp (2 a 8 s) pour l'apercu titre / auteur / vignette.
_OEMBED = (
    ("youtube.com", "https://www.youtube.com/oembed?format=json&url={u}"),
    ("youtu.be", "https://www.youtube.com/oembed?format=json&url={u}"),
    ("tiktok.com", "https://www.tiktok.com/oembed?url={u}"),
    ("soundcloud.com", "https://soundcloud.com/oembed?format=json&url={u}"),
    ("dailymotion.com", "https://www.dailymotion.com/services/oembed?format=json&url={u}"),
    ("vimeo.com", "https://vimeo.com/api/oembed.json?url={u}"),
    ("twitter.com", "https://publish.twitter.com/oembed?url={u}"),
    ("x.com", "https://publish.twitter.com/oembed?url={u}"),
)


class Downloader:
    """Gestionnaire de telechargement asynchrone avec suivi de progression."""

    # Objet interne : ne doit pas etre expose au JS (cf. StorageManager._serializable).
    _serializable = False

    def __init__(self, download_dir_getter, on_event_callback, on_complete_callback):
        self.download_dir_getter = download_dir_getter
        self.on_event = on_event_callback
        self.on_complete = on_complete_callback
        self.downloading = False
        self._info_cache = {}     # url -> (timestamp, metadonnees oEmbed)
        self._last_emit = 0.0     # throttle des evenements de progression
        # ---- File d'attente ----
        # Plusieurs liens colles a la suite : au lieu de refuser le 2e ("un telechargement
        # est deja en cours"), on l'ajoute a la file et il demarre tout seul a la fin du
        # precedent. _queue_lock protege la liste (le pont JS et le thread yt-dlp y touchent).
        self._queue = []            # elements : (url, opts, mode)
        self._queue_lock = threading.Lock()
        self._queue_active = False  # un worker fait-il tourner la file ?

    # ------------------------------------------------------------------ metadonnees
    def _oembed(self, url):
        """Interroge l'API oEmbed de la plateforme (rapide). Retourne None si indisponible."""
        low = url.lower()
        endpoint = None
        for needle, tpl in _OEMBED:
            if needle in low:
                endpoint = tpl.format(u=urllib.parse.quote(url, safe=""))
                break
        if not endpoint:
            return None
        try:
            req = urllib.request.Request(
                endpoint,
                headers={"User-Agent": _UA, "Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read(200000).decode("utf-8", "replace"))
        except Exception:
            return None

        title = data.get("title")
        if not title:
            return None
        dur, ds = data.get("duration"), ""
        if dur:
            try:
                mm, ss = divmod(int(float(dur)), 60)
                ds = f"{mm}:{ss:02d}"
            except (TypeError, ValueError):
                ds = ""
        return {
            "title": title,
            "uploader": data.get("author_name") or data.get("provider_name"),
            "thumbnail": data.get("thumbnail_url") or data.get("thumbnail_url_with_play_button"),
            "extractor": data.get("provider_name"),
            "duration_string": ds,
            "fast": True,
        }

    def fetch_info(self, url):
        """Recupere les metadonnees sans telecharger.

        Boost : on tente d'abord oEmbed (1 requete, mise en cache 30 min) puis, seulement
        si la plateforme n'est pas couverte, l'extraction yt-dlp complete.
        """
        url = (url or "").strip()
        if not url:
            raise ValueError("URL vide")

        hit = self._info_cache.get(url)
        if hit and (time.time() - hit[0]) < INFO_CACHE_TTL:
            return dict(hit[1])

        fast = self._oembed(url)
        if fast:
            if len(self._info_cache) > 60:  # borne memoire : on jette l'entree la plus ancienne
                oldest = min(self._info_cache, key=lambda k: self._info_cache[k][0])
                self._info_cache.pop(oldest, None)
            self._info_cache[url] = (time.time(), fast)
            return dict(fast)

        if yt_dlp is None:
            raise ValueError("Installez yt-dlp : pip install yt-dlp")

        opts = {
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "skip_download": True,
            "cachedir": CACHE_DIR,
        }
        if _IMPERSONATE:
            opts["impersonate"] = _IMPERSONATE
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
        dur = info.get("duration") or 0
        mm, ss = divmod(int(dur), 60)
        return {
            "title": info.get("title"),
            "uploader": info.get("uploader") or info.get("channel"),
            "thumbnail": info.get("thumbnail"),
            "extractor": info.get("extractor_key"),
            "duration_string": f"{mm}:{ss:02d}" if dur else "",
        }

    def start_download(self, opts):
        """Ajoute un telechargement a la file puis demarre le worker si besoin.

        Si un telechargement est deja en cours, le nouveau lien n'est plus refuse :
        il est mis en attente et demarrera automatiquement a la fin du precedent.
        """
        if yt_dlp is None:
            raise ValueError("Installez yt-dlp : pip install yt-dlp")
        url = (opts.get("url") or "").strip()
        if not url:
            raise ValueError("URL vide")
        mode = opts.get("mode", "video")
        with self._queue_lock:
            self._queue.append((url, opts, mode))
            position = len(self._queue)
        self.on_event({"type": "queued", "title": url, "position": position,
                       "pending": self.pending_count()})
        self._ensure_worker()
        return {"ok": True, "queued": True, "position": position,
                "pending": self.pending_count()}

    def pending_count(self):
        """Nombre d'elements encore en file (hors telechargement en cours)."""
        with self._queue_lock:
            return len(self._queue)

    def cancel_all(self):
        """Vide la file d'attente (le telechargement en cours n'est pas interrompu)."""
        with self._queue_lock:
            n = len(self._queue)
            self._queue = []
        if n:
            self.on_event({"type": "queue", "pending": 0, "cleared": n})
        return n

    def _ensure_worker(self):
        """Demarre le worker de file s'il ne tourne pas deja."""
        with self._queue_lock:
            if self._queue_active:
                return
            self._queue_active = True
        threading.Thread(target=self._queue_worker, name="chape-dl-queue", daemon=True).start()

    def _queue_worker(self):
        """Consomme la file : un telechargement a la fois, dans l'ordre d'arrivee."""
        try:
            while True:
                with self._queue_lock:
                    if not self._queue:
                        self._queue_active = False
                        return
                    url, opts, mode = self._queue.pop(0)
                    remaining = len(self._queue)
                self.downloading = True
                self.on_event({"type": "queue", "pending": remaining, "current": url})
                self._run_download(url, opts, mode)
                # _run_download a remis self.downloading a False : on enchaine le suivant.
                # Si la file est vide, on signale explicitement la fin pour que le front
                # remette le bouton Telecharger a l'etat normal et rafraichisse l'historique.
                with self._queue_lock:
                    if not self._queue:
                        self._queue_active = False
                        self.on_event({"type": "queue", "pending": 0, "done": True})
                        return
        finally:
            with self._queue_lock:
                if not self._queue:
                    self._queue_active = False

    def _hook(self, d):
        if d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            done = d.get("downloaded_bytes", 0)
            # Certains flux (live, HLS, morceaux sans en-tete de taille) n'annoncent aucun
            # total : pct restait fige a 0 % pendant tout le telechargement. On envoie alors
            # le volume deja recu pour que l'utilisateur voie que ca avance.
            if total:
                pct = done / total * 100
            else:
                pct = None
            now = time.monotonic()
            # Throttle : 4 evenements/s maxi (le reseau appelle ce hook des dizaines de fois
            # par seconde). Moins de trafic vers JS = moins de repaint = plus de CPU pour yt-dlp.
            if now - self._last_emit < 0.25 and (pct is None or pct < 100):
                return
            self._last_emit = now
            ev = {
                "type": "progress",
                "pct": round(pct, 1) if pct is not None else None,
                "done": done,
                "total": total,
                "speed": (d.get("_speed_str") or "").strip(),
                "eta": (d.get("_eta_str") or "").strip(),
            }
            self.on_event(ev)
        elif d.get("status") == "finished":
            self._last_emit = 0.0
            self.on_event({"type": "status", "text": "Fusion / conversion...", "pct": 100})

    def _pp_hook(self, d):
        """Annonce les etapes de post-traitement (fusion, extraction audio) pour rassurer l'utilisateur."""
        if d.get("status") != "started":
            return
        pp = str(d.get("postprocessor") or "")
        if "Merger" in pp:
            text = "Fusion audio + video..."
        elif "ExtractAudio" in pp:
            text = "Extraction audio..."
        elif "VideoConvertor" in pp or "Remux" in pp:
            text = "Remux / conversion..."
        elif "Metadata" in pp or "EmbedSubtitle" in pp or "ThumbnailsConvertor" in pp:
            return
        elif "MoveFiles" in pp or "ModifyChapters" in pp or "FixupM" in pp:
            return
        else:
            text = "Post-traitement..."
        self._last_emit = 0.0
        self.on_event({"type": "status", "text": text, "pct": 100})

    # Windows refuse d'ouvrir un chemin de plus de 260 caracteres (MAX_PATH), et les
    # titres de reseau social sont souvent bien plus longs (hashtags, compteurs de vues,
    # separateurs, emojis : un post Facebook depasse allegegrement 250 caracteres).
    # -> « unable to open for writing: [Errno 2] No such file or directory ».
    MAX_PATH = 260
    # Marge de securite : le nom final porte encore ".part" pendant le telechargement,
    # et peut recevoir un suffixe de deduplication de yt-dlp (« .f123456789v ») quand
    # un fichier du meme nom existe deja. On garde donc de la place pour ces ajouts.
    PATH_MARGIN = 24

    # ------------------------------------------------------------------ fallback
    def _fallback_download(self, url, download_dir, mode="video", opts=None):
        """Moteur de secours Cobalt (pybalt), utilise si yt-dlp echoue sur l'URL.

        pybalt interroge une instance Cobalt (service en ligne) qui extrait le lien
        direct du media : robuste face aux changements d'extracteurs de yt-dlp, car
        la detection se fait cote serveur. Verifie en developpement : YouTube passe
        (tunnel + telechargement manuel), mais TikTok/Instagram renvoient
        « content.no_valid_content » selon l'instance — on remonte alors l'erreur
        telle quelle.

        Retourne (fpath, title) ou leve RuntimeError. `opts` porte la qualite/format
        demandes (vquality, aformat, aquality) pour construire la requete Cobalt.
        """
        if _PYBALT is None:
            raise RuntimeError("Moteur de secours (pybalt) non installe : pip install pybalt")
        import httpx
        os.makedirs(download_dir, exist_ok=True)
        opts = opts or {}

        # ---- Parametres Cobalt selon le mode ----
        params = {"filenameStyle": "basic"}
        if mode == "audio":
            params["downloadMode"] = "audio"
            want_ext = (opts.get("aformat") or "mp3").lower()
            if want_ext not in ("mp3", "ogg", "wav", "opus"):
                want_ext = "mp3"                 # Cobalt ne fait pas m4a/flac
            params["audioFormat"] = want_ext
            q = str(opts.get("aquality") or "192")
            params["audioBitrate"] = q if q.isdigit() else "192"
            want = want_ext
        else:
            params["downloadMode"] = "auto"
            q = str(opts.get("vquality") or "best")
            # Cobalt n'accepte que des hauteurs explicites : "best" -> 1080 (compromis
            # raisonnable pour un moteur de secours, on ne cherche pas la 4K ici)
            params["videoQuality"] = q if q.isdigit() else "1080"
            want = "mp4"

        # ---- Requete a l'instance (async pybalt -> boucle dediee dans ce thread worker) ----
        async def _tunnel():
            mgr = _PYBALT()
            try:
                return await mgr.first_tunnel(url=url, **params)
            finally:
                # Ferme proprement la session httpx interne de pybalt
                try:
                    await mgr.client.aclose()
                except Exception:
                    pass

        try:
            resp = asyncio.run(_tunnel())
        except Exception as e:
            raise RuntimeError("secours Cobalt : %s" % e)
        if not isinstance(resp, dict):
            # pybalt renvoie None quand aucune instance n'a repondu (erreur non geree
            # en interne : AttributeError sur None). On traduit en erreur lisible.
            raise RuntimeError("secours Cobalt : aucune instance disponible (registre "
                               "instances.cobalt.best injoignable ou URL non supportee)")
        if resp.get("status") == "error":
            err = (resp.get("error") or {}).get("code") or "erreur inconnue"
            raise RuntimeError("secours Cobalt : %s" % err)
        if resp.get("status") == "picker":
            # Posts multi-media : on prend le premier element video disponible
            items = resp.get("picker") or []
            v = next((i for i in items if i.get("type") == "video" and i.get("url")), None)
            if not v:
                raise RuntimeError("secours Cobalt : aucun media video dans le post")
            dl_url = v["url"]
            filename = None      # pas de nom fourni par Cobalt sur un picker
        elif resp.get("status") in ("tunnel", "redirect"):
            dl_url = resp.get("url")
            filename = resp.get("filename")
        else:
            raise RuntimeError("secours Cobalt : reponse inattendue (%s)" % resp.get("status"))
        if not dl_url:
            raise RuntimeError("secours Cobalt : lien direct absent de la reponse")

        # ---- Telechargement du fichier en streaming (progression vers l'interface) ----
        base = os.path.splitext(filename or "video")[0] or "video"
        base = base[: self._title_budget(download_dir, want)]
        dest = os.path.join(download_dir, base + "." + want)
        n = 0
        total = 0
        try:
            with httpx.Client(follow_redirects=True, timeout=180) as c:
                with c.stream("GET", dl_url) as r:
                    r.raise_for_status()
                    total = int(r.headers.get("content-length") or 0)
                    with open(dest, "wb") as f:
                        last = 0.0
                        for chunk in r.iter_bytes(1 << 16):
                            f.write(chunk)
                            n += len(chunk)
                            # meme throttle que _hook : 4 evt/s maxi
                            now = time.monotonic()
                            if total and now - last > 0.25:
                                last = now
                                self.on_event({"type": "progress",
                                               "pct": round(n / total * 100, 1),
                                               "done": n, "total": total,
                                               "speed": "", "eta": ""})
        except Exception as e:
            try:
                os.remove(dest)
            except OSError:
                pass
            raise RuntimeError("secours Cobalt : telechargement impossible (%s)" % e)
        if n < 1024:  # fichier « fantome » (erreur HTML, page vide...) : on refuse
            try:
                os.remove(dest)
            except OSError:
                pass
            raise RuntimeError("secours Cobalt : fichier vide ou refuse")
        return dest, base

    def _gallery_dl_download(self, url, download_dir, mode="video", opts=None):
        """3e moteur de secours : gallery-dl, execute en sous-processus isole.

        Reelu quand yt-dlp (3 strategies) ET Cobalt ont echoue : gallery-dl possede
        ses propres extracteurs (Facebook, Instagram, X, sites d'images...), donc il
        couvre des cas que les deux premiers moteurs ne traitent plus.

        Le processus est isole (pas d'import en interne du module gallery_dl, qui
        installe ses propres gestionnaires de signaux) avec un timeout dure.
        Retourne (fpath, title) ou leve RuntimeError.
        """
        # Le module n'est pas importe ici (il installe ses propres handlers de
        # signaux) : la presence est testee via importlib.util.find_spec.
        import importlib.util
        if importlib.util.find_spec("gallery_dl") is None:
            raise RuntimeError("Moteur de secours (gallery-dl) non installe : pip install gallery-dl")
        import subprocess
        opts = opts or {}
        os.makedirs(download_dir, exist_ok=True)

        # gallery-dl ecrit le fichier avec son propre schema de nommage : on fait un
        # snapshot du dossier avant/apres pour retrouver le(s) nouveau(x) fichier(s).
        # On n'impose pas de schema -f (mots-cles variables selon l'extracteur) :
        # le nommage par defaut + -D (dossier exact) suffit, le plus gros fichier
        # nouveau identifie le media principal.
        before = {f for f in os.listdir(download_dir)}
        cmd = [
            sys.executable, "-m", "gallery_dl",
            "-D", download_dir,                # dossier exact (pas de sous-dossiers)
            "--windows-filenames",             # flag sans argument : noms valides Windows
            "-w",                               # warnings seulement : sortie courte
            url,
        ]
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True,
                encoding="utf-8", errors="replace",
                timeout=300,                    # 5 min maxi puis on abandonne
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError("secours gallery-dl : delai depasse (5 min)")
        except OSError as e:
            raise RuntimeError("secours gallery-dl : lancement impossible (%s)" % e)

        # Nouveaux fichiers non vides apparus pendant l'execution
        produced = []
        for name in os.listdir(download_dir):
            if name in before:
                continue
            p = os.path.join(download_dir, name)
            if os.path.isfile(p) and os.path.getsize(p) > 0:
                produced.append(p)
        if not produced:
            err = (proc.stderr or proc.stdout or "").strip().splitlines()
            err = err[-1] if err else "aucun fichier produit (extracteur non supporte)"
            raise RuntimeError("secours gallery-dl : %s" % err)

        # Plus gros fichier = le media principal (gallery-dl telecharge aussi des
        # vignettes / metadonnees sur certains extracteurs).
        fpath = max(produced, key=lambda p: os.path.getsize(p))

        title = os.path.splitext(os.path.basename(fpath))[0]
        return fpath, title

    def _title_budget(self, download_dir, ext_hint="mp4"):
        """Nombre maximal de caracteres autorises pour le titre d'un fichier.

        On retranche la longueur reelle du dossier de destination : un dossier plus long
        doit donner un titre plus court. `trim_file_name` de yt-dlp ne suffit pas, car il
        decoupe sur `rsplit('.', 2)` : un titre contenant un point (« 8.8K reactions »)
        casse son calcul et le nom ressort en entier, plus long qu'avant.
        """
        dossier = len(download_dir.rstrip("\\/")) + 1
        ext_len = len(ext_hint) + 1
        budget = self.MAX_PATH - dossier - ext_len - self.PATH_MARGIN
        return max(40, min(120, budget))

    @staticmethod
    def _js_runtime():
        """Runtime JS disponible pour yt-dlp-ejs (deno prioritaire, sinon node).

        yt-dlp a besoin d'un moteur JavaScript pour les scripts YouTube (decodage
        des signatures, PO token). Sans lui il le « No supported JavaScript
        runtime » : certains formats manquent et les URLs googlevideo expirent
        plus vite, d ou les 403 « unable to download video data » intermittents.
        Retourne le nom du runtime, ou None si aucun n est installe (yt-dlp
        garde alors son comportement de repli embarque).
        """
        import shutil
        for name in ("deno", "node"):
            if shutil.which(name):
                return name
        return None

    def _build_options(self, opts, mode, download_dir):
        budget = self._title_budget(download_dir)
        # La troncature se fait DANS le template (« %(title).Ns ») : elle s'applique au
        # titre avant que yt-dlp ne recompose le nom, donc insensible aux points du titre.
        o = {
            "outtmpl": os.path.join(download_dir, "%%(title).%ds.%%(ext)s" % budget),
            "progress_hooks": [self._hook],
            "postprocessor_hooks": [self._pp_hook],
            "noplaylist": True,
            "windowsfilenames": True,
            "retries": 3,
            "fragment_retries": 5,
            "socket_timeout": 25,
            # ---- Boost vitesse ----
            "concurrent_fragment_downloads": FRAGMENT_WORKERS,  # 4 fragments en parallele
            "buffersize": NET_BUFFER,       # 1 Mo : moins d'ecritures disque pendant le telechargement
            "trim_file_name": budget,        # filet de securite (see _title_budget)
            "cachedir": CACHE_DIR,          # cache des extracteurs (JS YouTube, signatures...)
            # ---- Moins de bruit CPU/console ----
            "quiet": True,
            "no_warnings": True,
            "noprogress": True,
            "consoletitle": False,
        }
        if _IMPERSONATE:
            o["impersonate"] = _IMPERSONATE   # TikTok / sites anti-bot exigent un vrai profil navigateur
        # Runtime JS (node/deno) : indispensable a yt-dlp-ejs pour decoder les
        # signatures YouTube et emettre les PO tokens. Sans lui, URLs googlevideo
        # courtes duree -> 403 intermittents au milieu du telechargement.
        js = self._js_runtime()
        if js:
            o["js_runtimes"] = {js: {}}
        ff = ffmpeg_path()
        if ff:
            o["ffmpeg_location"] = ff

        if mode == "audio":
            want_ext = (opts.get("aformat") or "mp3").lower()
            if want_ext not in ("mp3", "m4a", "opus", "ogg", "wav", "flac"):
                want_ext = "mp3"
            # yt-dlp nomme le codec Vorbis "vorbis" dans sa table de codecs, mais ecrit
            # un fichier ".ogg" : envoyer "ogg" provoquerait un KeyError. On envoie donc
            # le nom de codec, tout en conservant l'extension attendue pour l'affichage.
            codec = "vorbis" if want_ext == "ogg" else want_ext
            qual = str(opts.get("aquality") or "192")
            o["format"] = "bestaudio/best"
            o["postprocessors"] = [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": codec,
                "preferredquality": qual,
            }]
            final_ext = want_ext
        else:
            ext = (opts.get("vformat") or "mp4").lower()
            if ext not in ("mp4", "mkv", "webm", "mov"):
                ext = "mp4"
            q = str(opts.get("vquality") or "best")
            # avc1 en tete pour mp4/mov seulement : le codec av01 (choisi par defaut
            # par yt-dlp, plus compact) est plus souvent refuse (403) par les CDN
            # video. Conteneurs ouverts (mkv/webm) : inutile, ils acceptent av01/vp9
            # et imposer avc1 ferait echouer le remux (h264 non valide en webm).
            avc_first = ext in ("mp4", "mov")
            if q == "best":
                if avc_first:
                    o["format"] = ("bestvideo[vcodec^=avc1]+bestaudio/"
                                   "bestvideo+bestaudio/best")
                else:
                    o["format"] = "bestvideo+bestaudio/best"
            else:
                if avc_first:
                    o["format"] = ("bestvideo[height<=%s][vcodec^=avc1]+bestaudio/"
                                   "bestvideo[height<=%s]+bestaudio/"
                                   "best[height<=%s]/best" % (q, q, q))
                else:
                    o["format"] = ("bestvideo[height<=%s]+bestaudio/"
                                   "best[height<=%s]/best" % (q, q))
            o["merge_output_format"] = ext
            final_ext = ext
            # ffmpeg ne sait pas produire de conteneur QuickTime ("mov") : yt-dlp tente,
            # echoue ("Conversion failed!") et laisse un .mov vide. On remuxe en mkv
            # (meme donnees, lecture universelle) tout en annonçant "mov" a l'interface.
            if ext == "mov":
                o["merge_output_format"] = "mkv"

        o["_final_ext"] = final_ext
        ydl_opts = {k: v for k, v in o.items() if k != "_final_ext"}
        return ydl_opts, final_ext

    def _strip_audio(self, fpath):
        """Renomme l'original en « (avec son) » puis cree la version « (sans son) ».

        Retourne le chemin de la version muette si tout s'est bien passe, sinon le chemin
        d'origine (comportement degrade : le telechargement n'est JAMAIS marque en echec
        a cause de cette option).
        """
        try:
            from .file_manager import FileManager
            base, ext = os.path.splitext(fpath)
            keep = base + " (avec son)" + ext
            os.replace(fpath, keep)      # l'original est garde, jamais detruit
            ok, res = FileManager.remove_audio(keep)
            if ok and os.path.isfile(res):
                return res
            os.replace(keep, fpath)      # echec : on restaure l'original, rien n'est perdu
        except Exception:
            pass
        return fpath

    def _push_fallback_notice(self, engine, orig_err):
        """Informe le front que le moteur de secours a ete utilise (banniere discret)."""
        self.on_event({"type": "status", "pct": 100,
                       "text": "Telecharge via le moteur de secours %s (yt-dlp : %s)" % (engine, orig_err[:80])})

    def _run_download(self, url, opts, mode):
        title, thumb, fpath = url, None, None
        # `info` doit exister avant le try : si extract_info echoue tot (ou renvoie None),
        # le bloc except lisait une variable non liee -> UnboundLocalError masquant la
        # vraie erreur (l'utilisateur voyait "local variable 'info' referenced before
        # assignment" au lieu du message du site).
        info = {}
        fmt = (opts.get("vformat") if mode == "video" else opts.get("aformat")) or ""
        download_dir = self.download_dir_getter()
        try:
            # Retour visuel immediat pendant l'extraction yt-dlp (2-8 s sans aucun evenement sinon)
            self.on_event({"type": "status", "text": "Analyse de la source...", "pct": 1})
            o, want = self._build_options(opts, mode, download_dir)
            with yt_dlp.YoutubeDL(o) as ydl:
                info = ydl.extract_info(url, download=True) or {}
                title = info.get("title", title)
                thumb = info.get("thumbnail")
                fpath = ydl.prepare_filename(info)
                if want:
                    base = os.path.splitext(fpath)[0]
                    # Le conteneur reel peut differer du format annonce (ex. "ogg" = vorbis
                    # dans un .ogg, "mov" remuxe en mkv). On cherche d'abord le nom
                    # attendu, puis le conteneur intermEDIAIRE (laisse vide par yt-dlp),
                    # et on ne retient que des fichiers non vides.
                    for cand in (base + "." + want, base + ".mkv", base + ".webm",
                                 base + ".mp4", base + ".m4a", base):
                        if os.path.isfile(cand) and os.path.getsize(cand) > 0:
                            fpath = cand
                            break
            size = 0
            if fpath:
                try:
                    size = os.path.getsize(fpath)
                except OSError:
                    size = 0
            # Option « Sans son » : le telechargement est un telechargement normal, puis on
            # retire la piste audio en local (ffmpeg -an -c copy : rapide, sans re-encodage).
            # Le fichier original (avec son) est conserve a cote sous « (avec son) ».
            if mode == "video" and opts.get("silent") and fpath and os.path.isfile(fpath):
                self.on_event({"type": "status", "text": "Suppression du son...", "pct": 100})
                fpath = self._strip_audio(fpath)
            dur = info.get("duration") or 0
            try:
                mm, ss = divmod(int(float(dur)), 60)
                duration = "%d:%02d" % (mm, ss)
            except (TypeError, ValueError):
                duration = ""
            entry = {
                "id": int(time.time() * 1000),
                "url": url,
                "title": title,
                "format": mode,                       # compatibilite avec l'ancien format
                "kind": mode,
                "ext": os.path.splitext(fpath)[1].lstrip(".") if fpath else fmt,
                "quality": str(opts.get("aquality") if mode == "audio" else opts.get("vquality") or ""),
                "uploader": info.get("uploader") or info.get("channel") or "",
                "extractor": info.get("extractor_key") or info.get("extractor") or "",
                "duration": duration,
                "size": size,
                "filepath": fpath,
                "thumbnail": thumb,
                "date": datetime.now().strftime("%d/%m/%Y %H:%M"),
                "status": "OK",
                "error": "",
            }
            # Infaillible : meme si l'enregistrement echoue (base verrouillee…),
            # l'evenement 'done' part quand meme sinon l'interface reste bloquee.
            try:
                self.on_complete(entry)
            except Exception:
                pass
            self.on_event({"type": "done", "title": title})
        except Exception as e:
            # ---- Moteurs de secours : Cobalt prend le relais, puis gallery-dl ----
            # Les deux sont tentes dans l'ordre ; si les deux echouent, les deux
            # causes sont concatenees dans l'erreur finale (diagnostic complet).
            fb_fallbacks = (
                ("Cobalt", lambda: self._fallback_download(url, download_dir, mode, opts)),
                ("gallery-dl", lambda: self._gallery_dl_download(url, download_dir, mode, opts)),
            )
            errors = []
            for fb_name, fb_call in fb_fallbacks:
                try:
                    self.on_event({"type": "status",
                                   "text": "yt-dlp a echoue, essai du moteur de secours (%s)..." % fb_name,
                                   "pct": 1})
                    fpath, fb_title = fb_call()
                    title = fb_title or title
                    # Option « Sans son » : appliquee quel que soit le moteur de secours
                    # (Cobalt ne la gerait pas avant ; yt-dlp la traite de son cote).
                    if mode == "video" and opts.get("silent") and fpath and os.path.isfile(fpath):
                        self.on_event({"type": "status", "text": "Suppression du son...", "pct": 100})
                        try:
                            fpath = self._strip_audio(fpath)
                        except Exception:
                            pass
                    size = 0
                    try:
                        size = os.path.getsize(fpath)
                    except OSError:
                        size = 0
                    entry = {
                        "id": int(time.time() * 1000),
                        "url": url,
                        "title": title,
                        "format": mode,
                        "kind": mode,
                        "ext": os.path.splitext(fpath)[1].lstrip("."),
                        "quality": str(opts.get("aquality") if mode == "audio" else opts.get("vquality") or ""),
                        "uploader": "",
                        "extractor": "%s (secours)" % fb_name,
                        "duration": "",
                        "size": size,
                        "filepath": fpath,
                        "thumbnail": thumb,
                        "date": datetime.now().strftime("%d/%m/%Y %H:%M"),
                        "status": "OK (secours)",
                        "error": "",
                    }
                    try:
                        self.on_complete(entry)
                    except Exception:
                        pass
                    self.on_event({"type": "done", "title": title})
                    self._push_fallback_notice(fb_name, str(e))
                    return
                except Exception as e2:
                    errors.append("%s : %s" % (fb_name, e2))
            e = type(e)("%s | secours echoue (%s)" % (e, " ; ".join(errors)))
            entry = {
                "id": int(time.time() * 1000),
                "url": url,
                "title": title,
                "format": mode,
                "kind": mode,
                "ext": fmt,
                "quality": str(opts.get("aquality") if mode == "audio" else opts.get("vquality") or ""),
                "uploader": "",
                "extractor": "",
                "duration": "",
                "size": 0,
                "filepath": fpath,
                "thumbnail": thumb,
                "date": datetime.now().strftime("%d/%m/%Y %H:%M"),
                "status": f"Erreur: {e}",
                "error": str(e),
            }
            try:
                self.on_complete(entry)
            except Exception:
                pass
            self.on_event({"type": "error", "message": str(e)})
        finally:
            self.downloading = False
            # Pas de gc.collect() ici : le GC Python debase suffit et un cycle complet
            # a chaque telechargement figeait l'interface quelques centaines de ms.

