r"""Genere icon.ico (multi-tailles) et icon.png depuis icon.svg.
Usage : python app\gen_icon.py      (ecrit dans app\web\)
Necessite : pip install pillow
"""
import os

BASE = os.path.dirname(os.path.abspath(__file__))
SVG = os.path.join(BASE, "web", "icon.svg")
ICO = os.path.join(BASE, "web", "icon.ico")
PNG = os.path.join(BASE, "web", "icon.png")

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    raise SystemExit("Installez pillow : python -m pip install pillow")

S = 256
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
# fond jaune brutaliste
d.rounded_rectangle([8, 8, S - 8, S - 8], radius=52, fill="#ffd02f",
                    outline="#111510", width=12)
# soleil sunset
d.ellipse([S // 2 - 52, 44, S // 2 + 52, 148], fill="#ff5a3c",
          outline="#111510", width=10)
# tronc arbre
d.rectangle([S // 2 - 12, 140, S // 2 + 12, 196], fill="#2d6a4f",
            outline="#111510", width=7)
# branches
d.arc([52, 130, S - 52, 220], start=200, end=340, fill="#2d6a4f", width=16)
# lettres CM
try:
    font = ImageFont.truetype("arialbd.ttf", 56)
except OSError:
    font = ImageFont.load_default()
d.text((S // 2, 222), "CM", font=font, fill="#111510", anchor="mm")

img.save(PNG)
img.save(ICO, sizes=[(16, 16), (24, 24), (32, 32), (48, 48),
                     (64, 64), (128, 128), (256, 256)])
print("OK ->", ICO, "et", PNG)
