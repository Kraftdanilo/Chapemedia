
/* ===== app.js ===== */
/* CHAPE-MEDIA - frontend */
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={mode:'video',vf:'mp4',vq:'best',af:'mp3',aq:'192',silent:false,tab:'history',playerEnabled:true,history:[],library:[],logs:[],favOnly:false,hf:'all',flashId:null,lastDoneTitle:null,refreshFails:0,currentPlay:null};
function toast(m,err=false){const d=document.createElement('div');d.className='toast'+(err?' err':'');d.setAttribute('role','status');d.textContent=m;$('#toasts').appendChild(d);setTimeout(()=>d.remove(),3800)}
/* Etat "occupe" d'un bouton : desactivation + libelle provisoire, restauration auto. */
function busy(btn,on,label){if(!btn)return;if(on){if(btn.dataset.lbl==null)btn.dataset.lbl=btn.textContent;btn.disabled=true;if(label)btn.textContent=label}else{btn.disabled=false;if(btn.dataset.lbl!=null)btn.textContent=btn.dataset.lbl}}
function setBar(p){$('#bar').style.width=Math.max(0,Math.min(100,p))+'%'}
function setStatus(t){$('#status').textContent=t}
/* Exposes pour la surcouche ux.js (statut colore, % au centre de la barre) :
   elles etaient locales, donc l'enrobage window.setBar/window.setStatus ne trouvait
   rien et les intervalles de repli tournaient en permanence dans le vide. */
window.setBar=setBar;window.setStatus=setStatus;
/* ---- fond anime ECO : respecte ?eco=1 / memoire faible, 45% opacite via CSS ---- */
(function(){const c=$('#bg-canvas');if(!c)return;
const QS=new URLSearchParams(location.search);
const ECO=QS.has('eco')||QS.get('lite')==='1'||(navigator.deviceMemory&&navigator.deviceMemory<=4);
let N=ECO?14:46;
try{const v=parseInt(localStorage.getItem('dna_eco_n')||'0');if(v>0)N=Math.min(v,ECO?18:60)}catch(e){}
const x=c.getContext('2d',{alpha:true});let W,H,run=true;
function rs(){const dpr=ECO?1:Math.min(devicePixelRatio||1,1.5);W=innerWidth;H=innerHeight;c.width=W*dpr|0;c.height=H*dpr|0;x.setTransform(dpr,0,0,dpr,0,0)}
addEventListener('resize',rs);rs();
const SUN=['#ff5a3c','#ff8a5b','#c81e1e'],TREE=['#2d6a4f','#74c69d','#16442e'],BLACK='#111510';
const P=[];for(let i=0;i<N;i++)P.push({x:Math.random()*2200,y:Math.random()*1400,s:8+Math.random()*24,vx:-.2-Math.random()*.4,vy:-.1-Math.random()*.3,r:Math.random()*6.28,vr:(Math.random()-.5)*.02,k:i%4,sun:Math.random()>.42,o:.4+Math.random()*.6});
function frame(){x.clearRect(0,0,W,H);
for(const p of P){p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;
if(p.x<-40){p.x=W+40;p.y=Math.random()*H}if(p.y<-40){p.y=H+40;p.x=Math.random()*W}
const col=p.sun?SUN[p.s%3|0]:TREE[p.s%3|0];x.globalAlpha=p.o;
const px=p.x%W,py=p.y%H;
if(p.k===0){x.strokeStyle=col;x.lineWidth=3;x.beginPath();x.moveTo(px-p.s*.5,py);x.lineTo(px+p.s*.5,py);x.moveTo(px,py-p.s*.5);x.lineTo(px,py+p.s*.5);x.stroke()}
else if(p.k===1){x.save();x.translate(px,py);x.rotate(p.r);x.fillStyle=col;x.beginPath();x.moveTo(0,-p.s*.6);x.lineTo(p.s*.55,p.s*.45);x.lineTo(-p.s*.55,p.s*.45);x.closePath();x.fill();x.restore()}
else if(p.k===2){x.lineWidth=3;x.strokeStyle=col;x.beginPath();x.arc(px,py,p.s*.45,0,7);x.stroke()}
else{x.save();x.translate(px,py);x.rotate(p.r);x.fillStyle=col;x.fillRect(-p.s/2,-p.s/2,p.s,p.s);x.restore()}}
x.globalAlpha=1}
let last=0;
/* Delai sans interaction avant de considers la fenetre « au repos ». */
const IDLE_MS=15000;
/* Cadence adaptative : le fond ralentit pendant un telechargement ou la lecture d'une video
   pour laisser 100% du CPU au moteur de telechargement (le rendu reste fluide visuellement).
   RAM/CPU : inactif (aucun clic ni mouvement de souris depuis IDLE_MS), le fond passe en
   tres basse frequence - c'est l'etat de repos reel d'une fenetre laissee ouverte. */
const modalEl=$('#player-modal');
let lastAct=Date.now();
addEventListener('pointermove',()=>{lastAct=Date.now()},{passive:true});
addEventListener('keydown',()=>{lastAct=Date.now()});
addEventListener('pointerdown',()=>{lastAct=Date.now()});
function stepMs(){
  if(state.downloading||(modalEl&&!modalEl.classList.contains('hidden')))return ECO?180:100;
  if(Date.now()-lastAct>IDLE_MS)return ECO?900:500;   // fenetre inactive : 2 a 5 images/s
  return ECO?66:33;
}
/* Fenetre masquee : on arrete DEFINITIVEMENT la boucle (plus de requestAnimationFrame).
   Le navigateur ne fait que limiter le debit, les callbacks restaient empiles ; on les
   supprime et on relance a la visibilite. */
document.addEventListener('visibilitychange',()=>{run=!document.hidden;if(run){last=0;requestAnimationFrame(fr)}});
function fr(t){if(!run)return;if(t-last>=stepMs()){last=t;frame()}requestAnimationFrame(fr)}
requestAnimationFrame(fr);
window.DNA_ECO={on:ECO,set(n){try{localStorage.setItem('dna_eco_n',String(n))}catch(e){}location.reload()}}})();
/* ---- segments / pills ---- */
$('#seg-mode').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;state.mode=b.dataset.mode;$$('#seg-mode button').forEach(z=>z.classList.toggle('active',z===b));$('#video-opts').classList.toggle('hidden',state.mode!=='video');$('#audio-opts').classList.toggle('hidden',state.mode!=='audio')});
function pill(id,key){$(id).addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;$$(id+' button').forEach(z=>z.classList.toggle('active',z===b));state[key]=b.dataset.vf||b.dataset.vq||b.dataset.af||b.dataset.aq})}
pill('#video-formats','vf');pill('#video-quality','vq');pill('#audio-formats','af');pill('#audio-quality','aq');
/* Option « 🔇 Sans son » : retire la piste audio de la video telechargee (l'original avec son est garde). */
$('#toggle-silent').addEventListener('click',()=>{state.silent=!state.silent;
 const b=$('#toggle-silent');b.classList.toggle('on',state.silent);b.setAttribute('aria-pressed',state.silent);
 setStatus(state.silent?'🔇 Sans son activé : la vidéo téléchargée sera muette (l\'original avec son reste gardé).':'🔊 Son réactivé.')});

/* ===== app2.js ===== */
/* Tabs + search + player switch + render pagine */
const PAGE=30;let shown=PAGE,searchT=null;
$$('.tabs button[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;shown=PAGE;
 $$('.tabs button[data-tab]').forEach(z=>z.classList.toggle('active',z===b));
 $('#hist-filters').classList.toggle('hidden',state.tab!=='history');
 $('#search').placeholder=state.tab==='log'?'🔎 FILTRER LE JOURNAL…'
  :(state.tab==='library'?'🔎 RECHERCHER DANS LA MÉDIATHÈQUE…':'🔎 RECHERCHER TITRE, FORMAT…');
 /* le journal vit en base : on va le chercher a la demande (jamais au boot) */
 if(state.tab==='log'&&!state.logs.length)
  api('get_logs',200).then(r=>{state.logs=r||[];applyCounts();render()}).catch(()=>{});
 render()});
/* Recherche : pour l'historique la recherche se fait cote donnees (accents et casse
   ignores, resultats instantanes) ; mediatheque et journal sont filtres en local. */
$('#search').addEventListener('input',()=>{clearTimeout(searchT);searchT=setTimeout(onSearch,180)});
async function onSearch(){
 const q=$('#search').value.trim();
 if(state.tab==='history'&&q.length>=2){
  try{
   if(state.favOnly){            /* mode favoris : on ne sort pas du filtre actif */
    const f=(await api('get_favorites'))||{};const k=q.toLowerCase();
    state.history=(f.history||[]).filter(i=>((i.title||'')+' '+(i.ext||'')+' '+(i.uploader||'')).toLowerCase().includes(k))}
   else state.history=(await api('search_history',q,200))||[];
   applyCounts();shown=PAGE;render();
   setStatus('Recherche : '+state.history.length+' résultat(s)')}catch(e){console.error('search:',e);toast('Recherche impossible',true)}
  return}
 if(state.tab==='history'&&!q){refresh();return}
 shown=PAGE;render()}
$('#toggle-player').onclick=e=>{const b=e.currentTarget;state.playerEnabled=!state.playerEnabled;b.classList.toggle('on',state.playerEnabled);b.setAttribute('aria-pressed',state.playerEnabled);api('set_player_enabled',state.playerEnabled).catch(()=>{});toast(state.playerEnabled?'Lecture integree activee':'Lecture integree coupee (ouverture externe)')};
async function api(name, ...args) {
  if (!window.backend) {
    if (name !== 'poll_events') {
      toast('Interface non disponible', true);
    }
    throw new Error('no-bridge');
  }
  return window.backend[name](...args);
}
/* bridge.js expose window.backend = proxy vers FastAPI (POST /api/<nom>). */
function esc(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
/* Polling intelligent : long-polling cote application (wait_ms).
   - au repos : 1 seul appel toutes les ~20 s (0 CPU consomme dans le vide)
   - pendant un telechargement : reprise immediate a chaque lot d'evenements
   - fenetre cachee : plus aucun appel, puis resync au retour */
let pollTimer=null,pollBusy=false,pollStop=false;
function pollSoon(ms){clearTimeout(pollTimer);pollTimer=setTimeout(poll,Math.max(0,ms))}
async function poll(){
 if(pollBusy||pollStop)return;
 pollBusy=true;let gap=state.downloading?150:400;
 try{const ev=await api('poll_events',state.downloading?1200:20000);const arr=ev||[];
  for(let i=0;i<arr.length;i++)handleEvent(arr[i]);
  if(arr.length)gap=state.downloading?120:10}
 catch(e){gap=800}
 finally{pollBusy=false}
 if(!pollStop)pollSoon(gap)}
poll();
document.addEventListener('visibilitychange',()=>{pollStop=document.hidden;if(pollStop){clearTimeout(pollTimer)}else{refresh();poll()}});
function handleEvent(ev){
 if(ev.type==='progress'){state.downloading=true;setBar(ev.pct||0);if(!handleEvent._l||Date.now()-handleEvent._l>500){handleEvent._l=Date.now();setStatus('Telechargement '+(ev.pct||0).toFixed(1)+'% '+(ev.speed||''))}}
 else if(ev.type==='status'){setStatus(ev.text||'');if(ev.pct!=null)setBar(ev.pct)}
 else if(ev.type==='done'){state.downloading=false;setBar(100);setStatus('Termine : '+(ev.title||''));toast('Termine '+(ev.title||''));busy($('#btn-download'),0);state.lastDoneTitle=ev.title||'';refresh()}
 else if(ev.type==='error'){state.downloading=false;setStatus('Erreur '+(ev.message||''));toast('Erreur '+(ev.message||''),true);busy($('#btn-download'),0);refresh()}
 else if(ev.type==='update'){
  /* Mise a jour : progression dans le bloc Mentions legales, jamais dans la barre principale
     (sinon un telechargement de paquet serait confondu avec un telechargement de media). */
  const st=ev.stage||'';
  if(st==='downloading')updStatus((ev.text||'Téléchargement')+' '+Math.round(ev.pct||0)+' %');
  else if(st==='preparing')updStatus('Décompression du paquet…');
  else if(st==='ready'){updStatus('Version '+(ev.version||'')+' vérifiée : prête à installer');const b=$('#btn-update-install');if(b)b.classList.remove('hidden');toast('Mise à jour '+(ev.version||'')+' disponible')}
  else if(st==='uptodate')updStatus(ev.text||'Vous utilisez la dernière version');
  else if(st==='available'){updStatus('Version '+(ev.version||'')+' disponible — cliquez sur « Vérifier les mises à jour »');toast('Mise à jour '+(ev.version||'')+' disponible')}
  else if(st==='error')updStatus(ev.text||'Erreur de mise à jour',true);
  else updStatus(ev.text||'');
 }
}
async function boot(){try{const cfg=await api('get_config');$('#dest-path').textContent=cfg.download_dir||'…';if(cfg.player_enabled!=null){state.playerEnabled=!!cfg.player_enabled;$('#toggle-player').classList.toggle('on',state.playerEnabled)}}catch(e){}
 refresh();setTimeout(()=>{try{if(!document.hidden&&$('#url')!==document.activeElement)$('#url').focus()}catch(e){}},200)}

/* ===== app3.js ===== */
/* Refresh : les appels partent EN PARALLELE (l'interface est multithread) et la
   mediatheque est servie par l'index local synchronise avec le disque, sauf demande
   explicite (clic sur Actualiser). */
async function refresh(force){try{
 const wantLogs=state.tab==='log';
 /* Mode favoris : une seule requete renvoie l'historique ET la mediatheque filtres */
 const jobs=[state.favOnly?api('get_favorites'):api('get_history',150,false),api('scan_library',!!force)];
 if(wantLogs)jobs.push(api('get_logs',200));
 const [first,lib,logs]=await Promise.all(jobs);
 if(state.favOnly){state.history=(first&&first.history)||[];state.library=(first&&first.library)||[]}
 else{state.history=first||[];state.library=lib||[]}
 if(wantLogs)state.logs=logs||[];
 state.refreshFails=0;
 /* Apres un telechargement : on ramene l'utilisateur sur l'historique, on vide la
    recherche et on fait clignoter la nouvelle ligne -> il voit SA video tout de suite. */
 if(state.lastDoneTitle){
  const want=state.lastDoneTitle;state.lastDoneTitle=null;
  if(state.tab!=='history')selectTab('history');
  if($('#search').value)$('#search').value='';
  /* Un filtre avance actif (erreurs, manquants, 24 h...) masquerait la nouvelle ligne :
     on revient a TOUS pour etre sur que l'utilisateur voit son telechargement. */
  if(state.hf!=='all'){state.hf='all';$$('#hist-filters button[data-hf]').forEach(z=>z.classList.toggle('active',z.dataset.hf==='all'));}
  const top=state.history[0];
  if(top&&top.title===want){state.flashId=top.id;clearTimeout(refresh._flashT);
   refresh._flashT=setTimeout(()=>{state.flashId=null;render()},9000)}
 }
 syncFavBanner();applyCounts();shown=PAGE;render()
 }catch(e){
  /* Plus jamais de liste vide silencieuse : on annonce, on journalise, on retente. */
  console.error('refresh:',e);state.refreshFails=(state.refreshFails||0)+1;
  if(state.refreshFails===1)toast('Actualisation impossible : nouvelle tentative…',true);
  if(state.refreshFails<=3)setTimeout(()=>refresh(true),800);
 }}
/* Bascule programmatique d'onglet (meme logique que le clic utilisateur). */
function selectTab(name){const b=$$('.tabs button[data-tab]').find(z=>z.dataset.tab===name);if(b)b.click()}
/* Bandeau "filtre favoris actif" : l'utilisateur ne doit jamais se retrouver avec
   deux listes vides sans savoir pourquoi. */
function syncFavBanner(){const b=$('#fav-banner');if(b)b.classList.toggle('hidden',!state.favOnly)}
function applyCounts(){$('#count-hist').textContent=state.history.length;
 $('#count-lib').textContent=state.library.length;$('#count-log').textContent=(state.logs||[]).length;
 if($('#hf-count'))$('#hf-count').textContent=state.tab==='history'
  ?(histFilter(state.history).length+' / '+state.history.length):''}
/* Filtre ⭐ FAVORIS : historique et mediatheque viennent filtres par la base. */
async function showFavorites(on){
 state.favOnly=!!on;$('#btn-fav').classList.toggle('on',state.favOnly);
 await refresh(true);
 if(state.favOnly)toast('⭐ Favoris : '+state.history.length+' telechargement(s), '+state.library.length+' fichier(s)')}
function currentList(){return state.tab==='history'?state.history:(state.tab==='library'?state.library:(state.logs||[]))}
function searchable(it){return state.tab==='log'
 ?((it.message||'')+' '+(it.level||'')+' '+(it.ctx||'')).toLowerCase()
 :((it.title||'')+' '+(it.format||'')+' '+(it.ext||'')+' '+(it.uploader||'')).toLowerCase()}
/* Filtres avances de l'historique (TOUS / 24 h / 7 jours / erreurs / fichier manquant).
   Appliques en local sur les lignes deja chargees : aucun appel reseau, rendu immediat. */
function histFilter(src){
 const f=state.hf||'all';
 if(f==='all')return src;
 const now=Date.now()/1000;
 const d=new Date();d.setHours(0,0,0,0);const d0=d.getTime()/1000;
 return src.filter(it=>{
  if(f==='today')return (it.created_at||0)>=d0;
  if(f==='7d')return (it.created_at||0)>=now-604800;
  if(f==='errors'){const s=(it.status||'').toLowerCase();return !!it.error||s.startsWith('erreur')||s.startsWith('error')}
  if(f==='missing')return it.present===false;
  return true})}
function filtered(){const q=$('#search').value.trim().toLowerCase();const src=currentList();
 if(!q||state.tab==='history')return histFilter(src);   /* historique : recherche deja filtree cote donnees */
 return src.filter(i=>searchable(i).includes(q))}
function star(it){return '<button class="icon-btn star'+(it.favorite?' on':'')+'" data-act="fav" data-id="'
 +esc(it.id||('lib:'+it.path))+'" title="'+(it.favorite?'Retirer des favoris':'Ajouter aux favoris ⭐')+'">'
 +(it.favorite?'★':'☆')+'</button>'}
function plays(it){return it.plays>0?'<span class="badge sun">👁 '+it.plays+'</span> ':''}
function rowHtml(it){const isH=state.tab==='history';const id=isH?it.id:('lib:'+it.path);
 /* Badge d'etat : erreur / fichier manquant / OK (le titre porte le detail complet). */
 const st=String(it.status||'OK');const err=!!it.error||/^erreur|^error/i.test(st);
 const stBadge=isH?(err?'<span class="badge sun" title="'+esc(st)+'">âš  ERREUR</span>'
  :(it.present===false?'<span class="badge warn" title="Fichier absent du disque">🗑 MANQUANT</span>'
   :'<span class="badge" title="'+esc(st)+'">✅ OK</span>'))
  :'<span class="badge">'+esc(fmtSize(it.size))+'</span>';
 const fresh=isH&&state.flashId!=null&&String(it.id)===String(state.flashId)?' fresh':'';
 return '<div class="item'+fresh+'" data-id="'+esc(id)+'" data-ext="'+esc(it.ext||'')+'">'+(it.thumbnail?'<img src="'+esc(thumbUrl(it.thumbnail))+'" onerror="thumbFail(this)" loading="lazy" decoding="async" referrerpolicy="no-referrer">':'<img alt="">')+'<div class="meta"><h4 title="'+esc(it.title)+'">'+esc(it.title||'(sans titre)')+'</h4><p><span class="badge">'+esc((it.ext||it.format||'').toUpperCase())+'</span> '+stBadge+' '+plays(it)+'<span>'+esc(isH?(it.date||''):fmtDate(it.mtime))+'</span></p><div class="row">'+star(it)+'<button class="icon-btn" data-act="play" data-id="'+esc(id)+'">Lire</button><button class="icon-btn" data-act="open" data-id="'+esc(id)+'">Ouvrir</button><button class="icon-btn" data-act="folder" data-id="'+esc(id)+'">Dossier</button>'+(String(it.ext||'').toLowerCase().match(/^(mp4|mkv|webm|mov|m4v)$/)?'<button class="icon-btn" data-act="mute" data-id="'+esc(id)+'" title="Créer une copie sans son (original conservé)">🔇 Muet</button>':'')+(isH?'<button class="icon-btn" data-act="retry" data-id="'+esc(id)+'">Reessayer</button><button class="icon-btn" data-act="del" data-id="'+esc(id)+'">Suppr</button>':'<button class="icon-btn" data-act="dellib" data-id="'+esc(id)+'">Suppr</button>')+'</div></div></div>'}
/* Onglet JOURNAL : une ligne par evenement enregistre dans le journal. */
function logHtml(it){return '<div class="item log-item lvl-'+esc(it.level||'info')+'"><div class="meta"><h4>'+esc(it.message||'')+'</h4><p><span class="badge '+(it.level==='error'?'sun':'')+'">'+esc((it.level||'info').toUpperCase())+'</span> <span>'+esc(fmtStamp(it.ts))+'</span></p>'+(it.ctx?'<p class="ctx" title="'+esc(it.ctx)+'">'+esc(it.ctx)+'</p>':'')+'</div></div>'}
function fmtStamp(t){try{return new Date(t*1000).toLocaleString('fr-FR')}catch(e){return ''}}
/* Delegation d'evenements : 1 seul listener pour toutes les lignes (au lieu de ~150 closures
   recreees a chaque rendu) -> rendu plus rapide et moins de travail pour le garbage collector. */
$('#list').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.id==='more'){shown+=PAGE;render();return}
 if(b.dataset&&b.dataset.act)onItem(b.dataset.act,b.dataset.id)});
/* Barre de filtres de l'historique : rendu immediat, compteur mis a jour. */
$('#hist-filters').addEventListener('click',e=>{const b=e.target.closest('button[data-hf]');if(!b)return;
 state.hf=b.dataset.hf;
 $$('#hist-filters button[data-hf]').forEach(z=>z.classList.toggle('active',z===b));
 shown=PAGE;render();applyCounts()});
function render(){const box=$('#list');const arr=filtered();
 if(!arr.length){const q=$('#search').value.trim();box.innerHTML='<div class="empty">'
  +(q?'Aucun résultat pour <q>'+esc(q)+'</q>.<br>Essayez un autre mot.'
    :(state.favOnly?'Aucun favori ⭐ pour le moment.<br>Cliquez sur ☆ dans une ligne.'
    :(state.tab==='log'?'Journal vide.<br>Les telechargements et les operations apparaitront ici.'
    :(state.hf&&state.hf!=='all'?'Aucune entree avec ce filtre.<br>'
    :'Rien ici pour le moment.<br>Lancez un telechargement !'))))
  +((!q&&!state.favOnly)?'<p style="margin-top:10px"><button class="icon-btn" data-act="retry-list">🔄 Actualiser</button></p>':'')
  +'</div>';render._last=null;return}
 const slice=arr.slice(0,shown);
 const isLog=state.tab==='log';
 const out=new Array(slice.length);
 for(let i=0;i<slice.length;i++)out[i]=isLog?logHtml(slice[i]):rowHtml(slice[i]);
 let html=out.join('');
 if(arr.length>shown)html+='<button id="more" class="btn nb-btn" style="width:100%">+ AFFICHER PLUS ('+(arr.length-shown)+' RESTANTS)</button>';
 /* Rien n'a change au dernier refresh : on ne touche pas au DOM (le scroll est conserve). */
 if(html===render._last)return;
 const prevTop=box.scrollTop;
 box.innerHTML=html;render._last=html;
 if(prevTop>0)box.scrollTop=Math.min(prevTop,box.scrollHeight-box.clientHeight)}
function fmtSize(n){if(!n&&n!==0)return '—';const u=['o','Ko','Mo','Go'];let i=0;while(n>=1024&&i<3){n/=1024;i++}return n.toFixed(1)+' '+u[i]}
function fmtDate(t){try{return new Date(t*1000).toLocaleString('fr-FR')}catch(e){return ''}}
/* Vignette servie par le cache local (~/.chape_media/thumbs) : plus de hotlink casse,
   telechargee une seule fois puis servie par le serveur local (cache navigateur 7 j). */
function thumbUrl(u){if(!u)return '';try{return 'http://127.0.0.1:'+(state.mediaPort||8899)+'/thumb?url='+encodeURIComponent(u)}catch(e){return u}}
/* Vignette distante indisponible (hotlink expire, hors ligne, format refuse) :
   1) on tente la vignette locale extraite du media (ffmpeg, cote serveur) ;
   2) sinon on anime un placeholder propre (plus jamais d'icone d'image cassee). */
function thumbFail(img){
 if(!img||img.dataset.thumbFallback)return;
 img.dataset.thumbFallback='1';
 const item=img.closest('.item');
 const id=item&&item.dataset&&item.dataset.id;
 img.dataset.mediaPath='';
 if(id){
  const isH=!String(id).startsWith('lib:');
  const row=(isH?state.history:state.library).find(x=>String(isH?x.id:('lib:'+x.path))===String(id));
  const p=row&&row.path;
  if(p&&/\.(mp4|mkv|webm|mov|m4v|avi)$/i.test(p)){
   img.onerror=()=>{img.onerror=null;img.replaceWith(thumbPlaceholder(row&&row.ext))};
   img.src='http://127.0.0.1:'+(state.mediaPort||8899)+'/poster?path='+encodeURIComponent(p);
   return;
  }
 }
 img.replaceWith(thumbPlaceholder(item&&item.dataset&&item.dataset.ext));
}
/* Placeholder : carre degrade avec l'extension du fichier (MP4, MP3...). */
function thumbPlaceholder(ext){
 const d=document.createElement('div');
 d.className='thumb-ph';
 d.textContent=String(ext||'').replace('.','').toUpperCase().slice(0,4)||'—';
 return d;
}
async function onItem(act,id){
 if(act==='retry-list'){refresh(true);toast('Actualisation…');return}
 if(act==='fav'){const v=await api('toggle_favorite',String(id),null);
  const isH=!String(id).startsWith('lib:');
  const row=(isH?state.history:state.library).find(x=>String(isH?x.id:('lib:'+x.path))===String(id));
  if(row)row.favorite=!!v;
  toast(v?'⭐ Ajoute aux favoris':'Favori retire');
  if(state.favOnly)showFavorites(true);else{render();refresh()}
  return}
 if(act==='del'){if(confirm('Retirer ce telechargement de l historique ?\n(Les favoris seront aussi retires.)')){await api('delete_history',String(id));refresh()}return}
 if(act==='dellib'){if(confirm('Supprimer ce fichier du disque ?')){await api('delete_file',String(id).slice(4));refresh()}return}
 if(act==='mute'){
  const isL=String(id).startsWith('lib:');
  let p=null;
  if(isL){p=String(id).slice(4)}
  else{const h=state.history.find(x=>String(x.id)===String(id));if(h)p=h.filepath}
  if(!p)return toast('Fichier introuvable',true);
  if(!confirm('Créer une copie SANS son de cette vidéo ?\n(L\'original avec son est conservé.)'))return;
  toast('🔇 Suppression du son en cours…');
  try{const r=await api('remove_audio',p);
   if(r&&r.ok){setStatus('Suppression du son en cours…')}else toast((r&&r.error)||'Suppression du son impossible',true)}
  catch(e){toast('Suppression du son impossible : '+e,true)}
  return}
 let path=null,title='';
 if(String(id).startsWith('lib:')){path=String(id).slice(4);title=path.split(/[/\\]/).pop()}
 else{const h=state.history.find(x=>String(x.id)===String(id));if(!h)return;path=h.filepath;title=h.title;
  if(act==='retry'){$('#url').value=h.url||'';toast('URL remise dans le champ');return}}
 if(!path){toast('Fichier introuvable',true);return}
 if(act==='folder'){api('open_folder',path);return}
 if(act==='open'){api('open_external',path);return}
 markPlayed(id);                      /* compteur de lectures enregistre localement */
 if(!state.playerEnabled){api('open_external',path);return}
 openPlayer(path,title)}
/* Compteur de lectures : incremente localement, puis mis a jour a l'ecran sans rechargement. */
function markPlayed(id){api('mark_played',String(id)).catch(()=>{});
 const isH=!String(id).startsWith('lib:');
 const row=(isH?state.history:state.library).find(x=>String(isH?x.id:('lib:'+x.path))===String(id));
 if(row){row.plays=(row.plays||0)+1;render()}}
async function openPlayer(path,title){
 try{const url=await api('media_url',path);$('#player-title').textContent=title||'Lecture';
  const v=$('#video-el'),a=$('#audio-el');v.pause();a.pause();v.removeAttribute('src');a.removeAttribute('src');
  /* Le conteneur ne dit pas toujours s'il y a une image (mkv musical, mp4 sans video).
    1) on devine, 2) on ecoute 'error' : si l'element choisi refuse le flux, on bascule
    sur l'autre une seule fois. C'est ce qui evite le « lecteur muet » sur .m4a/.opus
    ou les conteneurs mal types par Windows. */
  const audioExt=['mp3','m4a','m4b','opus','ogg','oga','wav','flac','aac','wma'];
  const videoExt=['mp4','m4v','mov','mkv','webm','avi','flv','ts','wmv'];
  const ext=(path.split('.').pop()||'').toLowerCase();
  const isAudio=audioExt.includes(ext)?true:(videoExt.includes(ext)?false:false);
  const pick=(audio)=>{const el=audio?a:v;
   (audio?v:a).classList.add('hidden');el.classList.remove('hidden');
   el.preload='metadata';
   return el};
  let el=pick(isAudio);
  const fallback=()=>{
   const other=el===a?v:a;
   if(other.getAttribute('src'))return;      /* deja tente : evite la boucle */
   el.onerror=null;other.classList.remove('hidden');el.classList.add('hidden');
   other.preload='metadata';other.src=url;el=other;other.play().catch(()=>{});
  };
  el.onerror=fallback;
  try{el.loop=!!window.DNA_LOOP}catch(e){}
  el.src=url;
  /* Reprise : on retient la position par fichier (une lecture interrompue repart
     la ou on l'a laissee, sans refaire un seek manuel a chaque ouverture). */
  const key='dna_pos:'+path;let resume=0;try{resume=parseFloat(localStorage.getItem(key)||'0')||0}catch(e){}
  el.onloadedmetadata=()=>{try{if(resume>3&&resume<el.duration-3)el.currentTime=resume}catch(e){}};
  el.ontimeupdate=()=>{try{if(el.currentTime>3){localStorage.setItem(key,String(Math.floor(el.currentTime)))}}catch(e){}};
  $('#player-modal').classList.remove('hidden');if(window.resetPlayerPos)resetPlayerPos();
  el.play().catch(()=>{});
  state.currentPlay=path;
  if(window.setCurrentSharePath)window.setCurrentSharePath(path);
 }catch(e){toast('Lecture impossible, ouverture externe',true);api('open_external',path)}}

/* ===== app4.js ===== */
$('#player-close').onclick=()=>{$('#video-el').pause();$('#audio-el').pause();$('#player-modal').classList.add('hidden')};
$('#player-modal').addEventListener('click',e=>{if(e.target.id==='player-modal')$('#player-close').click()});
/* ---- Mini-lecteur : « réduire » cache la modale SANS arreter le média.
   L'element video/audio reste en lecture ; une pastille flottante en bas a droite
   permet de rouvrir la fenêtre ou de couper/reprendre. ---- */
let plMini=false;
function plMiniBadge(){
 let b=document.getElementById('mini-player-fab');
 if(!plMini){if(b)b.remove();return}
 if(!b){
  b=document.createElement('div');b.id='mini-player-fab';
  b.innerHTML='<button id="mini-play" title="Lecture / Pause">⏯</button><button id="mini-open" title="Rouvrir le lecteur">⬆</button><button id="mini-stop" title="Arrêter et fermer">✖</button>';
  document.body.appendChild(b);
  $('#mini-open').onclick=()=>plSetMini(false);
  $('#mini-stop').onclick=()=>{plSetMini(false);$('#player-close').click()};
  $('#mini-play').onclick=()=>{const el=plActiveEl();if(el){el.paused?el.play().catch(()=>{}):el.pause()}};
 }
 const el=plActiveEl();
 const bp=$('#mini-play');if(bp)bp.textContent=el&&el.paused?'▶':'⏯';
}
function plActiveEl(){const a=$('#audio-el'),v=$('#video-el');return a&&!a.classList.contains('hidden')?a:(v&&!v.classList.contains('hidden')?v:null)}
function plSetMini(on){plMini=!!on;
 $('#player-modal').classList.toggle('mini',plMini);
 $('#player-modal').classList.toggle('hidden',plMini);
 plMiniBadge();}
$('#player-min').onclick=()=>plSetMini(true);
// met a jour la pastille quand on pause/reprend depuis le mini-lecteur
['#video-el','#audio-el'].forEach(s=>{const el=$(s);if(el)el.addEventListener('play',()=>{if(plMini){const b=$('#mini-play');if(b)b.textContent='⏯'}else if(!plMini){}})});
/* Fenetre de lecture deplaçable : glisser la barre de titre (double-clic = recentrer). */
let plX=0,plY=0,plDrag=null;
function plApply(){const p=$('#player-modal .player');if(p)p.style.transform='translate('+plX+'px,'+plY+'px)'}
window.resetPlayerPos=function(){plX=0;plY=0;plApply()};
(function(){
 const head=document.querySelector('#player-modal .player-head');if(!head)return;
 head.addEventListener('pointerdown',e=>{
  if(e.target.closest('button'))return;
  plDrag={x:e.clientX,y:e.clientY,ox:plX,oy:plY};
  try{head.setPointerCapture(e.pointerId)}catch(_){}
  document.body.style.userSelect='none';e.preventDefault();
 });
 head.addEventListener('pointermove',e=>{
  if(!plDrag)return;
  plX=plDrag.ox+(e.clientX-plDrag.x);plY=plDrag.oy+(e.clientY-plDrag.y);plApply();
  const r=head.parentElement.getBoundingClientRect();let dx=0,dy=0;
  if(r.left<8)dx=8-r.left;else if(r.right>window.innerWidth-8)dx=(window.innerWidth-8)-r.right;
  if(r.top<0)dy=-r.top;else if(r.bottom>window.innerHeight-8)dy=(window.innerHeight-8)-r.bottom;
  if(dx||dy){plX+=dx;plY+=dy;plApply()}
 });
 const end=()=>{if(plDrag){plDrag=null;document.body.style.userSelect=''}};
 head.addEventListener('pointerup',end);head.addEventListener('pointercancel',end);
 head.addEventListener('dblclick',e=>{if(!e.target.closest('button'))window.resetPlayerPos()});
})();
$('#player-external').onclick=()=>{if(state.currentPlay)api('open_external',state.currentPlay)};
$('#player-folder').onclick=()=>{if(state.currentPlay)api('open_folder',state.currentPlay)};
$('#btn-folder').onclick=async()=>{
 /* Selecteur natif (app.py via window.pywebview.api) : Tk ne peut pas s'ouvrir depuis
    le thread du serveur. Repli sur choose_folder hors fenetre pywebview. */
 let d='';
 try{if(window.pywebview&&window.pywebview.api&&window.pywebview.api.pick_folder)
  d=await window.pywebview.api.pick_folder($('#dest-path').textContent||null)}catch(e){d=''}
 if(!d)d=await api('choose_folder');
 if(!d)return;
 d=await api('set_download_dir',d);
 if(d)$('#dest-path').textContent=d};
$('#btn-folder-top').onclick=()=>$('#btn-folder').click();
$('#btn-paste').onclick=async()=>{try{const t=await navigator.clipboard.readText();if(t)$('#url').value=t.trim()}catch(e){toast('Copiez puis collez (Ctrl+V)')}};
$('#btn-refresh').onclick=refresh;
$('#btn-clear').onclick=async()=>{
 if(state.tab==='log'){
  if(confirm('Vider tout le journal ?')){await api('clear_logs');state.logs=[];applyCounts();render();toast('Journal vidé')}}
 else if(state.tab==='history'){
  if(confirm("Vider tout l'historique ?\n(Les favoris ⭐ sont conservés.)")){await api('clear_history');refresh()}}
 else toast('La mediatheque reflete le dossier')};
$('#btn-info').onclick=async()=>{const u=$('#url').value.trim();if(!u)return toast("Collez une URL d'abord",true);
 setStatus('Analyse du lien…');try{const info=await api('fetch_info',u);$('#preview').classList.remove('hidden');
  $('#preview-title').textContent=info.title||u;$('#preview-meta').textContent=(info.uploader||'')+' • '+(info.duration_string||'')+' • '+(info.extractor||'');
  $('#preview-thumb').src=thumbUrl(info.thumbnail)||info.thumbnail||'';setStatus('Pret.')}catch(e){toast('Lien illisible : '+e,true);setStatus('Lien illisible')}};
$('#btn-download').onclick=async()=>{const u=$('#url').value.trim();if(!u)return toast('Collez une URL',true);
 busy($('#btn-download'),1,'⏳ TÉLÉCHARGEMENT…');setBar(2);setStatus('Connexion…');
 try{await api('start_download',{url:u,mode:state.mode,vformat:state.vf,vquality:state.vq,aformat:state.af,aquality:state.aq,silent:state.mode==='video'&&!!state.silent})}
 catch(e){busy($('#btn-download'),0);toast(''+e,true);setStatus(''+e)}};
/* ---- Outils donnees : favoris, statistiques, export, sauvegarde, dossier ---- */
$('#btn-fav').onclick=()=>showFavorites(!state.favOnly);
$('#btn-fav-reset').onclick=()=>showFavorites(false);
/* Nettoyage avance : retire les entrees dont le fichier n'existe plus sur le disque. */
$('#btn-prune-missing').onclick=async()=>{
 if(!confirm("Retirer de l'historique les entrees dont le fichier n'existe plus ?\n(Les favoris sont conserves.)"))return;
 try{const r=await api('prune_history_missing');
  toast((r&&typeof r.removed==='number')?r.removed+' entree(s) retiree(s)':'Nettoyage effectue');
  refresh()}catch(e){toast('Nettoyage impossible : '+e,true)}};
$('#btn-stats').onclick=async()=>{const box=$('#stats-box');
 if(!box.classList.contains('hidden')){box.classList.add('hidden');return}
 box.innerHTML='<div class="empty">Chargement des statistiques…</div>';box.classList.remove('hidden');
 busy($('#btn-stats'),1,'⏳ …');
 try{box.innerHTML=statsHtml(await api('get_stats'))}
 catch(e){box.classList.add('hidden');toast('Stats indisponibles',true)}
 finally{busy($('#btn-stats'),0)}};
$('#btn-export').onclick=async()=>{try{
 const r=await api('export_history');
 if(r&&r.ok){toast('💾 Export JSON : '+String(r.path).split(/[\\/]/).pop());api('open_folder',r.path)}
 else toast('Export impossible',true)}catch(e){toast('Export impossible',true)}};
$('#btn-backup').onclick=async()=>{try{
 const r=await api('backup_db');
 if(r&&r.ok)toast('💾 Sauvegarde : '+String(r.path).split(/[\\/]/).pop()+' ('+fmtSize(r.size)+')');
 else toast('Sauvegarde impossible',true)}catch(e){toast('Sauvegarde impossible',true)}};
$('#btn-data').onclick=()=>{api('open_db_folder').catch(()=>{})};
$('#btn-opt').onclick=async()=>{const btn=$('#btn-opt');busy(btn,1,'⏳ OPTIM…');
 setStatus('Optimisation des données…');
 try{
  const r=await api('optimize_db');setStatus('Pret.');
  if(r&&r.ok)toast('🧰 Données optimisées : '+fmtSize(r.before)+' → '+fmtSize(r.after)+' · intégrité '+(r.integrity||'ok'));
  else toast('Compactage impossible',true)}catch(e){toast('Compactage impossible',true);setStatus('Pret.')}
 finally{busy(btn,0)}};
/* Panneau STATS : tout est calcule cote donnees puis affiche en grille. */
function statsHtml(s){
 const cell=(l,v)=>'<div><span>'+l+'</span><b>'+v+'</b></div>';
 const sites=(s.top_sites||[]).map(x=>esc(String(x.site))+'&nbsp;·&nbsp;'+x.n).join('&nbsp;&nbsp;')||'—';
 const days=(s.daily||[]).slice(-7).map(d=>esc(String(d.day).slice(5))+'&nbsp;'+d.downloads).join('&nbsp;&nbsp;')||'—';
 return '<div class="stats-grid">'
  +cell('📥 TÉLÉCHARGEMENTS',s.downloads+' <small>('+s.video+' vidéo / '+s.audio+' audio)</small>')
  +cell('⭐ FAVORIS',s.favorites)
  +cell('👁 LECTURES',s.plays)
  +cell('📦 VOLUME TÉLÉCHARGÉ',fmtSize(s.bytes))
  +cell('âš  ERREURS',s.errors)
  +cell('📚 MÉDIATHÈQUE',s.library+' fichiers · '+fmtSize(s.library_bytes))
  +cell('🗄 STOCKAGE LOCAL',fmtSize(s.db_size))
  +cell('🗂 JOURNAL',s.logs+' lignes')
  +cell('🕘 DERNIER TÉLÉCHARGEMENT',esc(String(s.last||'—')))
  +cell('🌐 SITES',sites)
  +cell('📅 7 DERNIERS JOURS',days)
  +cell('📂 DOSSIER',esc(String(s.download_dir||'—')))
  +'</div>'}
document.addEventListener('backendready',boot);   /* émis par bridge.js quand FastAPI répond */
window.addEventListener('load',()=>setTimeout(()=>{if(!state.history.length&&!state.library.length)boot()},700));
/* ---- Mentions legales : createur Dane hk \Manifest, licence MIT + mise a jour integree ---- */
let updBusy=false,updArmTimer=null;
function updStatus(txt,err){const el=$('#update-status');if(!el)return;el.textContent=txt||'';el.classList.toggle('err',!!err)}
let legalDone=false;
async function openLegal(){
 $('#legal-modal').classList.remove('hidden');
 if(legalDone)return;legalDone=true;
 try{const v=await api('get_version');
  $('#legal-version').textContent=(v.name||'CHAPE-MEDIA')+' v'+(v.display_version||v.app_version||v.version||'?')+(v.installed_package?'':' — mode sources');
  if(v.installed_package&&v.writable===false)updStatus("Dossier programme protege : déplacez l'application dans un dossier personnel pour qu'elle puisse se mettre à jour.",true);
  else if(v.installed_package)updStatus('Source du manifeste : '+(v.update_url||v.source||'non configurée'));
  else updStatus('Mode sources : la mise à jour automatique ne remplace que la version installée (.exe)');
 }catch(e){}
}
$('#btn-legal').onclick=openLegal;
$('#legal-close').onclick=()=>$('#legal-modal').classList.add('hidden');
$('#legal-modal').addEventListener('click',e=>{if(e.target.id==='legal-modal')$('#legal-close').click()});
/* Verification : lit le manifeste publie (version + SHA-256 du paquet) puis telecharge en fond.
   L'installation reste volontaire : deux clics -> l'app se ferme, le script remplace les
   fichiers (avec retour arriere automatique) et redemarre. */
$('#btn-update-check').onclick=async e=>{
 const b=e.currentTarget;if(updBusy)return;updBusy=true;busy(b,1,'⏳ Vérification…');
 updStatus('Contact du serveur de mise à jour…');
 try{
  const r=await api('check_update');
  if(!r.ok)updStatus('Vérification impossible : '+(r.error||'serveur injoignable'),true);
  else if(r.available){updStatus('Version '+(r.latest||'?')+' disponible (installée : '+r.current+') — téléchargement…');
   const d=await api('download_update');if(d&&d.ok===false)updStatus(d.error||'Téléchargement impossible',true)}
  else updStatus('À jour : version '+(r.current||'?')+(r.latest?' (publiée : '+r.latest+')':' (aucune publication connue)'));
 }catch(err){updStatus('Interface indisponible',true)}
 busy(b,0);updBusy=false};
$('#btn-update-install').onclick=async e=>{
 const b=e.currentTarget;if(updBusy)return;
 if(b.dataset.arm!=='1'){
  b.dataset.arm='1';busy(b,1,'⚠️ Confirmer (l\'app va redémarrer)');
  clearTimeout(updArmTimer);updArmTimer=setTimeout(()=>{b.dataset.arm='0';busy(b,0)},8000);
  return}
 b.dataset.arm='0';updBusy=true;busy(b,1,'⏳ Installation…');
 try{const r=await api('install_update',true);
  if(r&&r.ok){updStatus("Installation lancée : CHAPE-MEDIA se ferme et redémarre sur la version "+((r.version)||'')+'…');toast('Mise à jour en cours…')}
  else{updStatus((r&&r.error)||'Installation impossible',true);busy(b,0);updBusy=false}}
 catch(err){updStatus('Interface indisponible',true);busy(b,0);updBusy=false}};

/* ---- Profil utilisateur : nom + photo, affiches dans le bandeau et modifiables ----
   Le nom est stocke en base, la photo est copiee dans APP_DATA/profile par le backend
   (set_profile copie le fichier choisi, l'interface ne transmet qu'un chemin local). */
function applyProfile(p){
 if(!p)return;
 const name=(p.name||'').trim();
 /* On prefere l'URL http servie par le serveur local : un chemin Windows brut mis
    dans <img src> devient file:///, que la webview bloque (page chargee en http).
    C'est ce qui faisait disparaitre la photo apres rechargement. */
 const photo=p.photo_url||'';
 const btnName=$('#profile-name');
 if(btnName)btnName.textContent=name||'PROFIL';
 const av=$('#profile-avatar');
 if(av){if(photo){av.classList.remove('hidden');av.src=photo+(photo.indexOf('?')<0?'?v='+Date.now():'')}
  else{av.classList.add('hidden');av.removeAttribute('src')}}
}
let profileLoaded=false;
async function openProfile(){
 $('#profile-modal').classList.remove('hidden');
 try{
  const p=await api('get_profile');
  $('#profile-name-input').value=(p.name||'');
  const pv=$('#profile-preview');
  if(pv&&p.photo){pv.dataset.preview=p.photo;pv.src=p.photo_url||p.photo}   /* handled by fixAvatar */
  profileLoaded=true;
 }catch(e){toast('Profil indisponible',true)}}
$('#btn-profile').onclick=openProfile;
$('#profile-close').onclick=()=>$('#profile-modal').classList.add('hidden');
$('#profile-modal').addEventListener('click',e=>{if(e.target.id==='profile-modal')$('#profile-close').click()});
$('#profile-photo-input').addEventListener('change',e=>{
 const f=e.target.files&&e.target.files[0];
 if(f){
  // apercu immediate : on affiche le fichier choisi avant l'enregistrement
  try{$('#profile-preview').src=URL.createObjectURL(f)}catch(_){}
  $('#profile-preview').dataset.pending=f.name}});
$('#profile-save').onclick=async e=>{
 const b=e.currentTarget;if(b.dataset.busy)return;b.dataset.busy='1';busy(b,1,'⏳ …');
 try{
  const name=$('#profile-name-input').value.trim();
  const file=$('#profile-photo-input').files&&$('#profile-photo-input').files[0];
  let photoPath='';
  if(file){
  // Photo de profil : le navigateur ne donne pas le chemin réel d'un fichier ;
   // on passe donc par une data-url traitée côté Python (save_profile_photo).
   const dataUrl=await new Promise(res=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>res('');r.readAsDataURL(file)});
   if(dataUrl){
    const r2=await api('save_profile_photo',dataUrl);
    if(r2&&r2.ok)photoPath=r2.path;
    else toast((r2&&r2.error)||'Photo non enregistree',true)}}
   const p=await api('set_profile',name,photoPath);
   if(p&&p.ok===false){toast(p.error||'Profil non enregistré',true);return}
   applyProfile(p);
  $('#profile-modal').classList.add('hidden');
  $('#profile-photo-input').value='';
  $('#profile-preview').dataset.pending='';
  toast(name?('Profil enregistré : '+name):'Profil enregistré');
 }catch(err){toast('Enregistrement impossible',true)}
 finally{b.dataset.busy='0';busy(b,0)}};
// chargement initial du profil au demarrage de l'interface
api('get_profile').then(applyProfile).catch(()=>{});

/* ---- Lecture en boucle ----
   Toggle actif : le média courant redemarre automatiquement a la fin (video ou audio).
   L'etat est conservé d'un média au suivant dans la session. */
let loopOn=!!window.DNA_LOOP;
$('#player-loop').onclick=()=>{
 loopOn=!loopOn;window.DNA_LOOP=loopOn;
 const v=$('#video-el'),a=$('#audio-el');
 v.loop=loopOn;a.loop=loopOn;
 $('#player-loop').textContent=loopOn?'🔁 BOUCLE : OUI':'🔁 BOUCLE : NON';
 $('#player-loop').classList.toggle('active',loopOn);
 toast(loopOn?'Lecture en boucle activée':'Lecture en boucle désactivée')};

/* ---- Partage par lien (appareils sur le même réseau / même navigateur) ----
   Le backend cree une URL http://<IP-LAN>:<port>/media?path=... ouverte dans le
   navigateur par defaut : n'importe quel appareil du réseau peut la consommer. */
let currentSharePath='';
window.setCurrentSharePath=function(p){currentSharePath=p||'';
 const el=$('#share-link');el.textContent='';el.classList.add('hidden')};
$('#player-share').onclick=async e=>{
 const b=e.currentTarget;if(b.dataset.busy)return;b.dataset.busy='1';
 try{
  const r=await api('share_media',currentSharePath);
  if(r&&r.ok){
   const el=$('#share-link');el.textContent=r.url;el.classList.remove('hidden');
   try{await navigator.clipboard.writeText(r.url);toast('Lien copié dans le presse-papiers')}
   catch(_){toast('Lien créé : '+r.url)}
   window.open(r.url,'_blank');
  }else toast((r&&r.error)||'Partage impossible',true);
 }catch(err){toast('Partage indisponible',true)}
 finally{b.dataset.busy='0'}};

/* ---- Raccourcis clavier ----
   Entrée  : lance le telechargement depuis le champ URL
   /       : focus sur la recherche (hors champ de saisie)
   Echap   : ferme le lecteur, puis les mentions, puis le panneau STATS ---- */
$('#url').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('#btn-download').click()}});
document.addEventListener('keydown',e=>{
 const t=e.target,typing=t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA');
 if(e.key==='Escape'){
  if(!$('#player-modal').classList.contains('hidden'))$('#player-close').click();
  else if(!$('#legal-modal').classList.contains('hidden'))$('#legal-close').click();
  else if(!$('#stats-box').classList.contains('hidden'))$('#btn-stats').click();}
 else if(e.key==='/'&&!typing){e.preventDefault();$('#search').focus()}
 else if(e.key==='Enter'&&t===$('#search')){e.preventDefault();onSearch()}});

/* ===== remix.js ===== */
/* CHAPE-MEDIA 1.0.4 remix — micro-couche UX non-destructive.
   Aucun id existant renommé, aucune API ajoutée : embellit + fiabilise.
   Communication : via window.backend (proxy FastAPI défini par bridge.js). */
(function(){
'use strict';
function $(s){return document.querySelector(s)}
/* 1. Badge version dynamique : affiche la version servie par le backend
      (display_version = "1.0.4 remix"), repli sur le texte statique. */
function paintVersion(v){
  var badge=$('#app-version-badge');if(!badge)return;
  var txt=(v&&(v.display_version||(v.app_version+(v.edition?' '+v.edition:''))))||'';
  if(txt)badge.textContent='v'+txt;
}
function fetchVersion(){
  if(!window.backend)return;
  window.backend.get_version().then(paintVersion).catch(function(){});
}
document.addEventListener('backendready',function(){setTimeout(fetchVersion,400)});
window.addEventListener('load',function(){setTimeout(fetchVersion,1200)});
/* 2. Boucle persistante : l'état survit au changement de média.
      openPlayer() réapplique window.DNA_LOOP ; le toggle reste la source. */
window.DNA_LOOP=!!window.DNA_LOOP;
function syncLoopBtn(){
  var b=$('#player-loop');if(!b)return;
  b.textContent=window.DNA_LOOP?'🔁 BOUCLE : OUI':'🔁 BOUCLE : NON';
  b.classList.toggle('active',window.DNA_LOOP);
}
document.addEventListener('click',function(e){
  if(e.target&&e.target.id==='player-loop'){
    setTimeout(function(){
      try{
        var on=$('#player-loop').classList.contains('active')
          ||$('#player-loop').textContent.indexOf('OUI')>=0;
        window.DNA_LOOP=on;
        var v=$('#video-el'),a=$('#audio-el');
        if(v)v.loop=on;if(a)a.loop=on;
      }catch(_){}
    },0);
  }
});
/* 3. Avatar : repli icône. Jamais de file:/// : la page vient de http://127.0.0.1,
   Chromium y interdit file:// — un chemin local brut ne s'affiche donc jamais.
   Le backend fournit photo_url (/profile/...), servie par le même serveur. */
function fixAvatar(img){
  if(!img||!img.getAttribute)return;
  if(!img.dataset.iconFallback){
    img.dataset.iconFallback='1';
    img.addEventListener('error',function(){
      var src=img.getAttribute('src')||'';
      if(src.indexOf('icon.svg')<0){try{img.src='icon.svg'}catch(_){}}
    });
  }
  var src=img.getAttribute('src')||'';
  if(/^[A-Za-z]:\\/.test(src)){
    // Chemin local residuel : inutilisable, on affiche l'icone plutot qu'une image cassee.
    try{img.removeAttribute('src');img.src='icon.svg'}catch(_){}
  }
}
if(typeof MutationObserver==='function'){
 new MutationObserver(function(muts){
  muts.forEach(function(m){
    m.addedNodes.forEach(function(n){
      if(n.querySelectorAll)n.querySelectorAll('#profile-avatar,#profile-preview').forEach(fixAvatar);
    });
    if(m.type==='attributes'&&(m.target.id==='profile-avatar'||m.target.id==='profile-preview'))fixAvatar(m.target);
  });
 }).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});
}else{
 setInterval(function(){['#profile-avatar','#profile-preview'].forEach(function(s){var el=$(s);if(el)fixAvatar(el)})},400);
}
['#profile-avatar','#profile-preview'].forEach(function(s){var el=$(s);if(el)fixAvatar(el)});
/* 4. Port média effectif : stocké au boot pour des vignettes stables. */
document.addEventListener('backendready',function(){
  setTimeout(function(){
    try{
      if(window.backend)
        window.backend.get_config().then(function(cfg){
          if(cfg&&cfg.media_port&&window.state)window.state.mediaPort=cfg.media_port;
        }).catch(function(){});
    }catch(_){}
  },600);
});
syncLoopBtn();
})();

/* ===== ux.js — surcouche UI/UX 1.0.5 (non destructive) =====
   Statut colore, barre avec pourcentage, bouton effacer, toasts de succes.
   Reutilise les fonctions existantes (setStatus, setBar, toast) sans les remplacer. */
(function(){
'use strict';
function $(s){return document.querySelector(s)}

/* 1. Bouton effacer le champ URL */
var btnClear=$('#btn-clear-url');
if(btnClear){
  btnClear.addEventListener('click',function(){
    var u=$('#url');if(!u)return;
    if(u.value){u.value='';u.focus();toast('Champ efface')}
  });
}

/* 2. Statut colore selon le texte courant (prete/busy/ok/erreur) */
var _setStatus=window.setStatus;
if(typeof _setStatus!=='function'){
  /* setStatus est defini dans app.js (const/fonction locale) : on lit le texte a la place */
  setInterval(function(){paintStatusClass($('#status')&&$('#status').textContent||'')},250);
}else{
  var __setStatus=_setStatus;
  window.setStatus=function(t){__setStatus(t);paintStatusClass(t)};
}
function paintStatusClass(t){
  var el=$('#status');if(!el)return;
  el.classList.remove('busy','ok','err');
  var s=(t||'').toLowerCase();
  if(s.indexOf('erreur')===0||s.indexOf('erreur')>=0)el.classList.add('err');
  else if(s.indexOf('telechargement')===0||s.indexOf('%')>=0)el.classList.add('busy');
  else if(s.indexOf('termine')===0)el.classList.add('ok');
}

/* 3. Barre : pourcentage affiche au centre via data-pct */
var _setBar=window.setBar;
if(typeof _setBar==='function'){
  var __setBar=_setBar;
  window.setBar=function(p){__setBar(p);var b=$('#bar');if(b)b.dataset.pct=(Math.max(0,Math.min(100,p)))+'%'};
}
/* Init/immediat meme sans evenement de progression (0% au boot) */
setInterval(function(){
  var b=$('#bar');if(!b)return;
  if(b.dataset.pct==null){var w=parseFloat(b.style.width)||0;b.dataset.pct=(w>0?w.toFixed(0):0)+'%'}
},300);

/* 4. Bouton telecharger : classe busy quand un telechargement tourne
   (state est une const globale non exposee sur window : on lit l'etat du bouton lui-meme) */
setInterval(function(){
  var b=$('#btn-download');
  if(b)b.classList.toggle('busy',b.disabled||((b.textContent||'').indexOf('…')>=0));
},300);

/* 5. Toast de succes (classe .ok) : on distingue Termine / Erreur a l'ecriture du toast */
var _toast=window.toast;
if(typeof _toast!=='function'){
  /* toast est defini dans app.js : on surveille les toasts crees et on tague les erreurs/succes */
  if(typeof MutationObserver==='function'){
    var obs=new MutationObserver(function(muts){
      muts.forEach(function(m){
        m.addedNodes.forEach(function(n){
          if(!n.classList||!n.classList.contains('toast'))return;
          var t=n.textContent||'';
          if(t.toLowerCase().indexOf('erreur')===0)n.classList.add('err');
          else if(t.toLowerCase().indexOf('termine')===0)n.classList.add('ok');
        });
      });
    });
    obs.observe($('#toasts')||document.body,{childList:true});
  }else{
    setInterval(function(){
      var host=$('#toasts');if(!host)return;
      Array.prototype.forEach.call(host.children,function(n){
        if(!n.classList||!n.classList.contains('toast')||n.dataset.uxTag)return;
        var t=n.textContent||'';
        if(t.toLowerCase().indexOf('erreur')===0)n.classList.add('err');
        else if(t.toLowerCase().indexOf('termine')===0)n.classList.add('ok');
        n.dataset.uxTag='1';
      });
    },400);
  }
}
})();
