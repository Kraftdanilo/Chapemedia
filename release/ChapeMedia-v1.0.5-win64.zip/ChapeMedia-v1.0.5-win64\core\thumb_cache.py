"""Cache local des vignettes de medias.

Pourquoi ce module : les URLs de vignettes renvoyees par les extracteurs (i.ytimg.com,
etc.) expirent, cassent ou refusent le referer -> l'historique affichait des images
brisees apres quelques jours. Ici, la vignette est telechargee UNE seule fois, stockee
dans ~/.chape_media/thumbs/ (nom = hash de l'URL) puis servie depuis le disque local.

Avantages :
  - plus d'image cassee (le fichier reste la meme si le hotlink disparait) ;
  - hors ligne, l'historique garde ses vignettes ;
  - le navigateur integre ne re-telecharge pas l'image a chaque rendu (cache local) ;
  - le disque est borne : seules les THUMB_MAX vignettes les plus recentes sont gardees.

Aucune dependance externe : urllib.request de la bibliotheque standard suffit.
"""
import hashlib
import os
import threading
import time
import urllib.request

from .config import THUMB_MAX, THUMBS_DIR

# En-tetes d'un navigateur reel : certains CDN refusent une requete sans User-Agent.
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) CHAPE-MEDIA thumbnail cache"
_HEADERS = {"User-Agent": _UA, "Accept": "image/*,*/*;q=0.8"}
_TIMEOUT = 10.0
_MAX_BYTES = 4 * 1024 * 1024     # securite : une vignette ne depasse jamais 4 Mo

# Verrou : plusieurs vignettes peuvent etre demandees en meme temps par le front.
_lock = threading.Lock()


def _key(url):
    """Nom de fichier stable pour une URL de vignette (empreinte SHA-1)."""
    return hashlib.sha1(str(url).encode("utf-8", "ignore")).hexdigest()


def path_for(url):
    """Chemin local de la vignette mise en cache (le fichier peut ne pas exister)."""
    return os.path.join(THUMBS_DIR, _key(url))


def find(url):
    """Fichier cache existant pour cette URL : sans extension (ancien nom) ou `.<ext>`.

    Les vignettes sont servies telles quelles au navigateur : leur type MIME vient de
    l'extension. L'ancien nom (hash seul) etait servi en application/octet-stream, que
    Chromium refuse d'afficher -> toutes les vignettes apparaissaient cassees.
    """
    base = path_for(url)
    if os.path.isfile(base) and os.path.getsize(base) > 0:
        return base
    for ext in (".jpg", ".png", ".webp", ".gif", ".avif", ".bmp"):
        cand = base + ext
        if os.path.isfile(cand) and os.path.getsize(cand) > 0:
            return cand
    return None


def _sniff(data):
    """Extension deduite du contenu (les CDN servent souvent du WEBP sans le dire)."""
    head = data[:16]
    if head.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return ".webp"
    if head.startswith(b"GIF8"):
        return ".gif"
    if head[4:8] == b"ftyp" and head[8:12] in (b"avif", b"avis"):
        return ".avif"
    if head.startswith(b"BM"):
        return ".bmp"
    return ""


def get(url):
    """Renvoie le chemin local de la vignette, en la telechargeant si besoin.

    Retourne None si l'URL est vide, invalide, ou si le telechargement echoue :
    l'appelant peut alors retomber sur l'URL d'origine (comportement degrade, jamais bloquant).
    """
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        return None
    existing = find(url)
    if existing:
        return existing
    base = path_for(url)
    with _lock:
        # Re-verification : un autre thread a pu telecharger la meme vignette entre-temps.
        existing = find(url)
        if existing:
            return existing
        try:
            req = urllib.request.Request(url, headers=_HEADERS)
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                data = resp.read(_MAX_BYTES + 1)
            if not data or len(data) > _MAX_BYTES:
                return None
            ext = _sniff(data)
            if not ext:
                return None          # pas une image : on n'ecrit rien (jamais de .part orphelin)
            target = base + ext
            # Ecriture atomique : fichier temporaire puis renommage (jamais de fichier tronque).
            tmp = target + ".part"
            with open(tmp, "wb") as fh:
                fh.write(data)
            os.replace(tmp, target)
            _prune()
            return target
        except Exception:
            # Echec reseau / 404 / format inattendu : on ne casse jamais l'affichage.
            return None


def migrate():
    """Renomme les vignettes de l'ancien cache (hash sans extension) avec leur vraie
    extension, en lisant la signature du fichier. Idempotent, sans perte."""
    moved = 0
    try:
        names = os.listdir(THUMBS_DIR)
    except OSError:
        return 0
    for name in names:
        if name.endswith((".part", ".jpg", ".png", ".webp", ".gif", ".avif", ".bmp")):
            continue
        src = os.path.join(THUMBS_DIR, name)
        if not os.path.isfile(src):
            continue
        try:
            with open(src, "rb") as fh:
                ext = _sniff(fh.read(16))
            if not ext:
                os.remove(src)          # contenu non image : inutilisable
                continue
            os.replace(src, src + ext)
            moved += 1
        except OSError:
            continue
    return moved


def _prune(keep=THUMB_MAX):
    """Ne garde que les `keep` vignettes les plus recentes (suppression best-effort)."""
    try:
        files = []
        for name in os.listdir(THUMBS_DIR):
            full = os.path.join(THUMBS_DIR, name)
            if name.endswith(".part") or not os.path.isfile(full):
                continue
            try:
                files.append((os.path.getmtime(full), full))
            except OSError:
                continue
        if len(files) <= keep:
            return
        files.sort(reverse=True)
        for _, full in files[keep:]:
            try:
                os.remove(full)
            except OSError:
                pass
    except OSError:
        pass
