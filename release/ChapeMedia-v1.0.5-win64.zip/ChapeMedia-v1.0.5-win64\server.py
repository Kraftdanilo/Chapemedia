"""CHAPE-MEDIA - Serveur FastAPI.

Remplace le pont pywebview (window.pywebview.api) par une API REST locale.
Toutes les methodes de core.api.Api sont exposees en POST /api/<nom> ; les
lectures pures (get_*, scan_library, poll_events...) le sont aussi en GET.
CORS est restreint : seule la fenetre servie par ce meme serveur est acceptee.

Lancement :
    python server.py                                (lance uvicorn directement)
    python -m uvicorn server:app --port 8928        (depuis app/)
Le port par defaut (8928) est defini dans core/config.py (API_PORT) et peut
etre change par CHAPE_MEDIA_API_PORT ou le reglage "api_port" de config.json.
"""
from __future__ import annotations

from typing import Any, Callable

try:
    from fastapi import FastAPI, Request
    from fastapi.staticfiles import StaticFiles
    from fastapi.responses import FileResponse, JSONResponse
except ImportError as e:                                    # pragma: no cover
    raise SystemExit("Installez FastAPI : pip install fastapi uvicorn") from e

from core.api import Api
from core.config import API_PORT, API_PORT_FALLBACKS, APP_VERSION, WEB_DIR

# Documentation FastAPI (docs, redoc, openapi.json) desactivee : ce serveur n'est
# destine qu'a la fenetre locale, exposer le schema ne sert a rien et donne une
# surface d'attaque gratuite.
app = FastAPI(title="CHAPE-MEDIA API", version=APP_VERSION,
              docs_url=None, redoc_url=None, openapi_url=None)

# --------------------------------------------------------------- origine de la requete
# Seule la fenetre servie par ce serveur (meme hote) peut appeler /api/*. Le port de
# repli n'est connu qu'apres bind_port() : on enregistre les origines la-bas.
_ALLOWED_ORIGINS: set[str] = set()


def _register_origin_port(port: int):
    """Autorise l'origine du port effectif (bind_port choisit un eventuel repli)."""
    _ALLOWED_ORIGINS.update({"http://127.0.0.1:%d" % port, "http://localhost:%d" % port})


_register_origin_port(API_PORT)


@app.middleware("http")
async def _check_origin(request: Request, call_next):
    if request.url.path.startswith("/api/"):
        origin = request.headers.get("origin")
        host = request.headers.get("host") or ""
        same_host = "http://" + host
        if origin and origin != same_host and origin not in _ALLOWED_ORIGINS:
            return JSONResponse({"ok": False, "error": "Origine refusee"}, status_code=403)
    return await call_next(request)


_api: Api | None = None


def get_api() -> Api:
    global _api
    if _api is None:
        _api = Api()
    return _api


# --------------------------------------------------------------- routes statiques
@app.get("/")
def index():
    return FileResponse(WEB_DIR + "/index.html")


@app.get("/api/health")
def health():
    return {"ok": True, "version": get_api().get_version().get("display_version")}


# --------------------------------------------------------------- route generique
_METHODS: dict[str, Callable[..., Any]] = {}

# Lectures pures : aucune ecriture disque ni changement d'etat. Seules ces methodes
# acceptent GET ; toutes les autres (delete_file, install_update, shutdown...) sont
# POST uniquement : un GET les rendrait declenchables par une simple balise
# <img src=".../api/delete_file?path=..."> depuis n'importe quelle page.
_METHODS_READONLY = frozenset({
    "get_config", "get_profile", "get_history", "get_favorites", "get_stats",
    "get_logs", "get_version", "media_url", "thumb_url", "scan_library",
    "poster_url", "search_history", "queue_state", "db_info", "poll_events",
})


def _init_routes():
    """Genere POST /api/<nom> pour chaque methode publique, GET pour les lectures."""
    global _METHODS
    api = get_api()
    for name in dir(api):
        if name.startswith("_"):
            continue
        fn = getattr(api, name)
        if not callable(fn):
            continue
        # pywebview expose aussi les proprietes ; on filtre
        if isinstance(getattr(type(api), name, None), property):
            continue
        _METHODS[name] = fn

        def _make(fn=fn):
            import inspect
            # Parametres du backend : sert a distinguer kwargs nommes
            # d'un payload objet unique passe en positionnel (ex: start_download(opts)).
            # NB : fn est une methode LIEE (getattr(api, name)) -> self n'est deja
            # plus dans la signature, il ne faut PAS retirer un parametre de plus.
            try:
                _params = list(inspect.signature(fn).parameters.values())
                _has_var_kw = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in _params)
                _names = [p.name for p in _params if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)]
            except (TypeError, ValueError):
                _params, _has_var_kw, _names = [], False, []

            async def handler(request: Request):
                payload: Any = {}
                if request.method == "POST":
                    try:
                        payload = await request.json()
                    except Exception:
                        payload = {}
                # GET : les arguments arrivent dans la query string
                # (?query=xxx&limit=200) -> meme distribution que le POST.
                if request.method != "POST":
                    q = dict(request.query_params)
                    if q:
                        payload = q
                if isinstance(payload, dict) and payload.get("__args__") is not None:
                    args = payload["__args__"]
                    kwargs = {}
                elif isinstance(payload, dict) and payload:
                    # Payload objet : kwargs si TOUTES les cles correspondent aux
                    # parametres. Sinon (ex: start_download({url, mode, vformat…})
                    # qui n'a qu'un parametre `opts`) l'objet est passe en positionnel.
                    # Methode a un seul parametre (ex: start_download(opts),
                    # set_profile(name, photo="")) et payload sans cette cle :
                    # le payload EST la valeur de ce parametre.
                    if not _has_var_kw and _names and len(_names) == 1 and _names[0] not in payload:
                        # Un seul parametre dont le nom n'est pas dans le payload :
                        # c'est la valeur de ce parametre -> start_download({url…}),
                        # set_profile({name, photo}).
                        args, kwargs = [payload], {}
                    elif not _has_var_kw and _names and not all(k in _names for k in payload):
                        # Aucune cle ne correspond a la signature : objet unique.
                        args, kwargs = [payload], {}
                    else:
                        args, kwargs = [], payload
                elif payload:
                    args, kwargs = [payload], {}
                else:
                    args, kwargs = [], {}
                try:
                    result = await _run_blocking(fn, *args, **kwargs)
                    return JSONResponse(result)
                except Exception as e:
                    return JSONResponse({"ok": False, "error": str(e)}, status_code=500)
            return handler

        app.post("/api/%s" % name)(_make())
        if name in _METHODS_READONLY:
            _GET_HANDLERS[name] = _make()


# GET generique : Starlette route en fonction du chemin AVANT la methode, donc un
# GET sur une action tombe ici et recoit 405 (au lieu du 404 du montage statique).
# Les lectures pures trouvent leur handler dans _GET_HANDLERS.
_GET_HANDLERS: dict[str, Callable] = {}


@app.api_route("/api/{name}", methods=["GET", "HEAD"], include_in_schema=False)
async def _api_get(name: str, request: Request):
    handler = _GET_HANDLERS.get(name)
    if handler is None:
        return JSONResponse({"ok": False, "error": "Methode GET non autorisee pour %s" % name},
                            status_code=405, headers={"Allow": "POST"})
    return await handler(request)


async def _run_blocking(fn, *args, **kwargs):
    """Les methodes Api sont du code sync (SQLite, subprocess) -> thread pool."""
    import asyncio
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: fn(*args, **kwargs))


_init_routes()


# --------------------------------------------------------------- fichiers statiques
# Monté EN DERNIER : les routes /api/* et / ci-dessus restent prioritaires.
# Sert app*.js, style*.css, bridge.js, icônes… depuis web/.
app.mount("/", StaticFiles(directory=WEB_DIR, html=True), name="web")


def bind_port():
    """Trouve un port libre pour l'API : API_PORT puis les replis.

    Ne jamais laisser un port deja pris bloquer l'application : on prend le
    premier port disponible et on le publie (server.API_PORT).
    """
    import socket
    global API_PORT
    for port in (API_PORT,) + tuple(API_PORT_FALLBACKS):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("127.0.0.1", port))
            s.close()
            API_PORT = port
            _register_origin_port(port)
            return port
        except OSError:
            s.close()
    raise SystemExit("Aucun port libre pour l'API CHAPE-MEDIA (%s…)" % API_PORT)


def uvicorn_run(host="127.0.0.1", port=None):
    """Lance le serveur FastAPI dans un thread (utilise par app.py)."""
    import uvicorn
    uvicorn.run(app, host=host, port=port or bind_port(), log_level="warning")


if __name__ == "__main__":                                  # pragma: no cover
    print("CHAPE-MEDIA API sur http://127.0.0.1:%d" % bind_port())
    uvicorn_run(port=API_PORT)
