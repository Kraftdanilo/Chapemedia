/* CHAPE-MEDIA - pont front <-> backend.
   Le backend est FastAPI (app/server.py) : chaque methode de core/api.Api est
   exposee en POST /api/<nom>. Ce pont definit window.backend, un proxy :
   backend.<methode>(args...) retourne une Promise avec le resultat.
   Il emet aussi l'evenement 'backendready' quand le serveur repond.

   Port : jamais code en dur. Le front est servi par le meme serveur, donc on
   reutilise location.origin (port effectif, y compris si l'API a bascule sur un
   port de repli). file:// n'a pas d'origine exploitable -> web/bridge.js?port=N
   ou window.CHAPE_API_PORT, sinon 8928 (defaut de core/config.py). */
(function () {
  'use strict';
  const params = new URLSearchParams(location.search || '');
  const fromQuery = parseInt(params.get('port'), 10);
  const fromGlobal = parseInt(window.CHAPE_API_PORT, 10);
  const defaultPort = fromQuery || fromGlobal || 8928;
  const API_BASE = (/^https?:$/.test(location.protocol) && location.port)
    ? location.origin + '/api'
    : ('http://127.0.0.1:' + defaultPort + '/api');

  async function call(name, ...args) {
    // Convention : tous les arguments partent en positionnel ({"__args__": [...]}).
    // Sans encadrer un objet unique (ex. start_download({url, mode…})), le serveur
    // lisait ses cles comme des parametres nommes -> HTTP 500.
    const body = { __args__: args };
    const res = await fetch(API_BASE + '/' + name, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      let msg = 'Erreur serveur ' + res.status;
      try { const j = await res.json(); if (j && j.error) msg = j.error; } catch (_) { }
      throw new Error(msg);
    }
    const text = await res.text();
    if (!text) return null;
    try { return JSON.parse(text); } catch (_) { return text; }
  }

  // Proxy transparent : toute propriete devient un appel HTTP du meme nom.
  window.backend = new Proxy({}, {
    get(_t, prop) {
      if (typeof prop !== 'string') return undefined;
      if (prop === 'then') return undefined;   // Promise friendly
      return function (...args) { return call(prop, ...args); };
    },
    has() { return true; },
  });

  // Le front demarre a la reception de 'backendready' (apres healthcheck).
  function ready() { document.dispatchEvent(new Event('backendready')); }
  function ping(n) {
    fetch(API_BASE + '/health')
      .then(r => { if (r.ok) ready(); else if (n > 0) setTimeout(() => ping(n - 1), 500); })
      .catch(() => { if (n > 0) setTimeout(() => ping(n - 1), 500); });
  }
  ping(20);
})();
